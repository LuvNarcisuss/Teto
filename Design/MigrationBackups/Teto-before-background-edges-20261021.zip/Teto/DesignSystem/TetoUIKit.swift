import Combine
import UIKit

enum TetoTheme {
  static let background = UIColor(red: 250 / 255, green: 251 / 255, blue: 247 / 255, alpha: 1)
  static let ink = UIColor(red: 20 / 255, green: 38 / 255, blue: 32 / 255, alpha: 1)
  static let emerald = UIColor(red: 18 / 255, green: 107 / 255, blue: 88 / 255, alpha: 1)
  static let lime = UIColor(red: 221 / 255, green: 244 / 255, blue: 166 / 255, alpha: 1)
  static let muted = UIColor(red: 79 / 255, green: 102 / 255, blue: 92 / 255, alpha: 1)
  static let pink = UIColor(red: 1, green: 0.24, blue: 0.43, alpha: 1)
  static let soft = UIColor(red: 240 / 255, green: 245 / 255, blue: 238 / 255, alpha: 1)
  static func font(_ size: CGFloat = 16, title: Bool = false) -> UIFont {
    let base =
      UIFont(name: title ? "AvenirNext-BoldItalic" : "AvenirNext-Medium", size: size)
      ?? UIFont.systemFont(ofSize: size)
    return UIFontMetrics(forTextStyle: title ? .title2 : .body).scaledFont(for: base)
  }
}

final class StudioCanvas: UIView {
  private let wash = CAGradientLayer()
  private let ribbon = CAShapeLayer()
  override init(frame: CGRect) {
    super.init(frame: frame)
    isUserInteractionEnabled = false
    wash.colors = [
      TetoTheme.background.cgColor, UIColor(red: 0.89, green: 0.97, blue: 0.93, alpha: 1).cgColor,
      TetoTheme.background.cgColor,
    ]
    wash.startPoint = CGPoint(x: 0, y: 0)
    wash.endPoint = CGPoint(x: 1, y: 1)
    layer.addSublayer(wash)
    ribbon.fillColor = TetoTheme.lime.withAlphaComponent(0.28).cgColor
    layer.addSublayer(ribbon)
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  override func layoutSubviews() {
    super.layoutSubviews()
    wash.frame = bounds
    let w = bounds.width
    let h = bounds.height
    let p = UIBezierPath()
    p.move(to: CGPoint(x: w, y: h * 0.1))
    p.addCurve(
      to: CGPoint(x: 0, y: h * 0.65), controlPoint1: CGPoint(x: -w * 0.7, y: h * 0.1),
      controlPoint2: CGPoint(x: w * 1.5, y: h * 0.6))
    p.addCurve(
      to: CGPoint(x: w, y: h * 0.2), controlPoint1: CGPoint(x: w * 1.7, y: h * 0.8),
      controlPoint2: CGPoint(x: -w * 0.5, y: h * 0.15))
    p.close()
    ribbon.path = p.cgPath
  }
}

extension UIView {
  func pin(to other: UIView, insets: UIEdgeInsets = .zero) {
    translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      leadingAnchor.constraint(equalTo: other.leadingAnchor, constant: insets.left),
      trailingAnchor.constraint(equalTo: other.trailingAnchor, constant: -insets.right),
      topAnchor.constraint(equalTo: other.topAnchor, constant: insets.top),
      bottomAnchor.constraint(equalTo: other.bottomAnchor, constant: -insets.bottom),
    ])
  }
  func rounded(_ radius: CGFloat = 18) {
    layer.cornerRadius = radius
    clipsToBounds = true
  }
  func height(_ value: CGFloat) { heightAnchor.constraint(equalToConstant: value).isActive = true }
}
@MainActor func label(
  _ text: String, _ size: CGFloat = 16, _ color: UIColor = TetoTheme.ink, title: Bool = false
) -> UILabel {
  let l = UILabel()
  l.text = text
  l.font = TetoTheme.font(size, title: title)
  l.textColor = color
  l.numberOfLines = 0
  l.adjustsFontForContentSizeCategory = true
  return l
}
@MainActor func stack(
  _ views: [UIView] = [], axis: NSLayoutConstraint.Axis = .vertical, spacing: CGFloat = 12
) -> UIStackView {
  let s = UIStackView(arrangedSubviews: views)
  s.axis = axis
  s.spacing = spacing
  return s
}
@MainActor func iconButton(
  _ icon: TetoIcon, _ name: String, color: UIColor = TetoTheme.emerald, action: @escaping () -> Void
) -> UIButton {
  let b = UIButton(type: .custom)
  b.setImage(icon.image(color), for: .normal)
  b.accessibilityLabel = name
  b.translatesAutoresizingMaskIntoConstraints = false
  b.widthAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
  b.heightAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
  b.addAction(UIAction { _ in action() }, for: .touchUpInside)
  return b
}
@MainActor func actionButton(
  _ text: String, icon: TetoIcon? = nil, primary: Bool = false, action: @escaping () -> Void
) -> UIButton {
  let b = UIButton(type: .custom)
  var c = UIButton.Configuration.plain()
  c.title = text
  c.image = icon?.image(primary ? .white : TetoTheme.emerald, size: 23)
  c.imagePadding = 10
  c.baseForegroundColor = primary ? .white : TetoTheme.ink
  c.background.backgroundColor = primary ? TetoTheme.emerald : UIColor.white.withAlphaComponent(0.7)
  c.background.cornerRadius = 20
  c.contentInsets = NSDirectionalEdgeInsets(top: 13, leading: 16, bottom: 13, trailing: 16)
  b.configuration = c
  b.configuration?.titleTextAttributesTransformer = UIConfigurationTextAttributesTransformer {
    attributes in
    var result = attributes
    result.font = TetoTheme.font()
    return result
  }
  b.titleLabel?.numberOfLines = 0
  b.heightAnchor.constraint(greaterThanOrEqualToConstant: 48).isActive = true
  b.addAction(UIAction { _ in action() }, for: .touchUpInside)
  return b
}
@MainActor func field(_ placeholder: String, text: String = "") -> UITextField {
  let f = UITextField()
  f.placeholder = placeholder
  f.text = text
  f.font = TetoTheme.font()
  f.textColor = TetoTheme.ink
  f.backgroundColor = .white
  f.layer.cornerRadius = 14
  f.height(52)
  let pad = UIView(frame: CGRect(x: 0, y: 0, width: 14, height: 10))
  f.leftView = pad
  f.leftViewMode = .always
  f.autocorrectionType = .no
  f.accessibilityLabel = placeholder
  return f
}
final class TetoPhoto: UIImageView {
  private var request: UUID?
  init(asset: String? = nil, size: CGFloat? = nil, round: Bool = false) {
    super.init(frame: .zero)
    contentMode = .scaleAspectFill
    clipsToBounds = true
    backgroundColor = TetoTheme.soft
    if let asset { image = UIImage(named: FreshStudioPhotos.avatar(asset)) }
    if let size {
      translatesAutoresizingMaskIntoConstraints = false
      widthAnchor.constraint(equalToConstant: size).isActive = true
      height(size)
      layer.cornerRadius = round ? size / 2 : 14
    }
    isAccessibilityElement = false
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  func load(_ url: URL?) {
    let id = UUID()
    request = id
    image = TetoIcon.photo.image(size: 64)
    guard let url else { return }
    Task {
      let data = await Task.detached(priority: .utility) { try? Data(contentsOf: url) }.value
      guard request == id else { return }
      if let data, let loaded = UIImage(data: data) { image = loaded }
    }
  }
}

@MainActor class TetoScreen: UIViewController, UIAdaptivePresentationControllerDelegate {
  func presentationControllerDidDismiss(_ presentationController: UIPresentationController) {
    onDismiss?()
  }
  let store: AppStore
  var tokens = Set<AnyCancellable>()
  var onDismiss: (() -> Void)?
  private var shownNotice: UUID?
  override func viewDidDisappear(_ animated: Bool) {
    super.viewDidDisappear(animated)
    if isBeingDismissed || navigationController?.isBeingDismissed == true { onDismiss?() }
  }
  init(store: AppStore, title: String = "") {
    self.store = store
    super.init(nibName: nil, bundle: nil)
    self.title = title
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  override func viewDidLoad() {
    super.viewDidLoad()
    view.backgroundColor = TetoTheme.background
    let bg = StudioCanvas()
    view.addSubview(bg)
    bg.pin(to: view)
    overrideUserInterfaceStyle = .light
    build()
    refresh()
    store.objectWillChange.receive(on: DispatchQueue.main).sink { [weak self] _ in
      guard let self else { return }
      self.refresh()
      if let notice = self.store.notice, notice.id != self.shownNotice, self.view.window != nil,
        self.presentedViewController == nil
      {
        self.shownNotice = notice.id
        self.message(notice.message, title: notice.title)
        self.store.notice = nil
      }
    }
    .store(in: &tokens)
  }
  func build() {}
  func refresh() {}
  func presentScreen(_ screen: UIViewController, full: Bool = false) {
    let nav = UINavigationController(rootViewController: screen)
    TetoNavigation.style(nav)
    if full {
      nav.modalPresentationStyle = .fullScreen
    } else {
      nav.modalPresentationStyle = .pageSheet
      nav.sheetPresentationController?.detents = [.medium(), .large()]
      nav.sheetPresentationController?.prefersGrabberVisible = true
      nav.presentationController?.delegate = screen as? UIAdaptivePresentationControllerDelegate
    }
    screen.navigationItem.leftBarButtonItem = UIBarButtonItem(
      customView: iconButton(.close, "Close") { [weak nav, weak screen] in
        nav?.dismiss(animated: true) { (screen as? TetoScreen)?.onDismiss?() }
      })
    present(nav, animated: true)
  }
  func push(_ screen: UIViewController) {
    navigationController?.pushViewController(screen, animated: true)
  }
  func message(_ text: String, title: String = "Teto") {
    guard presentedViewController == nil else { return }
    let a = UIAlertController(title: title, message: text, preferredStyle: .alert)
    a.addAction(UIAlertAction(title: "OK", style: .default))
    present(a, animated: true)
  }
  func confirm(
    _ title: String, message: String, destructive: Bool = false, button: String = "Continue",
    action: @escaping () -> Void
  ) {
    let a = UIAlertController(title: title, message: message, preferredStyle: .alert)
    a.addAction(UIAlertAction(title: "Cancel", style: .cancel))
    a.addAction(
      UIAlertAction(title: button, style: destructive ? .destructive : .default) { _ in action() })
    present(a, animated: true)
  }
  func share(_ text: String, completion: ((Bool) -> Void)? = nil) {
    let sheet = UIActivityViewController(activityItems: [text], applicationActivities: nil)
    sheet.completionWithItemsHandler = { _, done, _, _ in completion?(done) }
    sheet.popoverPresentationController?.sourceView = view
    sheet.popoverPresentationController?.sourceRect = CGRect(
      x: view.bounds.midX, y: view.bounds.midY, width: 1, height: 1)
    present(sheet, animated: true)
  }
  func save(_ operation: @escaping () async -> Bool) {
    Task {
      if !(await operation()) {
        message(store.lastSaveError ?? "Your changes could not be saved. Please try again.")
      }
    }
  }
}

@MainActor class StackScreen: TetoScreen {
  let scroll = UIScrollView()
  let content = UIStackView()
  override func build() {
    content.axis = .vertical
    content.spacing = 18
    scroll.keyboardDismissMode = .interactive
    view.addSubview(scroll)
    scroll.translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
      scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
      scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
      scroll.bottomAnchor.constraint(equalTo: view.keyboardLayoutGuide.topAnchor),
    ])
    scroll.addSubview(content)
    content.translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      content.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 20),
      content.bottomAnchor.constraint(
        equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -24),
      content.leadingAnchor.constraint(
        equalTo: scroll.contentLayoutGuide.leadingAnchor, constant: 16),
      content.trailingAnchor.constraint(
        equalTo: scroll.contentLayoutGuide.trailingAnchor, constant: -16),
      content.widthAnchor.constraint(equalTo: scroll.frameLayoutGuide.widthAnchor, constant: -32),
    ])
    NotificationCenter.default.publisher(for: UIResponder.keyboardDidShowNotification).receive(
      on: DispatchQueue.main
    ).sink { [weak self] _ in
      guard let self, let active = self.view.firstResponderView else { return }
      self.scroll.scrollRectToVisible(
        active.convert(active.bounds, to: self.scroll).insetBy(dx: 0, dy: -18), animated: true)
    }.store(in: &tokens)
  }
  func clear() { content.arrangedSubviews.forEach { $0.removeFromSuperview() } }
  func heading(_ text: String) { content.addArrangedSubview(label(text, 26, title: true)) }
}
extension UIView {
  var firstResponderView: UIView? {
    if isFirstResponder { return self }
    return subviews.lazy.compactMap { $0.firstResponderView }.first
  }
}
@MainActor enum TetoNavigation {
  static func style(_ nav: UINavigationController) {
    let a = UINavigationBarAppearance()
    a.configureWithTransparentBackground()
    a.backgroundColor = TetoTheme.background.withAlphaComponent(0.9)
    a.titleTextAttributes = [
      .font: TetoTheme.font(19, title: true), .foregroundColor: TetoTheme.ink,
    ]
    a.setBackIndicatorImage(TetoIcon.back.image(), transitionMaskImage: TetoIcon.back.image())
    nav.navigationBar.standardAppearance = a
    nav.navigationBar.scrollEdgeAppearance = a
    nav.navigationBar.compactAppearance = a
    nav.navigationBar.tintColor = TetoTheme.emerald
  }
}
