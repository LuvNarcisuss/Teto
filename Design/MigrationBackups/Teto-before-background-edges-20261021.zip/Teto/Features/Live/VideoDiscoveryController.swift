import UIKit

@MainActor final class VideoTile: UIControl {
  private let cover = TetoPhoto(), caption = UILabel(), avatar = TetoPhoto(size: 24, round: true)
  var onTap: (() -> Void)?
  override init(frame: CGRect) {
    super.init(frame: frame)
    rounded(19)
    backgroundColor = TetoTheme.soft
    addSubview(cover)
    cover.pin(to: self)
    let shade = UIView()
    shade.backgroundColor = UIColor.black.withAlphaComponent(0.38)
    addSubview(shade)
    shade.translatesAutoresizingMaskIntoConstraints = false
    NSLayoutConstraint.activate([
      shade.leadingAnchor.constraint(equalTo: leadingAnchor),
      shade.trailingAnchor.constraint(equalTo: trailingAnchor),
      shade.bottomAnchor.constraint(equalTo: bottomAnchor),
    ])
    caption.font = TetoTheme.font(14)
    caption.textColor = .white
    caption.numberOfLines = 2
    caption.adjustsFontForContentSizeCategory = true
    let row = stack([avatar, caption], axis: .horizontal, spacing: 7)
    row.alignment = .center
    shade.addSubview(row)
    row.pin(to: shade, insets: UIEdgeInsets(top: 9, left: 9, bottom: 9, right: 9))
    cover.isUserInteractionEnabled = false
    shade.isUserInteractionEnabled = false
    addAction(UIAction { [weak self] _ in self?.onTap?() }, for: .touchUpInside)
    isAccessibilityElement = true
    accessibilityTraits = .button
  }
  required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }
  func configure(_ video: LocalVideo, store: AppStore, showDuration: Bool) {
    cover.load(store.coverURL(video))
    avatar.image = UIImage(named: FreshStudioPhotos.creatorAvatar(for: video.creatorID))
    caption.text = video.title + (showDuration ? "\n" + video.durationLabel : "")
    accessibilityLabel = video.title + ", " + video.creatorName(profile: store.library.profile)
  }
}
extension StackScreen {
  func videoGrid(
    _ videos: [LocalVideo], duration: Bool = true, onSelect: @escaping (LocalVideo) -> Void
  ) {
    guard !videos.isEmpty else {
      content.addArrangedSubview(label("Your next favorite move is waiting.", 17, TetoTheme.muted))
      return
    }
    let columns = traitCollection.preferredContentSizeCategory.isAccessibilityCategory ? 1 : 2
    for start in stride(from: 0, to: videos.count, by: columns) {
      let row = stack(axis: .horizontal, spacing: 10)
      row.distribution = .fillEqually
      for video in videos[start..<min(start + columns, videos.count)] {
        let tile = VideoTile()
        tile.configure(video, store: store, showDuration: duration)
        tile.onTap = { onSelect(video) }
        tile.heightAnchor.constraint(equalTo: tile.widthAnchor, multiplier: 1.25).isActive = true
        row.addArrangedSubview(tile)
      }
      if row.arrangedSubviews.count < columns { row.addArrangedSubview(UIView()) }
      content.addArrangedSubview(row)
    }
  }
}
final class DanceDiscoveryController: StackScreen, UISearchBarDelegate {
  private let searchBar = UISearchBar()
  private let modes = UISegmentedControl(items: ["Live", "Shorts"])
  private let searchHolder = UIView()
  private var query = ""
  private var shorts: VideoFeedController?
  private var searchOpen = false
  override func build() {
    super.build()
    title = "Teto"
    modes.selectedSegmentIndex = 0
    modes.selectedSegmentTintColor = TetoTheme.lime
    modes.addAction(UIAction { [weak self] _ in self?.changeMode() }, for: .valueChanged)
    navigationItem.titleView = modes
    navigationItem.leftBarButtonItem = UIBarButtonItem(
      customView: iconButton(.live, "Create") { [weak self] in self?.create() })
    navigationItem.rightBarButtonItem = UIBarButtonItem(
      customView: iconButton(.search, "Search") { [weak self] in self?.toggleSearch() })
    searchBar.searchBarStyle = .minimal
    searchBar.placeholder = "Search dancers and videos"
    searchBar.delegate = self
    searchBar.setImage(TetoIcon.search.image(size: 20), for: .search, state: .normal)
    searchBar.setImage(TetoIcon.close.image(size: 18), for: .clear, state: .normal)
    let refresh = UIRefreshControl()
    refresh.addAction(
      UIAction { [weak self] _ in
        guard let self else { return }
        Task {
          await self.store.refreshLiveRecommendations()
          refresh.endRefreshing()
          self.refresh()
        }
      }, for: .valueChanged)
    scroll.refreshControl = refresh
  }
  override func refresh() {
    guard isViewLoaded else { return }
    clear()

    heading("Find your people.")
    content.addArrangedSubview(label("A shared rhythm. A fresh perspective.", 16, TetoTheme.muted))
    let videos = store.discoveryVideos.filter {
      query.isEmpty
        || ($0.title + $0.creatorName(profile: store.library.profile))
          .localizedCaseInsensitiveContains(query)
    }
    videoGrid(videos, duration: false) { [weak self] video in
      guard let self else { return }
      self.presentScreen(
        VideoFeedController(store: self.store, videos: videos, initial: video.id, live: true),
        full: true)
    }
  }
  private func create() {
    presentScreen(
      CreationController(store: store, kind: modes.selectedSegmentIndex == 0 ? .live : .shortVideo))
  }
  private func changeMode() {
    if let nav = navigationController {
      if modes.selectedSegmentIndex == 1 {
        let appearance = UINavigationBarAppearance()
        appearance.configureWithTransparentBackground()
        nav.navigationBar.standardAppearance = appearance
        nav.navigationBar.scrollEdgeAppearance = appearance
      } else {
        TetoNavigation.style(nav)
      }
    }
    shorts?.willMove(toParent: nil)
    shorts?.view.removeFromSuperview()
    shorts?.removeFromParent()
    shorts = nil
    scroll.isHidden = modes.selectedSegmentIndex == 1
    guard modes.selectedSegmentIndex == 1 else {
      refresh()
      return
    }
    let child = VideoFeedController(
      store: store, videos: store.shortsDiscoveryVideos, initial: nil, live: false, discovery: true)
    shorts = child
    addChild(child)
    view.addSubview(child.view)
    child.view.pin(to: view)
    child.didMove(toParent: self)
  }
  private func toggleSearch() {
    if let shorts {
      shorts.openSearch()
      return
    }
    searchOpen.toggle()
    navigationItem.titleView = searchOpen ? searchBar : modes
    refresh()
    if searchOpen {
      searchBar.becomeFirstResponder()
    } else {
      view.endEditing(true)
      query = ""
      refresh()
    }
  }
  func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
    query = searchText
    refresh()
    searchBar.becomeFirstResponder()
  }
}
