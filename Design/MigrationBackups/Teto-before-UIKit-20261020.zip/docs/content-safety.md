# Content reports and creator blocking

## Entry points

Live's existing ellipsis opens More options, retaining playback, mute, speed, chat-flow and credit controls while adding the shared safety section. Shorts adds an ellipsis button directly below Share, using the same safety component in its own native options sheet. Its action rail can scroll if the available height is too short. Buttons retain 44-point targets and English accessibility labels.

ContentSafetyActions provides Report video and Block creator. The report target contains the content ID, title, media kind and stable creator identity. Live uses sourceVideoID when available; Shorts uses the video's ID. Both resolve the same creator identity used by profiles and private messages.

## Reports

Reasons cover spam, harassment, hate, sexual content, violence, dangerous activity and other concerns. Details are optional, English, up to 500 characters. Save report uses the existing atomic repository. The completion explicitly says the report is on this device and has not been submitted; no moderation service, case number, enforcement or platform receipt is fabricated. Repeating the same content/kind/reason updates its existing local record rather than duplicating it. Storage errors remain in the form without success feedback. Me > Blocked creators also lists locally saved reports.

## Blocking

Confirmation explains the local scope. A successful atomic save records the creator by stable ID and removes the local follow. Discovery videos (Live/Shorts/search), saved-video lists, creator works and author-chat lists exclude blocked creators. Explicit saved/profile playback IDs are also filtered. Follow and private-draft mutation methods reject blocked creators. The local owner's profile cannot be blocked.

Live stops playback/comment flow on block, closes the options sheet, then dismisses the room. Shorts removes the blocked creator's videos and reconciles its selection; when no videos remain it stops/releases the player and shows the empty feed. A single-video collection cover closes after its options sheet dismisses, returning to its collection/profile. Player lifecycle is paused while options/report sheets are open.

Blocking does not delete videos, favorites, comments or private drafts. Me > Blocked creators can unblock, restoring visibility and preserved chat/favorite data; it does not automatically follow again. There is no server-side block, account enforcement, notification to the creator or message transport integration.

## Storage and files

LocalLibrary.contentSafety is optional for backward compatibility with existing version-1 snapshots. ContentSafetyState stores blocked profiles and LocalContentReport records. It has no credentials or UserDefaults writes.

- `Features/Safety/ContentSafety.swift`: targets, reason enum and persisted state.
- `Features/Safety/ContentSafetyViews.swift`: shared actions, report form, unblock/report management.
- `App/AppStore.swift`, `Domain/LocalLibrary.swift`: atomic mutations, filtering and compatibility.
- `Features/LiveRoom/LiveRoomView.swift`, `LiveRoomSheets.swift`: existing ellipsis integration and safe room exit.
- `Features/Shorts/ShortVideoPage.swift`, `ShortsFeedView.swift`, `ShortsInteractionStore.swift`: new rail action, options routing, filtered playback lifecycle.
- `Features/Profile/ProfileView.swift`: blocked-creator management entry.
- `Features/Creators/CreatorProfileView.swift`: disabled follow/message controls for blocked creators.

## Verification

Inspected source routing, filter consumers, async success/error branches, English strings and retained dance media. Regenerated Xcode project metadata and linted the project plist. No compilation, typecheck, tests, app run, simulator or Preview execution. Actual sheet dismissal, small-screen action-rail layout, persistent-state migration, report saving and unblock behavior remain unverified on a device.
