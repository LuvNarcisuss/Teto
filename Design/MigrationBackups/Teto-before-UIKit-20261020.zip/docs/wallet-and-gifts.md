# Teto wallet and live gifts

## Brand and data preservation

App display name, welcome/sign-in, profile/About, party heading, authored activity sender, shares, camera permission and agreement copy now say Teto. The current icon has no written brand and is retained. Swift type names, source directory, Xcode target/scheme `teto`, Bundle ID `com.example.teto` and the Application Support/Teto library path are intentionally unchanged. Existing private profiles, media, follows, chats, reports and consent records are not rewritten or reset. Historical docs retain their original brand context.

## Wallet flow

Me > Wallet opens a Fresh Studio light page with a diamond balance card, a selected-state 3×3 recharge grid, USD prices, purchase confirmation and transaction history. Large accessibility text uses two columns. Diamonds are the only virtual currency; there is no currency selector or coin balance. Diamond artwork uses mint/evergreen gradients. Existing diamond package IDs, prices and gift prices are unchanged. No wallet data was persisted before this change, so no balance migration is needed.

| USD | Diamonds | Product ID | Source |
| --- | ---: | --- | --- |
| $0.99 | 400 | `hoewtkchclzkuruf` | User screenshot |
| $1.99 | 800 | `qbfuucwaccetjljs` | User screenshot |
| $4.99 | 2,450 | `mdnrsibqccschjcg` | User screenshot |
| $9.99 | 5,150 | `olfouxazhsdntxzs` | User screenshot |
| $19.99 | 10,800 | `ejtvapyfnomaimlf` | User screenshot |
| $29.99 | 16,800 | `qlrpflukqugckska` | Newly proposed ID |
| $49.99 | 29,400 | `uficsdpshzadegnz` | User screenshot |
| $69.99 | 42,600 | `zhkxxppfqwqfwhcp` | Newly proposed ID |
| $99.99 | 63,700 | `cbhpozbwbvfwgqxp` | User screenshot |

Each package now requires a nonempty `storeProductID` in the catalog. The seven supplied IDs are mapped exactly to their screenshot tiers. The two proposed IDs must also be registered as consumable products in App Store Connect and in the purchase backend's catalog before use. No store registration or product availability has been verified. The existing grid's identity, order, selection, quantities and reference prices are preserved.

The original tier screenshot is retained outside the target at `Design/References/Wallet/tiers-original.png`. The listed USD amounts are reference catalog values, not prices retrieved from Apple's storefront. Bank/account information from the provided screenshot is not needed for product mapping and is not included in the app configuration.

## Live gift flow

Live > Gifts shows diamond balance, Recharge shortcut, nine gift tiles, quantity 1–99, computed total and Send confirmation. It opens at the large sheet size. Opening the wallet from this sheet retains the selected gift and quantity; closing the wallet returns to gift selection. The stream's existing sheet-aware playback lifecycle remains in control.

| Gift | Diamonds each |
| --- | ---: |
| Rose | 10 |
| Balloons | 50 |
| Heart | 100 |
| Beat Drop | 200 |
| Spotlight | 500 |
| Bouquet | 1,000 |
| Dance Crown | 2,000 |
| Encore | 5,000 |
| Dance Galaxy | 10,000 |

Artwork is code-native SwiftUI/SF Symbols with gradients, including a three-flower bouquet; no third-party raster gift assets are required. Currency and gift artwork can be replaced in WalletComponents.swift without changing prices or actions.

## Service boundary

`AppStore` owns one `WalletStore` shared by profile and live gifts. `WalletServicing` separates purchase and gift operations from views. The current adapter returns explicit unavailable errors. It never starts a payment, records a transaction, credits currency, deducts diamonds, triggers a sent-gift animation or claims delivery. The initial diamond balance is zero and history is empty. No credentials or financial balance are written to UserDefaults or a local file.

Real purchases require this app's configured StoreKit products, storefront prices, verified transactions, transaction finishing/recovery and an authoritative consumable ledger. Real gifts also need authenticated recipients, balance validation, atomic debit/delivery and idempotency. These are not connected by this change. Future service implementations must supply verified balances/history; catalog selections are not evidence of a purchase. No real money or financial account is accessed.

User Agreement is now v1.3 (October 20, 2026), with Teto branding and accurate currency/payment capability wording.

## Files

New: `Teto/Features/Wallet/WalletModels.swift`, `WalletStore.swift`, `WalletComponents.swift`, `WalletView.swift`, `LiveGiftSheetView.swift`.

Integration: `App/AppStore.swift`, `Features/Profile/ProfileView.swift`, `Features/LiveRoom/LiveRoomView.swift`, `LiveRoomSheets.swift`, `LiveRoomStore.swift`. Visible-brand updates additionally affect authentication/agreement, AppRootView, profile settings, party views, chat catalog, live/shorts share text, video removal text and Info.plist. Generated project metadata includes the new Swift files.

## Static checks and remaining verification

Reviewed tier values, nine gifts, shared-wallet wiring, empty balance/history, unavailable-service behavior, English copy, visible-brand changes, retained storage identity and project references. No compilation, typecheck, test, simulator, app or SwiftUI Preview execution was performed. Layout at small/large Dynamic Type, live-sheet→wallet→gift navigation and physical-device behavior remain unverified. This does not establish App Store purchase readiness.
