> 素材数量更新（2026-10-20）：现有 24 段内置舞蹈视频；下文历史记录中的“两段/两部”仅描述当时状态。当前清单及验证范围见 [dance-media-expansion.md](dance-media-expansion.md)。

# Fresh Studio 主题

> 品牌更新（2026-10-20）：用户已确认采用更简洁的「律动 t」：常青绿底、奶白单一连续小写 t，横笔上扬、底部弯曲。此前 Dancing T 舞者图形，以及下文“小写 t 和律动曲线”的旧图标说明均已失效。当前资源与提示见 `Design/Brand/Teto-Rhythm-2026-10-20/`；欢迎、登录页共用 `TetoBrandLockup`，加载页使用同款图标。仅静态检查，未编译或运行。

已按用户选择的 B / Fresh Studio 方向修改原生 SwiftUI 源码。采用奶白底、常青绿主按钮、浅青柠强调色、圆角卡片和舞蹈摄影。应用文字保持英文。

## 覆盖范围

- `DesignSystem/TetoStyle.swift`：全局颜色、主次按钮、表单卡片和头像样式。
- `DesignSystem/FreshStudioArtwork.swift`：自适应背景曲线、入场摄影与渐变遮罩。
- 欢迎和登录：舞蹈工作室摄影、白色标题、绿色胶囊按钮；仍为欢迎 → 同意协议 → 本地进入，不添加设计图中的第三方登录。
- Voice：浅色分类胶囊、舞蹈照片房间卡；原搜索、筛选、工具、创建、进入房间及透明底栏保留。
- Chats：浅色背景、绿色未读标记、浅青柠私信气泡；搜索展开和列表上移行为保留。
- Me 和作者主页：居中头像、浅色曲线背景、胶囊操作、浅青柠钱包入口；沿用实际资料和已有统计，不导入设计图里的粉丝数或余额。
- Wallet 和礼物：薄荷绿钻石、九宫格档位、浅色礼物面板。根据后续要求只使用钻石，移除金币和币种切换。
- Live / Shorts：绿色关注及选中状态，保留全屏视频与浮层结构。语音房和通话保留沉浸式深色背景，调整为相同绿系。

## 色彩

| 用途 | 色值 |
| --- | --- |
| 页面 | #FAFBF7 |
| 主文字 | #142620 |
| 主色 | #126B58 |
| 强调底色 | #DDF4A6 |
| 次要文字 | #4F665C |
| 装饰灰绿 | #8EA99B |
| 输入和弱背景 | #F0F5EE |
| 边线 | #DAE4DB |

小字号次要文字使用较深的灰绿，以改善浅背景可读性。文字采用系统字体，不引入字体依赖。

## 素材和替换位置

选择稿保留于 `Design/Themes/Teto-2026-10-20/b-selected-original.png`。此目录中的 A/B/C/D 图片是设计方案，非应用运行截图；其中旧金币页签等内容已被最新要求覆盖。它们不进入 App 资源。

运行时新增 `Teto/Resources/Assets.xcassets/FreshStudioHero.imageset/fresh-studio-hero.png`，是 AI 生成的成年舞者工作室装饰摄影，用于欢迎、登录和部分房间封面，不作为真实用户头像或可播放视频。精确生成提示和来源记录在主题目录 `hero-provenance.json`。替换同名资源即可更新摄影；曲线背景由 SwiftUI Shape 绘制。

已有舞蹈视频、视频封面、身份数据及本地存储未替换。购买和礼物服务仍未接入，不产生余额充值、扣款或送达结果。

## 验证边界

仅进行了源码、资源 JSON、工程引用和 plist 静态检查。未编译、类型检查、运行 App、启动模拟器或执行测试/Preview。小屏、大字体、键盘、弹层、状态栏及设备上的实际视觉效果仍需运行验证。

## 项目目录更名

项目根目录现为 `/Users/apple/Desktop/Teto`，内部源码目录为 `Teto/`，XcodeGen 和素材来源记录已同步。该阶段工程文件为 `Teto.xcodeproj`（后续已更名为 `Teto.xcodeproj`）；Target/Scheme、Bundle ID、Swift 类型名及 Application Support/Teto 数据路径保留兼容性。


## 第二次对齐参考图（2026-10-20）

上一版主要统一了颜色，仍保留旧布局和卡通头像；本次以 `b-selected-original.png` 的结构重新实现。

- Live 默认打开沉浸式视频流，顶部 Live / Shorts 白色选中胶囊、左侧导入和右侧无边框搜索。Live 与 Shorts 共用稳定播放器；Live 不显示进度条，并提供钻石礼物入口。保留播放失败、生命周期、举报、拉黑、作者和分享流程。
- 底部仍为 Live / Voice / Chats / Me 四项，使用自定义 SwiftUI 细线图标导航，不再受系统 Tab Bar 胶囊外观影响。导航固定在各首页安全区，详情与全屏弹层不添加重复底栏；Voice 底栏保持透明。
- Voice 使用 16pt 外边距、12pt 网格间距、约 190pt 最小卡片高度、16pt 圆角。标题与头像组固定在照片底部；标题菜单保留全部房间、创建、刷新、筛选和工具入口，下拉刷新保留。大字号单列。
- Chats 改为摄影头像、紧凑故事栏、轻分隔、绿色未读标记；标题长按菜单保留筛选和笔记，右侧搜索展开行为不变。
- Me 采用居中头像、曲线背景、三项实际统计、细边 Edit profile、浅青柠 Wallet、Works / Saved / About 和三列视频网格。作品只取本人的导入内容，不把内置影片冒充个人作品；空资料库显示真实空状态。收藏仍使用原有 ID 和全屏播放返回逻辑。
- Wallet 移除大段上部标题留白，使用切面钻石和紧凑九宫格；图中的 Coins 不恢复。礼物图标移除大块彩色底板。
- 欢迎页重新安排标题和 CTA 比例，字体由圆润字形改为系统无衬线。继续保留欢迎后进入协议登录页的流程，不添加图中的未接入第三方登录。

新资源：`Teto/Resources/Assets.xcassets/Studio{HipHop,Latin,Afro,KPop,House,Freestyle}.imageset/image.png`。六张摄影通过内置 image_gen 分别生成并逐张检查，精确提示与原文件位置见 `Design/Themes/Teto-2026-10-20/studio-portraits.json`。用于内置虚构会话头像、默认舞者头像及房间装饰封面；不代表真实账号、不替换私人资料、不作为播放视频。旧资源原文件保留。播放器继续使用两部许可舞蹈影片，因此播放人物与设计图静态摄影并非同一素材。

源码变化集中在 MainTabView、DiscoveryView、ShortsFeedView、ShortVideoPage、PartyComponents、PartyDiscoveryView、ChatComponents、ChatsView、ProfileView、WalletView、WalletComponents、WelcomeView 及共享样式。工程文件已更名为 `Teto.xcodeproj`，XcodeGen 的 name 同步为 Teto；Target/Scheme 与 Bundle ID 不变。

已检查源码分支、资产引用、项目文件和 plist；未编译、类型检查、运行、测试或执行 Preview。当前没有运行截图可做逐像素比对，不能把生成参考图当作实际 App 截图，也不能宣称所有设备下完全一致。需要运行核对安全区、字体、键盘、摄影裁切和导航切换。


## 全应用主题覆盖（2026-10-20）

本次补齐主页面之外的视觉覆盖，不仅修改 Voice。完整文件清单见 `whole-app-theme-files.txt`。

- 共享 `freshStudioPage()` 统一浅色页面的奶白底、墨绿正文、常青绿交互、导航栏及 Sheet 背景。设置、协议、资料编辑、收藏/视频列表、搜索、聊天联系人、发布表单、筛选、举报、拉黑、钱包记录和直播工具面板均接入。
- Live / Shorts 保留全屏视频及透明浮层。礼物、分享使用同系列细线图标，收藏选中为浅青柠；点赞仍保留粉红色语义。评论输入和 More 面板改为浅色，旧紫色播放失败背景改为常青绿曲线背景。直播徽章改为常青绿系列。
- Voice 房间内部改为奶白曲线背景、白色/浅绿聊天气泡、常青绿按钮及一致的头像；话题卡使用有足够对比的深绿渐变。原循环消息频率、历史滚动、成员和退出逻辑保持。
- Chats / 作者私信使用奶白输入区和浅绿气泡，通话采用独立的常青绿曲线背景与圆形按钮；视频通话仍只显示本机摄像头，挂断使用红色语义。
- 个人与作者主页、钱包、礼物和表单使用统一字体、细描边和圆角；资料统计、余额及未接入提示继续来自实际状态，不复制设计图的虚构数字。
- 新 AppIcon 为奶白底、常青绿 t 和浅青柠律动曲线；同一标志用于启动加载画面。原始生成图保存在 `Design/Themes/Teto-2026-10-20/fresh-studio-app-icon-original.png`，提示与来源在 `app-icon-provenance.json`。运行时导出为不含 Alpha 的 1024×1024 PNG，位置为 `Teto/Resources/Assets.xcassets/AppIcon.appiconset/AppIcon.png`；`TetoMark.imageset` 为界面用副本。使用内置 image_gen 生成，sips 仅执行尺寸导出。

保留四项底部导航、Voice 首页透明底栏、舞蹈视频及其许可记录、钻石唯一货币、本地数据和旧收藏 ID。未增加在线认证、实时消息、语音连接或购买能力。

本轮仅进行源码差异、资源 JSON/尺寸、英文文案和 plist 检查。没有编译、类型检查、运行、测试、模拟器或 SwiftUI Preview，也没有新的运行截图。不能据此声称设备效果与参考图逐像素一致。系统权限、Photos 选择器和系统分享页保留 iOS 自身外观。


## 恢复原直播入口（2026-10-20）

按用户要求撤销 Live 复用短视频流的入口变更。上文“Live 默认打开沉浸式视频流”的描述已失效：当前 Live 使用原有 `VideoLibraryView(embedded: true)`，卡片进入独立 `LiveRoomView`；Live 搜索在关闭搜索页后进入同一直播间页面。Shorts 仍使用原短视频上下滑动界面。恢复 Live 列表的浅色顶部与底部导航，保留 Fresh Studio 主题、直播间全屏背景及原有操作，不改播放器、收藏和用户数据。修改文件为 `DiscoveryView.swift` 和 `MainTabView.swift`。仅检查源码路由，未编译或运行。


## Voice 底栏更新（2026-10-20）

按最新要求，Voice 首页底部导航改为与 Shorts 相同的深绿色半透明渐变，选中项浅青柠、其余项白色，底色延伸至底部安全区。此前“Voice 底栏保持全透明”的描述失效。仅底栏采用深色样式，Voice 页正文仍为浅色；四项导航的位置和点击区域不变。源码静态检查，未编译或运行。
