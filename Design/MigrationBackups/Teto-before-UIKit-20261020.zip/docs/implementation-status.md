## 2026-10-20 — Creation and community update

Live and Shorts now open separate creation forms instead of opening Photos immediately. New content is stored in a durable pending-review outbox, visible under Me > Pending review and excluded from discovery; no upload or review service is connected. Per-video like/save baselines are about 10–30. Comment reports are available in Shorts, Live and voice rooms. The eight built-in parties have disjoint 3–10-member rosters and display member counts rather than large heat figures. This supersedes earlier direct-import creation and shared-avatar behavior below. Details and source inventory: [creation-review-and-community.md](creation-review-and-community.md).

# Teto implementation status

Current product: English-language dance social frontend, iOS 17+, four tabs. The latest user request supersedes the earlier commerce/art/social room variants. See `live-room.md` for the current source inventory and replacement points; older records are preserved under `archive/`.

## Implemented in source

- Brand redesign (2026-10-20): the user-selected Rhythm t identity uses a single ivory lowercase-t silhouette on evergreen, with a rising crossbar and curved foot. This replaces the earlier Dancing T figure. Welcome and sign-in share the existing native `TetoBrandLockup`; the loading mark matches the installed icon. Selected artwork, exact image-generation prompts and runtime mappings are recorded in `Design/Brand/Teto-Rhythm-2026-10-20/`. Static source/resource and image inspection only; no build or runtime verification.

- Second dance-media batch: 12 additional Pexels films, 24 bundled clips total. Live and Shorts independently shuffle once per AppStore session with newest collection first and the original two clips last. Imported dances retain their existing priority; saved collection IDs/order remain compatible. Source/cover/provenance and static media checks recorded in `dance-media-expansion.md`; no app build or runtime verification.

- Dance media expanded by 10 licensed Pexels clips (12 total), with covers, English descriptions, stable IDs, source originals, hashes and five-timestamp visual review records. Live and Shorts share the expanded catalog. See `dance-media-expansion.md`. Media/static inspection only; no app build or runtime verification.

- Live restoration (2026-10-20): Live opens the original embedded video/room library; room cards and Live search results open `LiveRoomView`. Shorts alone uses the swipe feed at the main entry. Fresh Studio styling remains, with light Live list navigation and immersive Shorts navigation. This supersedes the earlier shared Live/Shorts feed design. No build or runtime verification was performed.

- Whole-app Fresh Studio coverage now includes all light utility/form sheets, live comments/options, voice-room interiors, call backgrounds, creator conversations, gift icon styling and a new matching AppIcon/loading mark. See the whole-app section of `fresh-studio-theme.md` and `whole-app-theme-files.txt`. Static inspection only; no build or runtime visual verification.

- Fresh Studio reference alignment now includes custom four-tab chrome, a Live room-card landing page, distinct photographic party cards/avatars, compact inbox, profile collection tabs and faceted diamond artwork. See the second-alignment section of `fresh-studio-theme.md`. Source and assets only; runtime visual equivalence has not been verified.

- Fresh Studio is the selected visual theme: cream surfaces, evergreen buttons, lime accents, dance photography, rounded cards and coordinated wallet/gift styling. Existing navigation and data identities are preserved. The wallet now uses diamonds only. See `fresh-studio-theme.md` for files, resource provenance and validation limits.

- Visible branding is now Teto, including the installed display name, welcome, agreement, profile, party header, share text and camera permission. Existing identifiers and storage root stay intact. Me > Wallet includes a single Diamonds balance, nine USD recharge packs and an empty transaction-history screen. The live gift sheet offers nine priced gifts, quantity/total, and a wallet shortcut. Purchase/gift adapters explicitly fail as unavailable, with no fake credit, deduction or delivery. See `wallet-and-gifts.md`.

- Person/group chats and creator private conversations have Voice call and Video call buttons. Full-screen call layouts reuse recipient avatars/names; microphone/speaker buttons change visual state and End returns to the same conversation. Video uses an actual local AVCaptureSession with front/back switching, permission/error states, and inactive/exit teardown. No audio capture, recording, signaling or network call is implemented. User Agreement v1.1 and About now describe camera permission accurately. See `chat-call-screens.md`.

- Startup now follows Welcome → One-tap sign in → main tabs on each cold launch. The agreement checkbox starts unchecked, cannot be bypassed by browsing, and opening the terms does not accept them. Consent version/time persist atomically through an optional library field before navigation. Me > Settings opens the same User Agreement text and acceptance record; old email/password entry is removed. See `welcome-and-agreement.md`.

- Live's existing More menu and a new Shorts More button below Share provide shared Report video and Block creator actions. Reports are saved locally with an explicit not-submitted state. Blocking persists by creator ID, filters discovery/search/saved videos and creator chats, and removes the local follow without deleting media or drafts. Me > Blocked creators supports undo and lists local reports. See `content-safety.md`.

- Live and Shorts author avatars now open a shared full-screen creator profile: cover/avatar/name, Likes/Following/Followers, biography, IP region, Follow/Message and a three-column dance-video grid. Unknown statistics use a dash and unknown IP uses Unavailable. Message opens a full-screen chat window with the author avatar/name, private draft bubble and bottom composer. Creator follows, per-author private message drafts and opened conversation records persist locally via optional schema fields. These conversations appear in Chats with search/pin/draft filtering and reopen the same author chat window; older saved drafts are included automatically. Work tiles play full screen and return to the profile. See `creator-profile.md`.

- Saved-video cards now open a full-screen cover reusing ShortsFeedView and ShortVideoPage, with the selected collection ID, automatic 1× looping playback, floating controls/comments and an explicit back button that stops playback before dismissing to the existing collection. Collection playback includes videos longer than three minutes and keeps an unsaved current video open until exit. Personal-video management still uses direct view destinations; duplicate UUID destinations remain removed. Source inspection only; device behavior is not yet verified.

- Chats now has a screenshot-inspired white inbox, ten English dance conversations, avatar notes, search, unread/pinned filters and conversation details. Read state, pin overrides and reply drafts persist locally; no message transport is connected. See `dance-chats.md`.

- Voice now opens an English dance party discovery page: a cream page with photographic two-column cards, category/search/filter, local party creation, an immersive room interior and the original four-tab navigation with a transparent background. Asset/interaction details: `party-discovery.md` and `voice-party-room.md`. The room interior has authored dance conversations (1–3 new lines every random 1–2 seconds, looping through 48 English phrases with a 200-entry cap), a member rail, local follow/private notes, native sharing and explicit unavailable voice-connection feedback. Chat flow pauses for sheets, backgrounding and exit; history reading suspends auto-scroll.

- Screenshot-inspired Shorts layout: left video import, right search, lower caption, five-action rail and constant-speed floating English comments. See `shorts-layout.md` for interaction boundaries and file inventory.

- English UI across entry, Live, Shorts, dance rooms, Voice, Chats and Me; prior Chinese room copy and staging labels removed.
- Shared two-film dance catalog for Live and Shorts; seven non-dance bundled videos, covers and original source videos removed.
- Full-screen dance rooms with stable AVPlayer ownership, local/HTTPS/cover interfaces, explicit 1× looping, error/retry, mute and lifecycle management.
- 96 authored English dance comments cycling at a randomly selected rate of 1–5 comments per second; stable IDs, bounded history, a Chat flow switch and cancellation on inactive/paused/failed/covered states. No server messages or online viewer counts are implied by the sequence.
- Keyboard-aware comments, local follow/likes, floating hearts, gift selection, native share and English practice/community sheets.
- Local imports/favorites/profile/drafts continue to save atomically. Optional `isDance` preserves old snapshot decoding; old uncategorized personal imports remain in Me and can be explicitly added to the dance feed.
- Runtime artwork uses the retained dance covers. Source/license credits remain accessible.

## Still not connected

Online authentication, public uploads/feeds, real-time broadcasting, voice RTC, messages/calls, remote account data, payments and gift delivery. These operations have not been reported as completed.

## Inspections performed

Read/inspected source and media provenance, visually inspected the retained dance covers, scanned app-owned text for Chinese/retired staging terms, inspected references, generated Xcode project metadata and checked plist/project format. Original reference screenshots and the retained dance source downloads are preserved outside the app target. The seven non-dance source downloads were deleted; their provenance records remain.

No build, compiler/typecheck, simulator, app execution, SwiftUI preview or tests were run. Actual layout, keyboard, lifecycle, comment loop/scrolling, accessibility and persisted-library compatibility remain unverified on a device.
