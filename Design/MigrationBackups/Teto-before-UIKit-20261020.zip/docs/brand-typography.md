# Teto 品牌字标与标题

当前图标使用 Design/Brand/Logo-v6 的青绿色流动背景版本；AppIcon 与 TetoMark 为相同的 1024 × 1024 不透明图像。

Teto 艺术字由 image_gen.imagegen 生成，原稿与完整提示词位于 Design/Brand/Wordmark-v1。Assets 中的 TetoWordmark 保留原始透明度，采用 template 渲染，在照片上使用奶白，在浅背景上使用常青绿。欢迎、登录和加载页引用共享组件。

标题字体统一位于 TetoStyle.swift 的 TetoTypography：主标题采用 iOS 自带 Avenir Next Bold Italic，次级标题采用 Demi Bold，导航与 Live/Shorts 标题采用 Demi Bold Italic。通过 Font.custom(relativeTo:) 跟随 Dynamic Type；字标通过 ScaledMetric 缩放，并提供 Teto 无障碍名称。正文、评论、输入框及系统图标保留原有字体。原生导航标题使用 principal 工具栏项，保留导航标题语义和返回行为。

未编译、运行、执行 Preview 或测试。仍需用户在设备上确认大字体、长标题以及各页面的最终排版。
