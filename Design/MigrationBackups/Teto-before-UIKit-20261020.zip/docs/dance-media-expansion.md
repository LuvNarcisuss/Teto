# 舞蹈素材扩充 · 2026-10-20

新增 10 段实际舞蹈视频，内置总数由 2 增至 12。Live 列表、搜索、直播间和 Shorts 共用 DanceVideoCatalog，因此无需新增入口。保留原有两段 ID、收藏数据及用户导入内容。

| 标题 | 作者 | 时长 | 来源 |
| --- | --- | --- | --- |
| Hip hop in motion | cottonbro studio | 40.72s | [Pexels 7958175](https://www.pexels.com/video/a-young-man-dancing-to-hip-hop-music-7958175/) |
| Crew rhythm | ANTONI SHKRABA production | 11.44s | [Pexels 8688877](https://www.pexels.com/video/people-dancing-hip-hop-8688877/) |
| Own the eight-count | Polina Tankilevitch | 3.92s | [Pexels 3873100](https://www.pexels.com/video/a-young-woman-dancing-hip-hop-3873100/) |
| Move together | cottonbro studio | 10.24s | [Pexels 10264814](https://www.pexels.com/video/two-women-dancing-hip-hop-10264814/) |
| Partnered lines | MART PRODUCTION | 23.68s | [Pexels 8462487](https://www.pexels.com/video/man-and-woman-dancing-ballet-8462487/) |
| Studio joy | Kampus Production | 22.48s | [Pexels 8956471](https://www.pexels.com/video/a-woman-dancing-in-a-studio-8956471/) |
| Practice partners | MART PRODUCTION | 15.04s | [Pexels 7480483](https://www.pexels.com/video/man-and-woman-dancing-together-7480483/) |
| After-dark groove | Tima Miroshnichenko | 10.64s | [Pexels 5805069](https://www.pexels.com/video/vertical-video-of-a-woman-dancing-5805069/) |
| Contemporary flow | Antoni Shkraba | 28.84s | [Pexels 7571002](https://www.pexels.com/video/woman-dancing-in-a-studio-7571002/) |
| Contemporary floorwork | MART PRODUCTION | 19.60s | [Pexels 7322867](https://www.pexels.com/video/ballerinas-dancing-on-a-dance-studio-7322867/) |

运行时新增视频合计约 27.6 MiB（另有封面）。使用 H.264/yuv420p、最长边 1280px、原始帧率和时长、1×速度；沿用无音轨策略，不加入未授权音乐。原始下载文件位于 Design/SourceMedia，压缩文件和封面位于 Teto/Resources/DanceMedia。

来源页面均标明 Pexels License，许可页面：https://www.pexels.com/license/ 。作者作为影片来源署名，不表示作者或画面人物使用/代言本 App。原始下载 URL、文件 SHA-256、编码参数、时长与审阅时间点已写入 manifest.json。

每段检查了 5%、25%、50%、75%、95% 时间点；联系图位于 Design/SourceMedia/Review-2026-10-20。确认被选画面为舞蹈动作，未发现非英文字幕或水印。一段候选因背景出现非英文疏散标识被排除，项目未保存该候选视频。代表帧检查不等于逐帧审核。

资源检查包括编码格式、时长/帧数、文件哈希、封面、目录唯一 ID 和 Xcode 资源引用。未编译、运行 App、启动模拟器或执行测试/SwiftUI Preview。真实直播与网络服务接入状态不变。

## 第二批扩充与推荐顺序 · 2026-10-20

本次再新增 12 段，内置总数达到 24 段。应用每次启动分别为 Live / Shorts 生成随机顺序：本批 12 段在前，上批 10 段随后，最早 2 段最后；批次内部随机。默认情况下首条内置素材不同。排序存在 AppStore 生命周期内，收藏、点赞和切换页面不会重新洗牌；用户新导入的舞蹈仍保持原有置顶行为。收藏和作者作品显式播放列表不受 Shorts 推荐排序影响。

原有 ID、收藏键和本地媒体数据目录不变。修改涉及 DanceVideoCatalog、AppStore、ShortsFeedView、ShortsInteractionStore、资源目录、来源登记和 Xcode 工程引用。

| 标题 | 作者 | 时长 | 来源 |
| --- | --- | --- | --- |
| Urban footwork | Yaroslav Shuraev | 50.04s | [Pexels 8027525](https://www.pexels.com/video/woman-doing-breakdance-8027525/) |
| Street power | Allan Mas | 6.20s | [Pexels 5362370](https://www.pexels.com/video/young-guy-doing-break-dance-on-the-street-5362370/) |
| Under the bridge | Kampus Production | 24.00s | [Pexels 8715155](https://www.pexels.com/video/a-woman-doing-break-dance-on-the-street-8715155/) |
| Court session | Marc Espejo | 35.38s | [Pexels 6548168](https://www.pexels.com/video/a-man-dancing-6548168/) |
| Studio chemistry | Shuttercraftsman | 17.76s | [Pexels 31889677](https://www.pexels.com/video/dynamic-dance-routine-in-modern-studio-setting-31889677/) |
| Together on the beat | Kampus Production | 23.24s | [Pexels 8956295](https://www.pexels.com/video/women-dancing-in-the-studio-8956295/) |
| Follow the feeling | Pavel Danilyuk | 52.22s | [Pexels 6939884](https://www.pexels.com/video/a-woman-dancing-in-the-dance-studio-6939884/) |
| A shared rhythm | KoolShooters | 12.80s | [Pexels 7689096](https://www.pexels.com/video/couple-dancing-together-7689096/) |
| Salsa in the sunshine | RDNE Stock project | 10.72s | [Pexels 8249922](https://www.pexels.com/video/woman-wearing-floral-dress-dancing-with-a-man-8249922/) |
| Glitter and groove | Mikhail Nilov | 23.72s | [Pexels 6834067](https://www.pexels.com/video/a-woman-dancing-in-the-studio-6834067/) |
| Ballet practice | Budgeron Bach | 9.32s | [Pexels 5138501](https://www.pexels.com/video/a-ballet-class-going-on-in-a-dance-studio-5138501/) |
| Street crew energy | Tima Miroshnichenko | 9.64s | [Pexels 5561275](https://www.pexels.com/video/people-dancing-outdoors-5561275/) |

本批运行时视频约 44.6 MiB。保留原始帧率、帧数和 1× 时间轴；H.264/yuv420p，最长边1280px，无音轨，不添加音乐。代表帧检查覆盖每段5%、25%、50%、75%、95%时间点，审阅联系图在 Review-2026-10-20-B；排除了一段动作不够明确的摄影棚候选。许可、作者、原文件映射、SHA256记录在manifest。未编译、运行App、启动模拟器或执行测试。

最终静态核对：24 个唯一 ID、24 个视频及封面与 Xcode 引用一致；新增 12 段源文件/运行时 SHA256 一致，帧率、帧数及时长保持；31889677 原文件缺少 nb_frames 元数据，实际解码读取为 444 帧，与运行时相符。project.pbxproj 和 Info.plist 的 plutil 检查通过。
