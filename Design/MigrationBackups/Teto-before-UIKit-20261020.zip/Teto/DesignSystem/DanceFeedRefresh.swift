import SwiftUI

private struct DanceFeedRefresh: ViewModifier {
    let enabled: Bool
    let action: () async -> Void
    @ViewBuilder func body(content: Content) -> some View {
        if enabled {
            content.refreshable { await action() }
                .scrollBounceBehavior(.always, axes: .vertical)
        } else { content }
    }
}

extension View {
    func danceFeedRefresh(enabled: Bool, action: @escaping () async -> Void) -> some View {
        modifier(DanceFeedRefresh(enabled: enabled, action: action))
    }
}
