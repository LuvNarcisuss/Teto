import SwiftUI

enum TetoStyle {
    // Fresh Studio palette. Retain this type name for existing feature code.
    static let background = Color(red: 250/255, green: 251/255, blue: 247/255)
    static let ink = Color(red: 20/255, green: 38/255, blue: 32/255)
    static let emerald = Color(red: 18/255, green: 107/255, blue: 88/255)
    static let lime = Color(red: 221/255, green: 244/255, blue: 166/255)
    static let muted = Color(red: 79/255, green: 102/255, blue: 92/255)
    static let sage = Color(red: 142/255, green: 169/255, blue: 155/255)
    static let soft = Color(red: 240/255, green: 245/255, blue: 238/255)
    static let mist = Color(red: 231/255, green: 247/255, blue: 241/255)
    static let aqua = Color(red: 67/255, green: 190/255, blue: 174/255)
    static let chromeGradient = LinearGradient(colors: [background, mist, background],
                                               startPoint: .topLeading, endPoint: .bottomTrailing)
    static let card = Color.white
    static let line = Color(red: 218/255, green: 228/255, blue: 219/255)
    static let night = Color(red: 10/255, green: 26/255, blue: 21/255)
    static let accentGradient = LinearGradient(colors: [Color(red: 15/255, green: 126/255, blue: 103/255), emerald], startPoint: .topLeading, endPoint: .bottomTrailing)
}

/// Evergreen brand badge and ivory wordmark for the entry photography.
struct TetoBrandLockup: View {
    var compact = false
    @ScaledMetric(relativeTo: .largeTitle) private var markSize: CGFloat = 56

    var body: some View {
        ViewThatFits(in: .horizontal) {
            HStack(spacing: 12) { mark; wordmark }
            VStack(alignment: .leading, spacing: 8) { mark; wordmark }
        }
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("Teto")
    }

    private var mark: some View {
        Image("TetoMark")
            .resizable()
            .scaledToFit()
            .frame(width: markSize * (compact ? 0.8 : 1),
                   height: markSize * (compact ? 0.8 : 1))
            .clipShape(RoundedRectangle(cornerRadius: markSize * (compact ? 0.2 : 0.25),
                                       style: .continuous))
            .accessibilityHidden(true)
    }

    private var wordmark: some View {
        TetoWordmark(compact: compact).foregroundStyle(TetoStyle.background)
    }
}

struct PrimaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline).padding(.horizontal, 18).padding(.vertical, 12)
            .frame(maxWidth: .infinity, minHeight: 52)
            .foregroundStyle(enabled ? Color.white : TetoStyle.muted)
            .background {
                Capsule().fill(enabled ? AnyShapeStyle(TetoStyle.accentGradient) : AnyShapeStyle(TetoStyle.line))
            }
            .overlay(Capsule().strokeBorder(.white.opacity(enabled ? 0.18 : 0), lineWidth: 1))
            .opacity(configuration.isPressed ? 0.78 : 1)
            .shadow(color: TetoStyle.emerald.opacity(enabled ? 0.10 : 0), radius: 10, y: 4)
            .contentShape(Capsule())
    }
}

struct SecondaryButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.headline).padding(.horizontal, 18).padding(.vertical, 12)
            .frame(maxWidth: .infinity, minHeight: 50)
            .foregroundStyle(enabled ? TetoStyle.ink : TetoStyle.muted)
            .background(configuration.isPressed ? TetoStyle.soft : TetoStyle.card, in: Capsule())
            .overlay(Capsule().strokeBorder(TetoStyle.line, lineWidth: 1))
            .opacity(enabled ? 1 : 0.55)
            .contentShape(Capsule())
    }
}

struct ScreenHeading: View {
    let title: String
    let subtitle: String
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(TetoTypography.largeTitle).tracking(-1.3).foregroundStyle(TetoStyle.ink)
            Text(subtitle).font(.subheadline).foregroundStyle(TetoStyle.muted)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

struct StatusPill: View {
    let text: String
    var dark = false
    var body: some View {
        Text(text).font(.caption.weight(.semibold))
            .padding(.horizontal, 10).padding(.vertical, 6)
            .foregroundStyle(dark ? Color.white : TetoStyle.ink)
            .background(dark ? Color.black.opacity(0.65) : TetoStyle.lime, in: Capsule())
    }
}

struct ServiceNote: View {
    let symbol: String
    let text: String
    var body: some View {
        Label(text, systemImage: symbol)
            .font(.caption).foregroundStyle(TetoStyle.muted)
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.horizontal, 4).padding(.vertical, 8)
    }
}

struct EmptyLibraryView: View {
    let title: String
    let description: String
    let symbol: String
    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: symbol).font(.system(size: 28, weight: .medium))
                .foregroundStyle(TetoStyle.emerald)
                .frame(width: 64, height: 64)
                .background(TetoStyle.lime.opacity(0.45), in: RoundedRectangle(cornerRadius: 22))
                .accessibilityHidden(true)
            Text(title).font(TetoTypography.subsection).foregroundStyle(TetoStyle.ink)
            Text(description).font(.subheadline).foregroundStyle(TetoStyle.muted)
                .multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity).padding(20)
    }
}

struct ProfileAvatar: View {
    let symbol: String
    var size: CGFloat = 96
    var body: some View {
        Group {
            if symbol == "figure.dance" {
                Image("Portrait3").resizable().scaledToFill()
            } else {
                Image(systemName: symbol).font(.system(size: size * 0.38, weight: .medium))
                    .foregroundStyle(TetoStyle.lime)
                    .frame(width: size, height: size)
                    .background(TetoStyle.accentGradient)
            }
        }
        .frame(width: size, height: size).clipShape(Circle()).accessibilityHidden(true)
    }
}

struct FormError: View {
    let message: String?
    var body: some View {
        if let message {
            Label(message, systemImage: "exclamationmark.circle")
                .font(.footnote).foregroundStyle(.red)
                .accessibilityLabel("Error: \(message)")
        }
    }
}

extension View {
    func tetoCard() -> some View {
        padding(18).background(TetoStyle.card, in: RoundedRectangle(cornerRadius: 16))
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(TetoStyle.line.opacity(0.65), lineWidth: 0.75))
            .shadow(color: TetoStyle.ink.opacity(0.025), radius: 10, y: 4)
    }
}


private struct FreshStudioPageModifier: ViewModifier {
    var drawsBackground: Bool
    func body(content: Content) -> some View {
        content
            .scrollContentBackground(.hidden)
            .background {
                if drawsBackground { FreshStudioPageBackground().ignoresSafeArea() }
            }
            .foregroundStyle(TetoStyle.ink)
            .tint(TetoStyle.emerald)
            .toolbarBackground(TetoStyle.chromeGradient, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.light, for: .navigationBar)
            .preferredColorScheme(.light)
            .presentationBackground { FreshStudioPageBackground() }
    }
}

extension View {
    func freshStudioPage(drawsBackground: Bool = true) -> some View {
        modifier(FreshStudioPageModifier(drawsBackground: drawsBackground))
    }
}


/// Shared title family: energetic display headings, clear secondary headings.
/// Avenir Next is supplied by iOS; no downloaded fonts or registration is needed.
enum TetoTypography {
    static let hero = Font.custom("AvenirNext-BoldItalic", size: 44, relativeTo: .largeTitle)
    static let largeTitle = Font.custom("AvenirNext-BoldItalic", size: 34, relativeTo: .largeTitle)
    static let title = Font.custom("AvenirNext-BoldItalic", size: 28, relativeTo: .title)
    static let section = Font.custom("AvenirNext-DemiBold", size: 22, relativeTo: .title2)
    static let subsection = Font.custom("AvenirNext-DemiBold", size: 20, relativeTo: .title3)
    static let headline = Font.custom("AvenirNext-DemiBold", size: 17, relativeTo: .headline)
    static let tabTitle = Font.custom("AvenirNext-DemiBoldItalic", size: 16, relativeTo: .subheadline)
    static let navigation = Font.custom("AvenirNext-DemiBoldItalic", size: 18, relativeTo: .headline)
}

/// Raster lettering has its own spoken name; template tint supports light and dark surfaces.
struct TetoWordmark: View {
    var compact = false
    @ScaledMetric(relativeTo: .largeTitle) private var width: CGFloat = 132

    var body: some View {
        Image("TetoWordmark")
            .renderingMode(.template)
            .resizable()
            .scaledToFit()
            .frame(width: width * (compact ? 0.8 : 1), height: width * (compact ? 0.4 : 0.5))
            .accessibilityLabel("Teto")
    }
}

extension View {
    /// Keep the native navigation/back behavior and a scalable custom title.
    func tetoNavigationTitle(_ title: String) -> some View {
        navigationTitle(title)
            .toolbar {
                if !title.isEmpty {
                    ToolbarItem(placement: .principal) {
                        Text(title)
                            .font(TetoTypography.navigation)
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                            .accessibilityAddTraits(.isHeader)
                    }
                }
            }
    }
}
