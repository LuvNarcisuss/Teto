import SwiftUI

/// Decorative imagery only: never a claimed broadcast, person or playable clip.
struct EditorialImage: View {
    let name: String
    var body: some View {
        GeometryReader { geometry in
            Group {
                if name == "DanceStory", let clip = DanceVideoCatalog.entries.first {
                    LocalVideoCover(url: clip.resourceURL(fileExtension: "jpg"))
                } else {
                    Image(name).resizable().scaledToFill()
                }
            }.frame(width: geometry.size.width, height: geometry.size.height).clipped()
        }.accessibilityHidden(true)
    }
}

struct Eyebrow: View {
    let text: String
    var color: Color = TetoStyle.muted
    var body: some View {
        Text(text.uppercased()).font(.caption2.weight(.bold)).tracking(2).foregroundStyle(color)
    }
}

struct FilterChip: View {
    let title: String
    var symbol: String? = nil
    let selected: Bool
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let symbol { Image(systemName: symbol).font(.caption) }
                Text(title).font(.subheadline.weight(.semibold))
            }
            .padding(.horizontal, 17).frame(minHeight: 44)
            .foregroundStyle(selected ? Color.white : TetoStyle.muted)
            .background(selected ? TetoStyle.emerald : TetoStyle.soft, in: Capsule())
            .overlay(Capsule().strokeBorder(selected ? Color.clear : TetoStyle.line, lineWidth: 1))
        }.buttonStyle(.plain)
            .accessibilityAddTraits(selected ? .isSelected : [])
    }
}

struct CircleAction: View {
    let symbol: String
    var dark = false
    var body: some View {
        Image(systemName: symbol).font(.system(size: 18, weight: .regular))
            .foregroundStyle(dark ? .white : TetoStyle.ink)
            .frame(width: 44, height: 44)
            .background(symbol == "magnifyingglass" ? Color.clear : (dark ? Color.white.opacity(0.14) : TetoStyle.card), in: Circle())
    }
}

struct SectionTitle: View {
    let title: String
    var detail: String? = nil
    var body: some View {
        HStack(alignment: .firstTextBaseline) {
            Text(title).font(TetoTypography.subsection).tracking(-0.5).foregroundStyle(TetoStyle.ink)
            Spacer(minLength: 12)
            if let detail { Text(detail).font(.caption).foregroundStyle(TetoStyle.muted) }
        }
    }
}

struct EditorialHero: View {
    var image = "DanceStory"
    let eyebrow: String
    let title: String
    let subtitle: String
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            EditorialImage(name: image)
            LinearGradient(colors: [.clear, .black.opacity(0.22), .black.opacity(0.8)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 10) {
                Eyebrow(text: eyebrow, color: TetoStyle.lime)
                Text(title).font(TetoTypography.largeTitle).tracking(-1.3)
                Text(subtitle).font(.subheadline).foregroundStyle(.white.opacity(0.88))
            }.foregroundStyle(.white).padding(24)
        }
        .frame(height: 310)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}
