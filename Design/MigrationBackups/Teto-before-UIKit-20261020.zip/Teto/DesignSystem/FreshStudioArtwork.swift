import SwiftUI

/// Quiet, static movement around the page edges; never competes with content.
struct FreshStudioPageBackground: View {
    @Environment(\.colorSchemeContrast) private var contrast

    var body: some View {
        ZStack {
            LinearGradient(colors: [TetoStyle.background, TetoStyle.mist, TetoStyle.background],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            RadialGradient(colors: [TetoStyle.aqua.opacity(0.20), .clear],
                           center: .topTrailing, startRadius: 0, endRadius: 480)
            RadialGradient(colors: [TetoStyle.lime.opacity(0.32), .clear],
                           center: .bottomLeading, startRadius: 0, endRadius: 460)
            StudioFlowRibbon()
                .fill(LinearGradient(colors: [TetoStyle.aqua.opacity(0.22), TetoStyle.mist.opacity(0.12), TetoStyle.sage.opacity(0.14)],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
            StudioFlowRibbon().rotation(.degrees(180))
                .fill(LinearGradient(colors: [TetoStyle.lime.opacity(0.30), TetoStyle.aqua.opacity(0.10)],
                                     startPoint: .bottomLeading, endPoint: .topTrailing))
            StudioFlowRibbon().stroke(Color.white.opacity(0.65), lineWidth: 1)
            if contrast == .increased { TetoStyle.background.opacity(0.65) }
        }
        .clipped()
        .allowsHitTesting(false)
        .accessibilityHidden(true)
    }
}

/// An airy accent for profile and wallet headers, with a readable central area.
struct FreshStudioBackdrop: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [TetoStyle.mist, TetoStyle.background, TetoStyle.lime.opacity(0.45)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            StudioRibbon().fill(LinearGradient(colors: [TetoStyle.aqua.opacity(0.22), TetoStyle.lime.opacity(0.35)],
                                               startPoint: .topLeading, endPoint: .bottomTrailing))
            StudioRibbon().stroke(.white.opacity(0.7), lineWidth: 1)
        }.clipped().allowsHitTesting(false).accessibilityHidden(true)
    }
}

/// Proportional curves stay near the perimeter on phones and wider layouts.
private struct StudioFlowRibbon: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: -r.width * 0.12, y: r.height * 0.04))
        p.addCurve(to: CGPoint(x: r.width * 1.12, y: r.height * 0.26),
                   control1: CGPoint(x: r.width * 0.26, y: -r.height * 0.14),
                   control2: CGPoint(x: r.width * 0.58, y: r.height * 0.40))
        p.addLine(to: CGPoint(x: r.width * 1.12, y: r.height * 0.36))
        p.addCurve(to: CGPoint(x: -r.width * 0.12, y: r.height * 0.17),
                   control1: CGPoint(x: r.width * 0.62, y: r.height * 0.50),
                   control2: CGPoint(x: r.width * 0.25, y: -r.height * 0.06))
        p.closeSubpath()
        return p
    }
}

private struct StudioRibbon: Shape {
    func path(in r: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: 0, y: r.height * 0.38))
        p.addCurve(to: CGPoint(x: r.width, y: r.height * 0.08), control1: CGPoint(x: r.width * 0.35, y: -r.height * 0.12), control2: CGPoint(x: r.width * 0.65, y: r.height * 1.12))
        p.addLine(to: CGPoint(x: r.width, y: r.height * 0.24))
        p.addCurve(to: CGPoint(x: 0, y: r.height * 0.49), control1: CGPoint(x: r.width * 0.67, y: r.height * 1.08), control2: CGPoint(x: r.width * 0.36, y: r.height * 0.03))
        p.closeSubpath()
        return p
    }
}

struct FreshStudioEntryBackground: View {
    var body: some View {
        GeometryReader { bounds in
            Image("FreshStudioHero").resizable().scaledToFill()
                .frame(width: bounds.size.width, height: bounds.size.height).clipped()
                .overlay {
                    LinearGradient(stops: [.init(color: .black.opacity(0.22), location: 0),
                                           .init(color: .clear, location: 0.22),
                                           .init(color: TetoStyle.night.opacity(0.36), location: 0.50),
                                           .init(color: TetoStyle.night.opacity(0.78), location: 1)],
                                   startPoint: .top, endPoint: .bottom)
                }
        }.allowsHitTesting(false).accessibilityHidden(true)
    }
}

// Bundled photographic portraits; provenance is in Design/SourcePortraits/manifest.json.
// These assets never replace a user's imported photo.
enum FreshStudioPhotos {
    static func avatar(_ asset: String) -> String {
        let mapping = ["ChatAvatar1": "Portrait1", "ChatAvatar2": "Portrait2",
                       "ChatAvatar3": "Portrait3", "ChatAvatar4": "Portrait4",
                       "ChatAvatar5": "LifestyleMusicBreak", "ChatAvatar6": "Portrait6",
                       "ChatAvatar7": "LifestyleBalletShoes", "ChatAvatar8": "LifestyleSneakerDay",
                       "PartyAvatar1": "Portrait1", "PartyAvatar2": "Portrait2",
                       "PartyAvatar3": "Portrait3", "PartyAvatar4": "Portrait4"]
        return mapping[asset] ?? asset
    }
    /// Photographic artwork for frontend creator identities, not a claim about
    /// the credited filmmaker's identity. Preserve one choice across entry points.
    static func creatorAvatar(for id: String) -> String {
        if id == "local-owner" { return "Portrait3" }
        let seed = id.utf8.reduce(UInt64(14695981039346656037)) {
            ($0 ^ UInt64($1)) &* 1099511628211
        }
        let choices = ["Portrait1", "Portrait2", "Portrait3", "Portrait4", "Portrait5", "Portrait6",
                       "Portrait7", "Portrait8", "LifestyleMusicBreak", "LifestyleSneakerDay", "LifestyleBalletShoes"]
        return choices[Int(seed % UInt64(choices.count))]
    }

    static func story(for id: String) -> String {
        let stories = ["maya": "LifestyleStudioPractice", "leo": "LifestyleStreetCoffee",
                       "zoe": "LifestyleCoffeeChat", "noah": "LifestyleSneakerDay",
                       "aria": "LifestyleMusicBreak", "finn": "LifestyleParkWalk"]
        return stories[id] ?? "LifestyleDanceRehearsal"
    }

    static func cover(for room: PartyRoom) -> String {
        let covers = ["hip-hop-crew": "LifestyleStreetCoffee", "k-pop-combo": "LifestyleStudioPractice",
                      "jazz-afterhours": "LifestyleCoffeeChat", "freestyle-circle": "LifestyleDanceRehearsal",
                      "dance-camera": "LifestyleMusicBreak", "ballet-circle": "LifestyleBalletShoes",
                      "house-friends": "LifestyleSneakerDay", "practice-break": "LifestyleParkWalk"]
        return covers[room.id] ?? "LifestyleStudioPractice"
    }

}


struct FreshStudioImmersiveBackdrop: View {
    var body: some View {
        ZStack {
            LinearGradient(colors: [TetoStyle.emerald, TetoStyle.night], startPoint: .topLeading, endPoint: .bottomTrailing)
            StudioRibbon().fill(TetoStyle.lime.opacity(0.10))
            StudioRibbon().stroke(TetoStyle.sage.opacity(0.16), lineWidth: 1)
                .scaleEffect(x: -1, y: 0.8)
        }.clipped().allowsHitTesting(false).accessibilityHidden(true)
    }
}
