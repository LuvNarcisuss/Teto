import Combine
import Foundation
import PhotosUI
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    @Published private(set) var library = LocalLibrary()
    @Published private(set) var isLoaded = false
    @Published private(set) var loadError: String?
    @Published private(set) var busyMessage: String?
    @Published var notice: AppNotice?
    @Published private(set) var accountExitRevision = 0
    private var sessionActive = false
    var canEndSession: Bool { isLoaded && sessionActive && !isBusy && !shortsSocial.isSaving && !wallet.isBusy }
    private(set) var lastSaveError: String?

    let wallet = WalletStore()
    let shortsSocial: ShortsInteractionStore
    private var socialObservation: AnyCancellable?
    let storageRoot: URL
    @Published private var liveVideoOrder: [UUID]
    @Published private var shortsVideoOrder: [UUID]
    private var watchedVideos: [UUID: Date] = [:]
    private let viewingHistory: VideoViewingHistory
    private var refreshingLive = false
    private var refreshingShorts = false
    private let repository: LocalLibraryRepository
    var isBusy: Bool { busyMessage != nil }
    var danceVideos: [LocalVideo] {
        DanceVideoCatalog.entries.map { entry in
            var video = entry.localVideo
            video.isSaved = library.savedDemoVideoIDs?.contains(video.id) == true
            return video
        }
    }
    var discoveryVideos: [LocalVideo] { discoveryVideos(orderedBy: liveVideoOrder) }
    var shortsDiscoveryVideos: [LocalVideo] { discoveryVideos(orderedBy: shortsVideoOrder) }

    private func discoveryVideos(orderedBy order: [UUID]) -> [LocalVideo] {
        let candidates = collectionVideos.filter { $0.isDance == true && !pendingVideoIDs.contains($0.id) && !isCreatorBlocked($0.creatorID) }
        let lookup = Dictionary(uniqueKeysWithValues: candidates.map { ($0.id, $0) })
        let known = Set(order)
        return candidates.filter { !known.contains($0.id) } + order.compactMap { lookup[$0] }
    }

    func recordVideoViewed(_ id: UUID) async {
        guard isLoaded, sessionActive, !isBusy else { return }
        let now = Date()
        guard now.timeIntervalSince(watchedVideos[id] ?? .distantPast) > 30 else { return }
        watchedVideos[id] = now
        // A storage failure leaves in-session recommendations working; never reset private data.
        try? await viewingHistory.record(id, at: now)
    }

    func refreshLiveRecommendations() async {
        guard !refreshingLive else { return }
        refreshingLive = true
        defer { refreshingLive = false }
        await Task.yield()
        guard !Task.isCancelled else { return }
        liveVideoOrder = VideoRecommendations.orderedIDs(discoveryVideos, watched: watchedVideos, avoiding: discoveryVideos.first?.id)
    }

    func refreshShortsRecommendations() async {
        guard !refreshingShorts else { return }
        refreshingShorts = true
        defer { refreshingShorts = false }
        await Task.yield()
        guard !Task.isCancelled else { return }
        let candidates = shortsDiscoveryVideos.filter { $0.duration <= 180 }
        shortsVideoOrder = VideoRecommendations.orderedIDs(candidates, watched: watchedVideos, avoiding: candidates.first?.id)
    }

    var collectionVideos: [LocalVideo] { library.videos + danceVideos }
    var likedVideos: [LocalVideo] {
        collectionVideos.filter { !pendingVideoIDs.contains($0.id) && shortsSocial.liked.contains($0.id) && !isCreatorBlocked($0.creatorID) }
    }
    var savedVideos: [LocalVideo] { collectionVideos.filter { !pendingVideoIDs.contains($0.id) && $0.isSaved && !isCreatorBlocked($0.creatorID) } }

    init() {
        let liveOrder = DanceVideoCatalog.shuffledDiscoveryIDs()
        var shortsOrder = DanceVideoCatalog.shuffledDiscoveryIDs()
        // Keep the first bundled clip different without moving older batches forward.
        if shortsOrder.count > 1, shortsOrder.first == liveOrder.first,
           let first = DanceVideoCatalog.entries.first(where: { $0.id == shortsOrder[0] }),
           let alternate = shortsOrder.dropFirst().first(where: { id in
               DanceVideoCatalog.entries.contains { $0.id == id && $0.collectionGeneration == first.collectionGeneration }
           }), let index = shortsOrder.firstIndex(of: alternate) {
            shortsOrder.swapAt(0, index)
        }
        liveVideoOrder = liveOrder
        shortsVideoOrder = shortsOrder
        let root = URL.applicationSupportDirectory.appendingPathComponent("Teto", isDirectory: true)
        storageRoot = root
        viewingHistory = VideoViewingHistory(root: root)
        repository = LocalLibraryRepository(root: root)
        shortsSocial = ShortsInteractionStore(root: root)
        socialObservation = shortsSocial.objectWillChange.sink { [weak self] _ in
            self?.objectWillChange.send()
        }
    }

    // Records explicit consent; this does not authenticate an online account.
    func acceptUserAgreement() async -> Bool {
        var updated = library
        updated.agreementAcceptance = AgreementAcceptance(version: TetoUserAgreement.version, acceptedAt: Date())
        guard await commit(updated, permitsEntry: true) else { return false }
        await viewingHistory.setRecordingEnabled(true)
        sessionActive = true
        shortsSocial.setSessionActive(true)
        return true
    }

    /// Ends only the local session. No online credentials or remote session exist.
    func logOut() async -> Bool {
        guard canEndSession else { return false }
        busyMessage = "Signing out…"
        defer { busyMessage = nil }
        sessionActive = false
        shortsSocial.setSessionActive(false)
        await viewingHistory.setRecordingEnabled(false)
        notice = nil
        lastSaveError = nil
        accountExitRevision += 1
        return true
    }

    /// Explicitly confirmed by the settings screen; never called on simple logout.
    func deleteLocalAccount() async -> Bool {
        guard canEndSession else { return false }
        busyMessage = "Deleting your data…"
        defer { busyMessage = nil }
        sessionActive = false
        shortsSocial.setSessionActive(false)
        await viewingHistory.setRecordingEnabled(false)
        do {
            try await repository.deleteLocalAccount()
            await clearAccountMemory()
            try await shortsSocial.load()
            loadError = nil
            accountExitRevision += 1
            return true
        } catch {
            // A durable deletion marker makes load() finish cleanup before any reads.
            await clearAccountMemory()
            isLoaded = false
            loadError = message(for: error)
            accountExitRevision += 1
            return false
        }
    }

    private func clearAccountMemory() async {
        library = LocalLibrary()
        shortsSocial.clearAccountMemory()
        wallet.clearAccountMemory()
        watchedVideos = [:]
        await viewingHistory.clearMemory()
        liveVideoOrder = DanceVideoCatalog.shuffledDiscoveryIDs()
        shortsVideoOrder = DanceVideoCatalog.shuffledDiscoveryIDs()
        notice = nil
        lastSaveError = nil
    }

    func load() async {
        guard !isBusy, !isLoaded else { return }
        busyMessage = "Opening your library…"
        defer { busyMessage = nil }
        loadError = nil
        do {
            library = try await repository.load()
            try await shortsSocial.load()
            watchedVideos = (try? await viewingHistory.load()) ?? [:]
            liveVideoOrder = VideoRecommendations.orderedIDs(discoveryVideos, watched: watchedVideos)
            shortsVideoOrder = VideoRecommendations.orderedIDs(shortsDiscoveryVideos.filter { $0.duration <= 180 }, watched: watchedVideos, avoiding: liveVideoOrder.first)
            isLoaded = true
        } catch {
            loadError = message(for: error)
        }
    }

    func videoURL(_ video: LocalVideo) -> URL {
        if let clip = video.bundledClip { return clip.resourceURL(fileExtension: "mp4") }
        return storageRoot.appendingPathComponent("Media/\(video.id.uuidString).\(video.fileExtension)")
    }

    func coverURL(_ video: LocalVideo) -> URL {
        if let clip = video.bundledClip { return clip.resourceURL(fileExtension: "jpg") }
        return storageRoot.appendingPathComponent("Media/\(video.id.uuidString).jpg")
    }

    var pendingSubmissions: [CreationSubmission] { library.submissions ?? [] }
    var pendingVideoIDs: Set<UUID> { Set(pendingSubmissions.compactMap(\.videoID)) }
    var personalWorks: [LocalVideo] { library.videos.filter { !pendingVideoIDs.contains($0.id) } }

    func submissionCoverURL(_ submission: CreationSubmission) -> URL? {
        if submission.hasCover { return storageRoot.appendingPathComponent("Media/\(submission.id.uuidString).jpg") }
        if let id = submission.videoID, let video = library.videos.first(where: { $0.id == id }) { return coverURL(video) }
        return nil
    }

    /// Queue content atomically; never start streaming, publish, or manufacture review approval.
    func queueCreation(kind: CreationKind, title: String, caption: String, category: PartyCategory,
                       videoItem: PhotosPickerItem?, coverItem: PhotosPickerItem?) async -> UUID? {
        guard isLoaded, sessionActive, !isBusy,
              CreationValidation.valid(title: title, caption: caption),
              kind != .shortVideo || videoItem != nil else { return nil }
        busyMessage = "Preparing your content…"
        lastSaveError = nil
        defer { busyMessage = nil }
        var submission = CreationSubmission(kind: kind, title: title.trimmingCharacters(in: .whitespacesAndNewlines),
            caption: caption.trimmingCharacters(in: .whitespacesAndNewlines), category: category.title)
        var importedVideo: LocalVideo?
        do {
            if kind == .shortVideo, let videoItem {
                guard let imported = try await videoItem.loadTransferable(type: ImportedVideo.self) else {
                    throw LocalLibraryError.importFailed
                }
                defer { try? FileManager.default.removeItem(at: imported.temporaryURL) }
                var video = try await repository.importVideo(from: imported.temporaryURL)
                importedVideo = video
                guard video.duration <= 180 else { throw CreationError.shortTooLong }
                video.title = submission.title
                video.isDance = true
                importedVideo = video
                submission.videoID = video.id
            }
            if kind == .live, let coverItem {
                guard let data = try await coverItem.loadTransferable(type: Data.self) else {
                    throw CreationError.coverUnavailable
                }
                try await repository.importSubmissionCover(data, id: submission.id)
                submission.hasCover = true
            }
            try Task.checkCancellation()
            var updated = library
            if let importedVideo { updated.videos.insert(importedVideo, at: 0) }
            var submissions = updated.submissions ?? []
            submissions.insert(submission, at: 0)
            updated.submissions = submissions
            try await repository.save(updated)
            library = updated
            return submission.id
        } catch {
            if let importedVideo { await repository.removeMedia(for: importedVideo) }
            await repository.removeSubmissionCover(submission.id)
            lastSaveError = (error as? CreationError)?.errorDescription
                ?? (error as? LocalLibraryError)?.errorDescription
                ?? "Your content could not be saved. Please try again."
            return nil
        }
    }

    func removeSubmission(_ id: UUID) async -> Bool {
        guard let submission = pendingSubmissions.first(where: { $0.id == id }) else { return false }
        let video = library.videos.first { $0.id == submission.videoID }
        var updated = library
        updated.submissions?.removeAll { $0.id == id }
        if let video { updated.videos.removeAll { $0.id == video.id } }
        guard await commit(updated) else { return false }
        if let video { await repository.removeMedia(for: video) }
        if submission.hasCover { await repository.removeSubmissionCover(submission.id) }
        return true
    }

    func markAsDance(_ id: UUID) async {
        var updated = library
        guard let index = updated.videos.firstIndex(where: { $0.id == id }) else { return }
        updated.videos[index].isDance = true
        if !(await commit(updated)) { showSaveFailure() }
    }

    func toggleSaved(_ id: UUID) async {
        var updated = library
        if DanceVideoCatalog.entries.contains(where: { $0.id == id }) {
            var saved = updated.savedDemoVideoIDs ?? []
            if saved.contains(id) { saved.remove(id) } else { saved.insert(id) }
            updated.savedDemoVideoIDs = saved
            if !(await commit(updated)) { showSaveFailure() }
            return
        }
        guard let index = updated.videos.firstIndex(where: { $0.id == id }) else { return }
        updated.videos[index].isSaved.toggle()
        if !(await commit(updated)) { showSaveFailure() }
    }

    func renameVideo(_ id: UUID, title: String) async -> Bool {
        let title = title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty, title.count <= 80 else { return false }
        var updated = library
        guard let index = updated.videos.firstIndex(where: { $0.id == id }) else { return false }
        updated.videos[index].title = title
        return await commit(updated)
    }

    func deleteVideo(_ id: UUID) async -> Bool {
        guard let video = library.videos.first(where: { $0.id == id }) else { return false }
        var updated = library
        updated.videos.removeAll { $0.id == id }
        updated.submissions?.removeAll { $0.videoID == id }
        guard await commit(updated) else { showSaveFailure(); return false }
        await repository.removeMedia(for: video)
        return true
    }

    func saveProfile(_ profile: LocalProfile) async -> Bool {
        var profile = profile
        profile.displayName = profile.displayName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !profile.displayName.isEmpty, profile.displayName.count <= 30,
              profile.biography.count <= 160 else { return false }
        var updated = library
        updated.profile = profile
        return await commit(updated)
    }

    func saveRoom(_ draft: VoiceRoomDraft) async -> Bool {
        var draft = draft
        draft.title = draft.title.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !draft.title.isEmpty, draft.title.count <= 60, draft.description.count <= 240,
              [4, 6, 8].contains(draft.seatCount) else { return false }
        draft.updatedAt = Date()
        var updated = library
        updated.roomDrafts.removeAll { $0.id == draft.id }
        updated.roomDrafts.insert(draft, at: 0)
        return await commit(updated)
    }

    func deleteRoom(_ id: UUID) async -> Bool {
        var updated = library
        updated.roomDrafts.removeAll { $0.id == id }
        let saved = await commit(updated)
        if !saved { showSaveFailure() }
        return saved
    }

    func saveMessageDraft(_ text: String) async -> Bool {
        guard text.count <= 2_000 else { return false }
        var updated = library
        updated.messageDraft = text
        return await commit(updated)
    }

    var chatConversations: [DanceConversation] {
        let state = library.creatorState ?? CreatorLocalState()
        var records = state.conversations ?? [:]
        // Surface existing drafts from versions that did not store inbox entries.
        for id in state.messageDrafts.keys where records[id] == nil {
            let creator = resolvedCreator(id: id, stored: nil)
            records[id] = CreatorConversationRecord(creator: creator, updatedAt: nil)
        }
        let creators = records.values.filter { !isCreatorBlocked($0.creator.id) }.sorted {
            let left = $0.updatedAt ?? .distantPast
            let right = $1.updatedAt ?? .distantPast
            return left == right ? $0.creator.id < $1.creator.id : left > right
        }.map { record in
            let creator = resolvedCreator(id: record.creator.id, stored: record.creator)
            let time = record.updatedAt.map { date in
                Calendar.current.isDateInToday(date)
                    ? date.formatted(.dateTime.hour().minute().locale(Locale(identifier: "en_US")))
                    : date.formatted(.dateTime.month(.abbreviated).day().locale(Locale(identifier: "en_US")))
            } ?? ""
            return DanceConversation(id: "creator-chat:\(creator.id)", name: creator.name, avatars: [],
                                     kind: .person, time: time, initialUnread: 0, initiallyPinned: false,
                                     story: nil, messages: library.chatState?.sentMessages?["creator-chat:\(creator.id)"] ?? [], creator: creator)
        }
        let authored = DanceChatCatalog.conversations.map { conversation in
            let additions = library.chatState?.sentMessages?[conversation.id] ?? []
            return DanceConversation(id: conversation.id, name: conversation.name, avatars: conversation.avatars,
                kind: conversation.kind, time: additions.last?.time ?? conversation.time,
                initialUnread: conversation.initialUnread, initiallyPinned: conversation.initiallyPinned,
                story: conversation.story, messages: conversation.messages + additions)
        }
        return (creators + authored).sorted { left, right in
            let a = library.chatState?.sentMessages?[left.id]?.last?.createdAt ?? .distantPast
            let b = library.chatState?.sentMessages?[right.id]?.last?.createdAt ?? .distantPast
            if a == b { return false }
            return a > b
        }
    }

    func messages(for conversation: DanceConversation) -> [ChatMessage] {
        chatConversations.first { $0.id == conversation.id }?.messages ?? conversation.messages
    }

    func followsChatPartner(_ conversation: DanceConversation) -> Bool {
        if let creator = conversation.creator { return isFollowingCreator(creator.id) }
        return library.chatState?.followingOverrides?[conversation.id]
            ?? DanceChatCatalog.initialMutualIDs.contains(conversation.id)
    }

    func chatPartnerFollowsMe(_ conversation: DanceConversation) -> Bool {
        // Unknown creator relationships remain false until an authoritative service updates them.
        let followers = library.chatState?.followerIDs ?? DanceChatCatalog.initialFollowerIDs
        return followers.contains(conversation.id)
    }

    func isMutualChat(_ conversation: DanceConversation) -> Bool {
        followsChatPartner(conversation) && chatPartnerFollowsMe(conversation)
    }

    func canSendChatMessage(_ conversation: DanceConversation) -> Bool {
        if conversation.kind == .activity { return false }
        if let creator = conversation.creator, isCreatorBlocked(creator.id) { return false }
        if conversation.kind == .group || conversation.creator?.isLocalOwner == true || isMutualChat(conversation) { return true }
        return (library.chatState?.sentMessages?[conversation.id] ?? []).isEmpty
    }

    func toggleChatFollow(_ conversation: DanceConversation) async {
        if let creator = conversation.creator { await toggleCreatorFollow(creator.id); return }
        guard isLoaded, !isBusy, conversation.kind == .person else { return }
        var updated = library
        var state = updated.chatState ?? ChatLocalState()
        var overrides = state.followingOverrides ?? [:]
        overrides[conversation.id] = !followsChatPartner(conversation)
        state.followingOverrides = overrides
        updated.chatState = state
        if !(await commit(updated)) { showSaveFailure() }
    }

    /// Local outbox only: persistence does not imply remote delivery or a read receipt.
    func sendChatMessage(_ text: String, to conversation: DanceConversation) async -> Bool {
        guard isLoaded, !isBusy else { return false }
        lastSaveError = nil
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= 2_000 else {
            lastSaveError = "Write a message of up to 2,000 characters."
            return false
        }
        guard canSendChatMessage(conversation) else {
            lastSaveError = conversation.creator.map { isCreatorBlocked($0.id) } == true
                ? "Unblock this person to chat."
                : "You can send another message once you follow each other."
            return false
        }
        var updated = library
        var state = updated.chatState ?? ChatLocalState()
        var outbox = state.sentMessages ?? [:]
        let now = Date()
        let message = ChatMessage(id: UUID().uuidString, author: "You", text: text,
            time: now.formatted(.dateTime.hour().minute().locale(Locale(identifier: "en_US"))),
            isOwn: true, createdAt: now, isPending: true)
        outbox[conversation.id, default: []].append(message)
        state.sentMessages = outbox
        state.drafts.removeValue(forKey: conversation.id)
        state.readIDs.insert(conversation.id)
        updated.chatState = state
        if let creator = conversation.creator {
            var creators = updated.creatorState ?? CreatorLocalState()
            creators.messageDrafts.removeValue(forKey: creator.id)
            var records = creators.conversations ?? [:]
            records[creator.id] = CreatorConversationRecord(creator: creator, updatedAt: now)
            creators.conversations = records
            updated.creatorState = creators
        }
        return await commit(updated)
    }

    func chatDraft(for conversation: DanceConversation) -> String? {
        if let creator = conversation.creator { return library.creatorState?.messageDrafts[creator.id] }
        return library.chatState?.drafts[conversation.id]
    }

    private func resolvedCreator(id: String, stored: CreatorProfile?) -> CreatorProfile {
        if let video = collectionVideos.first(where: { $0.creatorID == id }) {
            return .from(video: video, profile: library.profile, coverURL: coverURL(video))
        }
        if id == "local-owner" {
            return CreatorProfile(id: id, name: library.profile.displayName, biography: library.profile.biography,
                                  avatarSymbol: library.profile.avatarSymbol, isLocalOwner: true)
        }
        return stored ?? CreatorProfile(id: id, name: "Dance creator", biography: "")
    }

    @discardableResult
    func openCreatorConversation(_ creator: CreatorProfile) async -> Bool {
        guard !isCreatorBlocked(creator.id) else { return false }
        var updated = library
        var state = updated.creatorState ?? CreatorLocalState()
        var records = state.conversations ?? [:]
        records[creator.id] = CreatorConversationRecord(creator: creator, updatedAt: Date())
        state.conversations = records
        updated.creatorState = state
        return await commit(updated)
    }

    func chatUnreadCount(_ conversation: DanceConversation) -> Int {
        library.chatState?.readIDs.contains(conversation.id) == true ? 0 : conversation.initialUnread
    }

    func isChatPinned(_ conversation: DanceConversation) -> Bool {
        library.chatState?.pinOverrides[conversation.id] ?? conversation.initiallyPinned
    }

    func markChatRead(_ id: String? = nil) async {
        var updated = library
        var state = updated.chatState ?? ChatLocalState()
        let ids = id.map { Set([$0]) } ?? Set(chatConversations.map(\.id))
        guard !ids.isSubset(of: state.readIDs) else { return }
        state.readIDs.formUnion(ids)
        updated.chatState = state
        if !(await commit(updated)) { showSaveFailure() }
    }

    func toggleChatPin(_ conversation: DanceConversation) async {
        var updated = library
        var state = updated.chatState ?? ChatLocalState()
        state.pinOverrides[conversation.id] = !isChatPinned(conversation)
        updated.chatState = state
        if !(await commit(updated)) { showSaveFailure() }
    }

    func saveChatDraft(_ text: String, conversationID: String) async -> Bool {
        guard text.count <= 2_000, DanceChatCatalog.conversations.contains(where: { $0.id == conversationID }) else { return false }
        var updated = library
        var state = updated.chatState ?? ChatLocalState()
        if text.isEmpty { state.drafts[conversationID] = nil }
        else { state.drafts[conversationID] = text }
        updated.chatState = state
        return await commit(updated)
    }

    /// The profile grid and totals share the complete catalog, independent of feed order.
    /// Pending submissions are private queue entries, not published works.
    func creatorWorks(for creatorID: String) -> [LocalVideo] {
        collectionVideos.filter { $0.creatorID == creatorID && !pendingVideoIDs.contains($0.id) }
    }

    func statistics(for creator: CreatorProfile) -> CreatorStatistics {
        let totals = creatorWorks(for: creator.id).reduce(into: (likes: 0, saves: 0)) { total, video in
            let counts = shortsSocial.counts(for: video)
            total.likes += counts.likes
            total.saves += counts.saves
        }
        if creator.isLocalOwner {
            let creatorFollows = library.creatorState?.followedIDs.count ?? 0
            let chatFollows = DanceChatCatalog.conversations.filter {
                $0.kind == .person && followsChatPartner($0)
            }.count
            return CreatorStatistics(likes: totals.likes, saves: totals.saves,
                following: creatorFollows + chatFollows, followers: 0)
        }
        let relationships = creator.relationshipStatistics
        return CreatorStatistics(likes: totals.likes, saves: totals.saves,
            following: relationships.following, followers: relationships.followers + (isFollowingCreator(creator.id) ? 1 : 0))
    }

    func isFollowingCreator(_ id: String) -> Bool {
        library.creatorState?.followedIDs.contains(id) == true
    }

    func toggleCreatorFollow(_ id: String) async {
        guard isLoaded, !isBusy, !isCreatorBlocked(id) else { return }
        var updated = library
        var state = updated.creatorState ?? CreatorLocalState()
        if state.followedIDs.contains(id) { state.followedIDs.remove(id) }
        else { state.followedIDs.insert(id) }
        updated.creatorState = state
        if !(await commit(updated)) { showSaveFailure() }
    }

    func saveCreatorMessageDraft(_ text: String, creator: CreatorProfile) async -> Bool {
        guard !isCreatorBlocked(creator.id), text.count <= 2_000 else { return false }
        var updated = library
        var state = updated.creatorState ?? CreatorLocalState()
        state.messageDrafts[creator.id] = text.isEmpty ? nil : text
        var records = state.conversations ?? [:]
        records[creator.id] = CreatorConversationRecord(creator: creator, updatedAt: Date())
        state.conversations = records
        updated.creatorState = state
        return await commit(updated)
    }

    func isCreatorBlocked(_ id: String) -> Bool {
        library.contentSafety?.blockedCreators[id] != nil
    }

    func blockCreator(_ creator: CreatorProfile) async -> Bool {
        guard !creator.isLocalOwner, !isBusy else { return false }
        var updated = library
        var safety = updated.contentSafety ?? ContentSafetyState()
        safety.blockedCreators[creator.id] = creator
        updated.contentSafety = safety
        updated.creatorState?.followedIDs.remove(creator.id)
        return await commit(updated)
    }

    func unblockCreator(_ id: String) async -> Bool {
        var updated = library
        var safety = updated.contentSafety ?? ContentSafetyState()
        safety.blockedCreators[id] = nil
        updated.contentSafety = safety
        return await commit(updated)
    }

    func saveContentReport(_ target: ContentSafetyTarget, reason: ContentReportReason, details: String) async -> Bool {
        let text = details.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count <= 500, !text.unicodeScalars.contains(where: { $0.properties.isAlphabetic && !$0.isASCII }) else { return false }
        var updated = library
        var safety = updated.contentSafety ?? ContentSafetyState()
        let existing = safety.reports.first { $0.contentID == target.id && $0.kind == target.kind && $0.reason == reason }
        let report = LocalContentReport(id: existing?.id ?? UUID(), contentID: target.id, title: target.title,
                                        kind: target.kind, creatorID: target.creator.id, creatorName: target.creator.name,
                                        reason: reason, details: text, savedAt: Date())
        if let index = safety.reports.firstIndex(where: { $0.id == report.id }) { safety.reports[index] = report }
        else { safety.reports.append(report) }
        updated.contentSafety = safety
        return await commit(updated)
    }

    private func commit(_ updated: LocalLibrary, permitsEntry: Bool = false) async -> Bool {
        guard isLoaded, !isBusy, sessionActive || permitsEntry else { return false }
        lastSaveError = nil
        busyMessage = "Saving…"
        defer { busyMessage = nil }
        do {
            try await repository.save(updated)
            library = updated
            return true
        } catch {
            lastSaveError = message(for: error)
            return false
        }
    }

    private func showSaveFailure() {
        if let lastSaveError {
            notice = AppNotice(title: "Changes were not saved", message: lastSaveError)
        }
    }

    private func message(for error: Error) -> String {
        (error as? LocalLibraryError)?.errorDescription ?? LocalLibraryError.storageUnavailable.localizedDescription
    }
}
