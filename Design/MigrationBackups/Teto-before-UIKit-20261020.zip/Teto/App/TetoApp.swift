import SwiftUI

@main
struct TetoApp: App {
    var body: some Scene {
        WindowGroup {
            AppRootView()
        }
    }
}
