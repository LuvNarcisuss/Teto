import SwiftUI
import UIKit

struct MainTabView: View {
    @State private var selectedTab = 0
    @State private var discoverySection: DiscoverySection = .live
    @State private var discoveryPath: [UUID] = []
    @State private var voicePath = NavigationPath()
    @State private var chatsPath = NavigationPath()
    @State private var profilePath = NavigationPath()
    private var immersive: Bool { selectedTab == 0 && discoverySection == .shorts }
    private var usesDarkNavigation: Bool { immersive || selectedTab == 1 }

    var body: some View {
        // Let the system own the floating enclosure, sliding selection bubble,
        // safe-area reservation and accessibility instead of drawing a second bar.
        TabView(selection: $selectedTab) {
            NavigationStack(path: $discoveryPath) {
                DiscoveryView(section: $discoverySection, isTabActive: selectedTab == 0)
            }
            .tabItem {
                Label { Text("Live") } icon: {
                    Image(uiImage: TabNavigationArtwork.live).renderingMode(.original)
                }
            }
            .tag(0)

            NavigationStack(path: $voicePath) { PartyDiscoveryView() }
                .tabItem {
                    Label { Text("Voice") } icon: {
                        Image(uiImage: TabNavigationArtwork.voice).renderingMode(.original)
                    }
                }
                .tag(1)

            NavigationStack(path: $chatsPath) { ChatsView() }
                .tabItem {
                    Label { Text("Chats") } icon: {
                        Image(uiImage: TabNavigationArtwork.chats).renderingMode(.original)
                    }
                }
                .tag(2)

            NavigationStack(path: $profilePath) { ProfileView() }
                .tabItem {
                    Label { Text("Me") } icon: {
                        Image(uiImage: TabNavigationArtwork.me).renderingMode(.original)
                    }
                }
                .tag(3)
        }
        .tint(usesDarkNavigation ? TetoStyle.lime : TetoStyle.emerald)
        .preferredColorScheme(immersive ? .dark : .light)
    }
}

/// A native tab item uses the UIImage's point size, not SwiftUI frame modifiers.
/// Cache small, alpha-preserving display copies while retaining full-size source art.
private enum TabNavigationArtwork {
    static let live = icon("TabLive", fallback: "play.circle.fill")
    static let voice = icon("TabVoice", fallback: "headphones")
    static let chats = icon("TabChats", fallback: "bubble.left.and.bubble.right.fill")
    static let me = icon("TabMe", fallback: "person.crop.circle.fill")

    private static func icon(_ name: String, fallback: String) -> UIImage {
        guard let source = UIImage(named: name), source.size.width > 0, source.size.height > 0 else {
            return UIImage(systemName: fallback) ?? UIImage()
        }
        let size = CGSize(width: 30, height: 30)
        let format = UIGraphicsImageRendererFormat()
        format.scale = 3
        format.opaque = false
        let factor = min(size.width / source.size.width, size.height / source.size.height)
        let fitted = CGSize(width: source.size.width * factor, height: source.size.height * factor)
        let bounds = CGRect(x: (size.width - fitted.width) / 2, y: (size.height - fitted.height) / 2,
                            width: fitted.width, height: fitted.height)
        return UIGraphicsImageRenderer(size: size, format: format).image { _ in
            source.draw(in: bounds)
        }.withRenderingMode(.alwaysOriginal)
    }
}
