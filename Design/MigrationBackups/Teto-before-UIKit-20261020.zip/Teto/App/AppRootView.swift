import SwiftUI

struct AppRootView: View {
    @StateObject private var store = AppStore()
    @State private var entryStep: EntryStep = .welcome
    private enum EntryStep { case welcome, signIn, home }

    var body: some View {
        ZStack {
            FreshStudioPageBackground().ignoresSafeArea()
            if store.isLoaded {
                switch entryStep {
                case .welcome:
                    WelcomeView(onContinue: { entryStep = .signIn })
                case .signIn:
                    SignInView(onContinue: { entryStep = .home }, onBack: { entryStep = .welcome })
                case .home:
                    MainTabView()
                }
            } else if let error = store.loadError {
                VStack(spacing: 20) {
                    EmptyLibraryView(title: "Your library needs attention", description: error,
                                     symbol: "externaldrive.badge.exclamationmark")
                    Button("Try again") { Task { await store.load() } }
                        .buttonStyle(PrimaryButtonStyle())
                }.padding(24)
            } else {
                VStack(spacing: 24) {
                    Image("TetoMark").resizable().scaledToFit().frame(width: 80, height: 80)
                        .clipShape(RoundedRectangle(cornerRadius: 20)).accessibilityHidden(true)
                    TetoWordmark(compact: true).foregroundStyle(TetoStyle.emerald)
                    ProgressView("Opening Teto…").tint(TetoStyle.emerald)
                }
            }
        }
        .environmentObject(store)
        .tint(TetoStyle.emerald)
        .environment(\.locale, Locale(identifier: "en"))
        .disabled(store.isBusy)
        .overlay {
            if store.isLoaded, let message = store.busyMessage {
                ZStack {
                    Color.black.opacity(0.12).ignoresSafeArea()
                    ProgressView(message).padding(24).background(TetoStyle.card, in: RoundedRectangle(cornerRadius: 16))
                        .foregroundStyle(TetoStyle.ink).tint(TetoStyle.emerald)
                }
                .accessibilityAddTraits(.updatesFrequently)
            }
        }
        .onChange(of: store.accountExitRevision) { _, _ in
            entryStep = .signIn
        }
        .task { await store.load() }
        .alert(item: $store.notice) { notice in
            Alert(title: Text(notice.title), message: Text(notice.message), dismissButton: .default(Text("OK")))
        }
    }
}
