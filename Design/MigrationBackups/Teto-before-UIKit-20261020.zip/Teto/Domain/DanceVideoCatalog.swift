import Foundation

/// Licensed dance films; provenance is retained outside the runtime bundle.
struct DanceVideo {
    let id: UUID
    let title: String
    let creator: String
    let assetName: String
    let duration: Double
    let sourceURL: URL
    var collectionGeneration = 0

    var localVideo: LocalVideo {
        LocalVideo(id: id, title: title, fileExtension: "mp4", duration: duration,
                   importedAt: Date(timeIntervalSince1970: 0), isSaved: false, isDance: true)
    }

    func resourceURL(fileExtension: String) -> URL {
        Bundle.main.url(forResource: assetName, withExtension: fileExtension)
            ?? Bundle.main.bundleURL.appendingPathComponent("\(assetName).\(fileExtension)")
    }
}

enum DanceVideoCatalog {
    /// Build once per app session, never during SwiftUI body updates.
    static func shuffledDiscoveryIDs() -> [UUID] {
        let groups = Dictionary(grouping: entries, by: \.collectionGeneration)
        return groups.keys.sorted(by: >).flatMap { generation in
            (groups[generation] ?? []).shuffled().map(\.id)
        }
    }

    static let entries: [DanceVideo] = [
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000007677198")!,
                   title: "Find your rhythm", creator: "Ivan S", assetName: "dance-studio", duration: 14.16,
                   sourceURL: URL(string: "https://www.pexels.com/video/woman-recording-herself-dancing-7677198/")!),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008713941")!,
                   title: "Freestyle by the sea", creator: "Kampus Production", assetName: "dance-seaside", duration: 19.96,
                   sourceURL: URL(string: "https://www.pexels.com/video/woman-dancing-by-the-sea-8713941/")!),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000007958175")!,
                   title: "Hip hop in motion", creator: "cottonbro studio", assetName: "dance-hiphop-solo", duration: 40.72,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-young-man-dancing-to-hip-hop-music-7958175/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008688877")!,
                   title: "Crew rhythm", creator: "ANTONI SHKRABA production", assetName: "dance-crew-rhythm", duration: 11.44,
                   sourceURL: URL(string: "https://www.pexels.com/video/people-dancing-hip-hop-8688877/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000003873100")!,
                   title: "Own the eight-count", creator: "Polina Tankilevitch", assetName: "dance-white-studio", duration: 3.92,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-young-woman-dancing-hip-hop-3873100/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000010264814")!,
                   title: "Move together", creator: "cottonbro studio", assetName: "dance-hiphop-duet", duration: 10.24,
                   sourceURL: URL(string: "https://www.pexels.com/video/two-women-dancing-hip-hop-10264814/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008462487")!,
                   title: "Partnered lines", creator: "MART PRODUCTION", assetName: "dance-ballet-duet", duration: 23.68,
                   sourceURL: URL(string: "https://www.pexels.com/video/man-and-woman-dancing-ballet-8462487/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008956471")!,
                   title: "Studio joy", creator: "Kampus Production", assetName: "dance-studio-joy", duration: 22.48,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-woman-dancing-in-a-studio-8956471/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000007480483")!,
                   title: "Practice partners", creator: "MART PRODUCTION", assetName: "dance-practice-partners", duration: 15.04,
                   sourceURL: URL(string: "https://www.pexels.com/video/man-and-woman-dancing-together-7480483/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000005805069")!,
                   title: "After-dark groove", creator: "Tima Miroshnichenko", assetName: "dance-purple-groove", duration: 10.64,
                   sourceURL: URL(string: "https://www.pexels.com/video/vertical-video-of-a-woman-dancing-5805069/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000007571002")!,
                   title: "Contemporary flow", creator: "Antoni Shkraba", assetName: "dance-contemporary-flow", duration: 28.84,
                   sourceURL: URL(string: "https://www.pexels.com/video/woman-dancing-in-a-studio-7571002/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000007322867")!,
                   title: "Contemporary floorwork", creator: "MART PRODUCTION", assetName: "dance-ballet-class", duration: 19.6,
                   sourceURL: URL(string: "https://www.pexels.com/video/ballerinas-dancing-on-a-dance-studio-7322867/")!, collectionGeneration: 1),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008027525")!,
                   title: "Urban footwork", creator: "Yaroslav Shuraev", assetName: "dance-urban-footwork", duration: 50.04,
                   sourceURL: URL(string: "https://www.pexels.com/video/woman-doing-breakdance-8027525/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000005362370")!,
                   title: "Street power", creator: "Allan Mas", assetName: "dance-street-power", duration: 6.2,
                   sourceURL: URL(string: "https://www.pexels.com/video/young-guy-doing-break-dance-on-the-street-5362370/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008715155")!,
                   title: "Under the bridge", creator: "Kampus Production", assetName: "dance-bridge-freestyle", duration: 24.0,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-woman-doing-break-dance-on-the-street-8715155/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000006548168")!,
                   title: "Court session", creator: "Marc Espejo", assetName: "dance-court-session", duration: 35.375,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-man-dancing-6548168/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000031889677")!,
                   title: "Studio chemistry", creator: "Shuttercraftsman", assetName: "dance-studio-chemistry", duration: 17.76,
                   sourceURL: URL(string: "https://www.pexels.com/video/dynamic-dance-routine-in-modern-studio-setting-31889677/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008956295")!,
                   title: "Together on the beat", creator: "Kampus Production", assetName: "dance-group-rehearsal", duration: 23.24,
                   sourceURL: URL(string: "https://www.pexels.com/video/women-dancing-in-the-studio-8956295/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000006939884")!,
                   title: "Follow the feeling", creator: "Pavel Danilyuk", assetName: "dance-expressive-arms", duration: 52.218833,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-woman-dancing-in-the-dance-studio-6939884/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000007689096")!,
                   title: "A shared rhythm", creator: "KoolShooters", assetName: "dance-shared-rhythm", duration: 12.8,
                   sourceURL: URL(string: "https://www.pexels.com/video/couple-dancing-together-7689096/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000008249922")!,
                   title: "Salsa in the sunshine", creator: "RDNE Stock project", assetName: "dance-sunny-salsa", duration: 10.72,
                   sourceURL: URL(string: "https://www.pexels.com/video/woman-wearing-floral-dress-dancing-with-a-man-8249922/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000006834067")!,
                   title: "Glitter and groove", creator: "Mikhail Nilov", assetName: "dance-glitter-groove", duration: 23.72,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-woman-dancing-in-the-studio-6834067/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000005138501")!,
                   title: "Ballet practice", creator: "Budgeron Bach", assetName: "dance-ballet-practice", duration: 9.32,
                   sourceURL: URL(string: "https://www.pexels.com/video/a-ballet-class-going-on-in-a-dance-studio-5138501/")!, collectionGeneration: 2),
        DanceVideo(id: UUID(uuidString: "AC8365F1-44DC-4BF4-934D-000005561275")!,
                   title: "Street crew energy", creator: "Tima Miroshnichenko", assetName: "dance-street-crew", duration: 9.64,
                   sourceURL: URL(string: "https://www.pexels.com/video/people-dancing-outdoors-5561275/")!, collectionGeneration: 2)
    ]
}
