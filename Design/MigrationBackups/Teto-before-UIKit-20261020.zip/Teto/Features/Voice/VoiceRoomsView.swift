import SwiftUI

struct VoiceRoomsView: View {
    @EnvironmentObject private var store: AppStore
    @State private var selectedTopic: RoomTopic = .music
    @State private var creatingRoom = false
    var draftsOnly = false

    private var roomIdea: VoiceRoomDraft {
        switch selectedTopic {
        case .music:
            return VoiceRoomDraft(title: "Find the beat", description: "Trade dance tracks, count the beats, and plan your next routine.", topic: .music)
        case .everyday:
            return VoiceRoomDraft(title: "Practice talk", description: "Swap dance tips, favorite routines, and practice goals.", topic: .everyday)
        case .unwind:
            return VoiceRoomDraft(title: "After the rehearsal", description: "Cool down and talk about the moves you are working on.", topic: .unwind)
        }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                Eyebrow(text: draftsOnly ? "Your space" : "Less noise. More connection.")
                ScreenHeading(title: draftsOnly ? "Room drafts" : "Find your frequency.",
                              subtitle: draftsOnly ? "A good conversation starts with an idea." : "Set the mood. Make a little room for company.")
                if !draftsOnly {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 10) {
                            ForEach(RoomTopic.allCases) { topic in
                                FilterChip(title: topic.title, symbol: topic.symbol, selected: selectedTopic == topic) { selectedTopic = topic }
                            }
                        }
                    }
                    NavigationLink {
                        VoiceRoomDetailView(initialDraft: roomIdea, isTemplate: true)
                    } label: { VoiceRoomArtwork(draft: roomIdea) }.buttonStyle(.plain)
                }
                HStack {
                    Text("Make it your own").font(TetoTypography.subsection).tracking(-0.5)
                    Spacer()
                    Button { creatingRoom = true } label: {
                        CircleAction(symbol: "plus")
                    }.accessibilityLabel("Create a room draft")
                }
                if store.library.roomDrafts.isEmpty {
                    Button { creatingRoom = true } label: {
                        HStack(spacing: 16) {
                            Image(systemName: "waveform").font(.title2).foregroundStyle(TetoStyle.emerald)
                                .frame(width: 54, height: 62).background(TetoStyle.lime.opacity(0.5), in: RoundedRectangle(cornerRadius: 18))
                            VStack(alignment: .leading, spacing: 6) {
                                Text("A room with your name on it.").font(TetoTypography.headline).foregroundStyle(TetoStyle.ink)
                                Text("Create a room draft").font(.caption).foregroundStyle(TetoStyle.muted)
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "arrow.up.right").foregroundStyle(TetoStyle.emerald)
                        }.tetoCard()
                    }.buttonStyle(.plain)
                } else {
                    ForEach(store.library.roomDrafts) { draft in
                        NavigationLink {
                            VoiceRoomDetailView(initialDraft: draft)
                        } label: {
                            HStack(spacing: 14) {
                                Image(systemName: draft.topic.symbol).font(.title2).foregroundStyle(TetoStyle.emerald)
                                    .frame(width: 50, height: 50).background(TetoStyle.lime.opacity(0.5), in: RoundedRectangle(cornerRadius: 16))
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(draft.title).font(TetoTypography.headline).foregroundStyle(TetoStyle.ink)
                                    Text("\(draft.topic.title) · \(draft.seatCount) seats · Draft")
                                        .font(.caption).foregroundStyle(TetoStyle.muted)
                                }
                                Spacer(minLength: 4)
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(TetoStyle.muted)
                            }.tetoCard()
                        }.buttonStyle(.plain)
                    }
                }
                ServiceNote(symbol: "mic.slash", text: "Voice connections are not available yet.")
            }.padding(20)
        }
        .freshStudioPage()
            .tetoNavigationTitle(draftsOnly ? "Room drafts" : "Voice").navigationBarTitleDisplayMode(.inline)
        .sheet(isPresented: $creatingRoom) { RoomEditorView(draft: VoiceRoomDraft()) }
    }
}

struct VoiceRoomArtwork: View {
    let draft: VoiceRoomDraft
    var body: some View {
        VStack(alignment: .leading, spacing: 22) {
            HStack {
                StatusPill(text: "DANCE CIRCLE", dark: true)
                Spacer()
                Image(systemName: draft.topic.symbol).font(.title3)
            }
            Spacer(minLength: 44)
            VStack(alignment: .leading, spacing: 8) {
                Text(draft.title).font(TetoTypography.largeTitle).tracking(-1)
                Text(draft.description.isEmpty ? "A little space for good company." : draft.description)
                    .font(.subheadline)
            }
            RoomSeatsView(count: draft.seatCount)
            HStack {
                Label(draft.topic.title, systemImage: draft.topic.symbol)
                Spacer()
                Text("\(draft.seatCount) seats")
            }.font(.caption.weight(.medium))
        }
        .foregroundStyle(.white).padding(24).frame(minHeight: 380)
        .background {
            ZStack {
                EditorialImage(name: "DanceStory")
                LinearGradient(colors: [.black.opacity(0.1), .black.opacity(0.45), .black.opacity(0.9)], startPoint: .top, endPoint: .bottom)
            }
        }
        .clipShape(RoundedRectangle(cornerRadius: 28))
    }
}

struct RoomSeatsView: View {
    let count: Int
    var body: some View {
        LazyVGrid(columns: [GridItem(.adaptive(minimum: 48), spacing: 10)], spacing: 14) {
            ForEach(0..<count, id: \.self) { index in
                VStack(spacing: 6) {
                    Image(systemName: "mic.slash").font(.title3)
                        .frame(width: 44, height: 44)
                        .background(.white.opacity(0.08), in: Circle())
                        .overlay(Circle().stroke(.white.opacity(0.32), lineWidth: 1))
                    Text("Seat \(index + 1)").font(.caption2)
                }.accessibilityLabel("Seat \(index + 1), not connected")
            }
        }
    }
}
