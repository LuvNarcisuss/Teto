import SwiftUI

struct VoiceRoomDetailView: View {
    let initialDraft: VoiceRoomDraft
    var isTemplate = false
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var editor: VoiceRoomDraft?
    @State private var confirmingDelete = false
    @State private var showingUnavailable = false
    private var draft: VoiceRoomDraft {
        store.library.roomDrafts.first { $0.id == initialDraft.id } ?? initialDraft
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                VoiceRoomArtwork(draft: draft)
                Text(isTemplate ? "Start with a little inspiration" : "Your room, in the making")
                    .font(TetoTypography.section).foregroundStyle(TetoStyle.ink)
                Text("Your microphone is off. This room has not been opened.")
                    .foregroundStyle(TetoStyle.muted)
                Button(isTemplate ? "Use this room idea" : "Edit draft") {
                    var copy = draft
                    if isTemplate { copy.id = UUID() }
                    editor = copy
                }.buttonStyle(PrimaryButtonStyle())
                Button("About live voice rooms") { showingUnavailable = true }
                    .buttonStyle(SecondaryButtonStyle())
                ServiceNote(symbol: "internaldrive", text: "Save your room as a draft.")
                if !isTemplate {
                    Button("Delete draft", role: .destructive) { confirmingDelete = true }
                        .frame(maxWidth: .infinity, minHeight: 44)
                }
            }.padding(20)
        }
        .freshStudioPage()
            .tetoNavigationTitle("Room details").navigationBarTitleDisplayMode(.inline)
        .sheet(item: $editor) { RoomEditorView(draft: $0) }
        .alert("Unable to join", isPresented: $showingUnavailable) {
            Button("OK", role: .cancel) { }
        } message: { Text("Voice chat is unavailable. Your microphone is off.") }
        .confirmationDialog("Delete this room draft?", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("Delete draft", role: .destructive) {
                Task { if await store.deleteRoom(draft.id) { dismiss() } }
            }
        } message: { Text("This permanently removes the draft.") }
    }
}

struct RoomEditorView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: VoiceRoomDraft
    @State private var failure: String?
    @State private var confirmDiscard = false
    @FocusState private var focused: Bool
    private let original: VoiceRoomDraft

    init(draft: VoiceRoomDraft) {
        original = draft
        _draft = State(initialValue: draft)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Room identity") {
                    TextField("Room name", text: $draft.title, axis: .vertical).focused($focused)
                    Text("\(draft.title.count)/60 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                    TextField("What would you like to talk about?", text: $draft.description, axis: .vertical)
                        .lineLimit(3...6).focused($focused)
                    Text("\(draft.description.count)/240 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                }
                Section("Room layout") {
                    Picker("Topic", selection: $draft.topic) {
                        ForEach(RoomTopic.allCases) { Text($0.title).tag($0) }
                    }
                    Picker("Seats", selection: $draft.seatCount) {
                        ForEach([4, 6, 8], id: \.self) { Text("\($0) seats").tag($0) }
                    }
                }
                Section {
                    Label("Draft · Private", systemImage: "internaldrive")
                    Text("This room has not been published.").font(.footnote)
                    FormError(message: failure)
                }
            }
            .disabled(store.isBusy)
            .scrollContentBackground(.hidden)
            .freshStudioPage()
            .tetoNavigationTitle("Room draft").navigationBarTitleDisplayMode(.inline)
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if draft != original { confirmDiscard = true } else { dismiss() } }.disabled(store.isBusy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.isBusy ? "Saving…" : "Save") {
                        focused = false
                        Task {
                            if await store.saveRoom(draft) { dismiss() }
                            else { failure = store.lastSaveError ?? "Check the room name and description." }
                        }
                    }.disabled(store.isBusy || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || draft.title.count > 60 || draft.description.count > 240)
                }
                ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { focused = false } }
            }
            .interactiveDismissDisabled(store.isBusy || draft != original)
            .confirmationDialog("Discard unsaved changes?", isPresented: $confirmDiscard, titleVisibility: .visible) {
                Button("Discard changes", role: .destructive) { dismiss() }
            }
        }
    }
}
