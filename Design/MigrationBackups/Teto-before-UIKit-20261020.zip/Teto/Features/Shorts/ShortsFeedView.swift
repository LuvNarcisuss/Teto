import SwiftUI

struct ShortsFeedView: View {
    let isTabActive: Bool
    @Binding var isSearching: Bool
    var searchQuery = ""
    // A collection supplies explicit IDs without applying the discovery duration limit.
    var collectionVideoIDs: [UUID]? = nil
    var onClose: (() -> Void)? = nil
    var closeLabel = "Back to saved videos"
    var allowsCreatorNavigation = true
    var isLiveFeed = false
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var playback = ShortsPlayback()
    private var social: ShortsInteractionStore { store.shortsSocial }
    @State private var panel: ShortsPanel?
    @State private var presentedCreator: CreatorProfile?
    @State private var currentID: UUID?
    @State private var isVisible = false
    @State private var preparedRecommendations = false
    @State private var creating = false
    private var videos: [LocalVideo] {
        if let collectionVideoIDs {
            return collectionVideoIDs.compactMap { id in store.collectionVideos.first { $0.id == id && !store.isCreatorBlocked($0.creatorID) } }
        }
        let source = isLiveFeed ? store.discoveryVideos : store.shortsDiscoveryVideos
        return source.filter { isLiveFeed || $0.duration <= 180 }
    }

    var body: some View {
        Group {
            if videos.isEmpty {
                if collectionVideoIDs != nil {
                    ContentUnavailableView("Video unavailable", systemImage: "video.slash",
                                           description: Text("This video is no longer in your collection."))
                        .foregroundStyle(.white)
                } else { emptyFeed }
            } else {
                GeometryReader { safeGeometry in
                    // Capture the bars' insets before extending the media viewport.
                    // Only the HUD uses these insets, preserving its existing position.
                    GeometryReader { viewport in
                        ScrollView(.vertical) {
                            LazyVStack(spacing: 0) {
                                ForEach(videos) { video in
                                    ShortVideoPage(video: video, current: currentID == video.id,
                                                   flowActive: isVisible && isTabActive && scenePhase == .active && panel == nil && !creating && presentedCreator == nil && !isSearching && store.notice == nil && !store.isBusy,
                                                   playback: playback, social: social, isLiveFeed: isLiveFeed,
                                                   safeAreaInsets: contentInsets(safeGeometry.safeAreaInsets), retry: retry,
                                                   open: { open($0, video: video) },
                                                   next: { move(by: 1) }, previous: { move(by: -1) })
                                        .frame(width: viewport.size.width, height: viewport.size.height)
                                        .clipped().id(video.id)
                                }
                            }.scrollTargetLayout()
                        }
                        .contentMargins(.all, 0, for: .scrollContent)
                        .scrollTargetBehavior(.paging)
                        .scrollPosition(id: $currentID)
                        .scrollIndicators(.hidden)
                        .danceFeedRefresh(enabled: collectionVideoIDs == nil) {
                            playback.setActive(false)
                            if isLiveFeed { await store.refreshLiveRecommendations() }
                            else { await store.refreshShortsRecommendations() }
                            guard !Task.isCancelled else { syncPlayback(); return }
                            currentID = videos.first?.id
                            syncPlayback()
                        }
                    }
                    .ignoresSafeArea(.container)
                }
            }
        }
        .accessibilityHidden(isSearching)
        .allowsHitTesting(!isSearching)
        .background(TetoStyle.night.ignoresSafeArea())
        .overlay(alignment: .topLeading) {
            if let onClose {
                Button {
                    isVisible = false
                    playback.stop()
                    onClose()
                } label: {
                    Image(systemName: "chevron.left").font(.system(size: 22, weight: .semibold))
                        .foregroundStyle(.white).frame(width: 44, height: 44)
                        .background(.black.opacity(0.25), in: Circle())
                }
                .buttonStyle(.plain).accessibilityLabel(closeLabel)
                .padding(.horizontal, 12).padding(.top, 4)
            }
        }
        .onAppear {
            isVisible = true
            reconcileSelection()
        }
        .task {
            guard collectionVideoIDs == nil, !preparedRecommendations else { return }
            if isLiveFeed { await store.refreshLiveRecommendations() }
            else { await store.refreshShortsRecommendations() }
            guard !Task.isCancelled else { return }
            preparedRecommendations = true
            currentID = videos.first?.id
            syncPlayback()
        }
        .onDisappear { isVisible = false; playback.stop() }
        .onChange(of: currentID) { _, _ in syncPlayback() }
        .onChange(of: isTabActive) { _, _ in syncPlayback() }
        .onChange(of: presentedCreator?.id) { _, _ in syncPlayback() }
        .onChange(of: panel?.id) { _, _ in syncPlayback() }
        .onChange(of: isSearching) { _, _ in syncPlayback() }
        .onChange(of: scenePhase) { _, _ in syncPlayback() }
        .onChange(of: store.isBusy) { _, _ in syncPlayback() }
        .onChange(of: videos.map(\.id)) { _, _ in reconcileSelection() }
        .onChange(of: store.notice?.id) { _, _ in syncPlayback() }
        .overlay {
            if isSearching {
                DanceSearchResults(videos: videos, profile: store.library.profile, query: searchQuery) { id in
                    currentID = id
                    isSearching = false
                }
            }
        }
        .sheet(item: $panel, onDismiss: {
            if collectionVideoIDs != nil && videos.isEmpty { playback.stop(); onClose?() }
            else { syncPlayback() }
        }) { route in
            switch route.kind {
            case .floating, .comments:
                ShortsCommentSheet(video: route.video, floating: route.kind == .floating, social: social)
                    .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
            case .more:
                NavigationStack {
                    List {
                        ContentSafetyActions(target: ContentSafetyTarget(id: route.video.id.uuidString,
                            title: route.video.title, kind: isLiveFeed ? .live : .shortVideo,
                            creator: .from(video: route.video, profile: store.library.profile, coverURL: store.coverURL(route.video))),
                            onBlocked: { panel = nil })
                        Section("Playback") {
                            Button(playback.isMuted ? "Turn sound on" : "Mute") { playback.toggleMuted() }
                            Text("Speed: 1× · Looping")
                            ShortsFlowToggle(social: social)
                        }
                    }
                    .freshStudioPage().tetoNavigationTitle("More options").navigationBarTitleDisplayMode(.inline)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { panel = nil } } }
                }.preferredColorScheme(.light).tint(TetoStyle.emerald)
                    .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
            case .gifts:
                NavigationStack {
                    GiftSheetView(wallet: store.wallet, roomID: route.video.id.uuidString)
                        .tetoNavigationTitle("Send a gift").navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { panel = nil } } }
                }.preferredColorScheme(.light).presentationDetents([.large])
            case .profile: EmptyView() // Creator profiles use the full-screen route below.
            case .share:
                LiveShareSheet(text: "\(route.video.title) · \(route.video.danceDescription) · Teto",
                               onCompleted: {
                                   Task { @MainActor in
                                       if !(await social.recordCompletedShare(for: route.video.id)) {
                                           store.notice = AppNotice(title: "Unable to save share count",
                                               message: social.storageError ?? "Please try again later.")
                                       }
                                   }
                               })
                    .presentationDetents([.medium, .large])
            }
        }
        .fullScreenCover(item: $presentedCreator, onDismiss: syncPlayback) { creator in
            CreatorProfileView(creator: creator)
        }
        .sheet(isPresented: $creating) { ShortVideoCreationView() }
        .onChange(of: creating) { _, _ in syncPlayback() }
    }

    private func open(_ kind: ShortsPanelKind, video: LocalVideo) {
        if kind == .profile {
            if allowsCreatorNavigation {
                playback.setActive(false)
                presentedCreator = .from(video: video, profile: store.library.profile, coverURL: store.coverURL(video))
            } else {
                isVisible = false
                playback.stop()
                onClose?()
            }
        } else {
            if kind == .comments || kind == .floating { social.prepareComments(for: video) }
            panel = ShortsPanel(kind: kind, video: video)
        }
    }

    private func contentInsets(_ insets: EdgeInsets) -> EdgeInsets {
        EdgeInsets(top: insets.top + (onClose == nil ? 0 : 52), leading: insets.leading,
                   bottom: insets.bottom, trailing: insets.trailing)
    }

    private var emptyFeed: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    HStack {
                        Eyebrow(text: "Small steps. Big energy.", color: TetoStyle.lime)
                        Spacer()
                        Image(systemName: "play.rectangle.on.rectangle").font(.title2).foregroundStyle(.white)
                    }
                    Spacer(minLength: 100)
                    Text("Find your\nnext move.")
                        .font(TetoTypography.largeTitle).tracking(-1.2)
                    Text("A full-screen home for your dance clips.\nAdd a routine, then swipe for inspiration.")
                        .font(.subheadline).foregroundStyle(.white.opacity(0.8))
                    Button { creating = true } label: {
                        Label("Add your first dance", systemImage: "plus")
                    }.buttonStyle(PrimaryButtonStyle()).disabled(store.isBusy)
                    Text("Up to 3 minutes · Dance videos only")
                        .font(.caption).foregroundStyle(.white.opacity(0.8))
                }
                .foregroundStyle(.white).padding(26)
                .frame(minHeight: geometry.size.height, alignment: .bottomLeading)
            }
            .background {
                ZStack {
                    EditorialImage(name: "DanceStory")
                    LinearGradient(colors: [.black.opacity(0.15), .black.opacity(0.1), TetoStyle.night.opacity(0.96)], startPoint: .top, endPoint: .bottom)
                }
                .ignoresSafeArea(.container)
            }
        }
    }

    private func reconcileSelection() {
        if !videos.contains(where: { $0.id == currentID }) { currentID = videos.first?.id }
        syncPlayback()
    }

    private func syncPlayback() {
        guard !videos.isEmpty else { playback.stop(); return }
        guard isVisible, isTabActive, scenePhase == .active,
              let video = videos.first(where: { $0.id == currentID }) else {
            playback.setActive(false)
            return
        }
        playback.select(video, url: store.videoURL(video))
        playback.setActive(!store.isBusy && store.notice == nil && panel == nil && !creating && presentedCreator == nil && !isSearching)
    }

    private func move(by offset: Int) {
        guard let index = videos.firstIndex(where: { $0.id == currentID }), !videos.isEmpty else { return }
        currentID = videos[min(max(index + offset, 0), videos.count - 1)].id
    }

    private func retry() {
        playback.stop()
        syncPlayback()
    }
}

private struct ShortsFlowToggle: View {
    @ObservedObject var social: ShortsInteractionStore
    var body: some View { Toggle("Chat flow", isOn: $social.bulletsEnabled) }
}
