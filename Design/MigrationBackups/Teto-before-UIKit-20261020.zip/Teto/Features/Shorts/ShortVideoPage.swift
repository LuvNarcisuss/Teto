import SwiftUI

struct ShortVideoPage: View {
    let video: LocalVideo
    let current: Bool
    let flowActive: Bool
    @ObservedObject var playback: ShortsPlayback
    @ObservedObject var social: ShortsInteractionStore
    var isLiveFeed = false
    let safeAreaInsets: EdgeInsets
    let retry: () -> Void
    let open: (ShortsPanelKind) -> Void
    let next: () -> Void
    let previous: () -> Void
    @EnvironmentObject private var store: AppStore
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOver
    @State private var scrubbing = false
    @State private var scrubProgress = 0.0
    private var compact: Bool { verticalSizeClass == .compact }
    private var name: String { video.creatorName(profile: store.library.profile) }
    private var liked: Bool { social.liked.contains(video.id) }
    private var counts: ShortVideoCounts { social.counts(for: video) }
    private func countLabel(_ count: Int) -> String {
        count.formatted(.number.locale(Locale(identifier: "en_US")))
    }
    private var countsAsViewing: Bool {
        current && flowActive && playback.isPlaying && !playback.isLoading && playback.error == nil
    }
    private var flowing: Bool {
        current && flowActive && playback.isPlaying && !playback.isLoading && playback.error == nil
        && social.bulletsEnabled && !reduceMotion && !voiceOver
    }

    var body: some View {
        ZStack {
            LocalVideoCover(url: store.coverURL(video)).allowsHitTesting(false)
            if current, playback.player != nil {
                VideoPlaybackSurface(player: playback.player).allowsHitTesting(false)
            }
            LinearGradient(stops: [.init(color: .black.opacity(0.28), location: 0),
                                   .init(color: .clear, location: 0.28),
                                   .init(color: .clear, location: 0.5),
                                   .init(color: .black.opacity(0.7), location: 1)],
                           startPoint: .top, endPoint: .bottom).allowsHitTesting(false)
            Button { playback.togglePlayback() } label: {
                Color.clear.contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            .disabled(!current || playback.isLoading || playback.error != nil)
            .accessibilityLabel(playback.isPlaying ? "Pause video" : "Play video")
            .accessibilityAction(named: "Next dance") { next() }
            .accessibilityAction(named: "Previous dance") { previous() }
            .accessibilityAction(named: Text(playback.isMuted ? "Unmute video" : "Mute video")) { playback.toggleMuted() }
            .contextMenu {
                Button(playback.isPlaying ? "Pause video" : "Play video") { playback.togglePlayback() }
                Button(playback.isMuted ? "Unmute video" : "Mute video") { playback.toggleMuted() }
                Button("Next dance", action: next)
                Button("Previous dance", action: previous)
            }

            VStack(spacing: 0) {
                ScrollingCommentsView(videoID: video.id, active: flowing,
                                      lanes: compact ? 2 : 5, bullet: social.latestBullet)
                    .padding(.top, 12)
                Spacer(minLength: 0)
            }.padding(.top, safeAreaInsets.top)

            if current {
                if let error = playback.error {
                    VStack(spacing: 12) {
                        Text(error).font(.subheadline).multilineTextAlignment(.center)
                        Button("Retry", action: retry).frame(minHeight: 44)
                    }.padding(20).background(.black.opacity(0.7), in: RoundedRectangle(cornerRadius: 20))
                        .padding(safeAreaInsets).padding(.horizontal, 32)
                } else if playback.isLoading {
                    ProgressView("Loading clip…").tint(.white)
                } else if !playback.isPlaying {
                    Image(systemName: "play.fill").font(.system(size: 64)).foregroundStyle(.white.opacity(0.65))
                        .allowsHitTesting(false).accessibilityHidden(true)
                }
            }

            VStack(spacing: 0) {
                Spacer(minLength: 8)
                HStack(alignment: .bottom, spacing: 12) {
                    caption.frame(maxWidth: .infinity, alignment: .leading)
                    if compact || typeSize.isAccessibilitySize {
                        ScrollView { actionRail.padding(.vertical, 6) }
                            .scrollIndicators(.hidden).frame(width: 64).frame(maxHeight: .infinity)
                    } else {
                        ViewThatFits(in: .vertical) {
                            actionRail
                            ScrollView { actionRail.padding(.vertical, 6) }.scrollIndicators(.hidden).frame(width: 64)
                        }
                    }
                }
                if current && !isLiveFeed { progressBar.padding(.top, 4) }
            }
            .padding(.horizontal, 12).padding(.bottom, 4).padding(.top, 8)
            .padding(safeAreaInsets)
        }
        .task(id: countsAsViewing) {
            guard countsAsViewing else { return }
            do { try await Task.sleep(for: .seconds(2)) } catch { return }
            guard !Task.isCancelled, countsAsViewing else { return }
            await store.recordVideoViewed(video.id)
        }
        .foregroundStyle(.white)
    }

    private var caption: some View {
        VStack(alignment: .leading, spacing: 6) {
            Button { open(.floating) } label: {
                Image(systemName: "text.bubble").font(.system(size: 20))
                    .frame(width: 44, height: 44)
            }.buttonStyle(.plain).accessibilityLabel("Send a floating comment")
            HStack(spacing: 10) {
                Button { open(.profile) } label: {
                    HStack(spacing: 8) {
                        creatorAvatar(size: 38)
                        Text(name).font(.subheadline.weight(.semibold)).lineLimit(1)
                    }.frame(minHeight: 44)
                }.buttonStyle(.plain).accessibilityLabel("View creator \(name)")
                Button {
                    Task { await store.toggleCreatorFollow(video.creatorID) }
                } label: {
                    Text(store.isFollowingCreator(video.creatorID) ? "Following" : "Follow")
                        .font(.caption.weight(.semibold)).padding(.horizontal, 14).padding(.vertical, 8)
                        .background(TetoStyle.emerald, in: Capsule()).frame(minHeight: 44)
                }.buttonStyle(.plain).disabled(store.isBusy)
            }
            Text(video.danceDescription).font(.subheadline).lineSpacing(2)
                .lineLimit(compact ? 2 : 3).multilineTextAlignment(.leading)
                .fixedSize(horizontal: false, vertical: true)
        }
        .shadow(color: .black.opacity(0.6), radius: 2, y: 1)
    }

    @ViewBuilder private func creatorAvatar(size: CGFloat) -> some View {
        if video.isBundled {
            LiveAvatar(asset: FreshStudioPhotos.creatorAvatar(for: video.creatorID), size: size)
        } else {
            ProfileAvatar(symbol: store.library.profile.avatarSymbol, size: size)
        }
    }

    private var actionRail: some View {
        VStack(spacing: compact ? 6 : 10) {
            Button { open(.profile) } label: {
                ZStack(alignment: .bottom) {
                    creatorAvatar(size: 48)
                        .overlay(Circle().strokeBorder(.white, lineWidth: 2))
                    Image(systemName: store.isFollowingCreator(video.creatorID) ? "checkmark" : "plus")
                        .font(.system(size: 12, weight: .heavy)).frame(width: 22, height: 22)
                        .background(TetoStyle.emerald, in: Circle()).offset(y: 8)
                }.padding(.bottom, 8).frame(width: 56, height: 64)
            }.accessibilityLabel("View creator \(name)")
            railButton(symbol: "heart.fill", title: countLabel(counts.likes), color: liked ? .pink : .white,
                       accessibility: liked ? "Unlike video" : "Like video", value: "\(counts.likes) likes") {
                Task { @MainActor in
                    if !(await social.toggleLike(video.id)) {
                        store.notice = AppNotice(title: "Unable to save",
                            message: social.storageError ?? "Please try again in a moment.")
                    }
                }
            }.disabled(social.isSaving)
            railButton(symbol: "bubble.right.fill", title: countLabel(counts.comments), accessibility: "Open comments", value: "\(counts.comments) comments") { open(.comments) }
            railButton(symbol: "star.fill", title: countLabel(counts.saves), color: video.isSaved ? TetoStyle.lime : .white,
                       accessibility: video.isSaved ? "Remove from saved videos" : "Save video", value: "\(counts.saves) saves") {
                Task { await store.toggleSaved(video.id) }
            }.disabled(store.isBusy)
            if isLiveFeed {
                railButton(symbol: "gift", title: "Gifts", accessibility: "Send a gift") { open(.gifts) }
            }
            railButton(symbol: "arrowshape.turn.up.right", title: countLabel(counts.shares), accessibility: "Share video", value: "\(counts.shares) shares") { open(.share) }
            railButton(symbol: "ellipsis", title: "More", accessibility: "More options") { open(.more) }
        }
        .buttonStyle(.plain).frame(width: 64)
        .shadow(color: .black.opacity(0.65), radius: 2, y: 1)
    }

    private func railButton(symbol: String, title: String, color: Color = .white,
                            accessibility: String, value: String = "", action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 3) {
                Image(systemName: symbol).font(.system(size: compact ? 26 : 30, weight: .regular))
                    .frame(width: 48, height: 44).foregroundStyle(color)
                Text(title).font(.caption2.weight(.medium)).monospacedDigit().lineLimit(1).minimumScaleFactor(0.8)
            }.frame(minWidth: 44, minHeight: 44)
        }.accessibilityLabel(accessibility).accessibilityValue(value)
    }

    private var progressBar: some View {
        Slider(value: Binding(get: { scrubbing ? scrubProgress : playback.progress }, set: { scrubProgress = $0 }),
               in: 0...1, onEditingChanged: { editing in
            if editing { scrubProgress = playback.progress; scrubbing = true }
            else { playback.seek(to: scrubProgress); scrubbing = false }
        })
        .tint(.white.opacity(0.8)).controlSize(.mini)
        .frame(minHeight: 44)
        .accessibilityLabel("Video position")
        .disabled(playback.isLoading || playback.error != nil)
    }
}
