import Combine
import SwiftUI
import UIKit

private struct MovingComment: Identifiable {
    let id = UUID()
    let text: String
    let lane: Int
    let started: Date
    let originX: CGFloat
    let width: CGFloat
    let isOwn: Bool
}

/// One speed for all text lengths; a lane is reused only after its trailing edge clears.
@MainActor
private final class ScrollingComments: ObservableObject {
    @Published private(set) var items: [MovingComment] = []
    private var laneReady: [Date] = []
    private var queued: [String] = []
    private var phrases = (DanceCommentScript.lines.map(\.1) + DanceDiscussionContent.phrases).shuffled()
    private var cursor = 0
    static let speed: CGFloat = 96

    func enqueue(_ text: String) { queued = Array((queued + [text]).suffix(10)) }

    func run(width: CGFloat, fontSize: CGFloat, lanes: Int) async {
        items.removeAll()
        laneReady = Array(repeating: .distantPast, count: lanes)
        defer { items.removeAll() }
        while !Task.isCancelled {
            let count = Int.random(in: 1...5)
            for _ in 0..<count {
                do { try await Task.sleep(for: .seconds(1.0 / Double(count))) } catch { return }
                guard !Task.isCancelled else { return }
                let now = Date()
                items.removeAll { now.timeIntervalSince($0.started) * Double(Self.speed) > Double($0.originX + $0.width + 16) }
                // Backpressure keeps text readable instead of overlapping busy lanes.
                guard let lane = laneReady.indices.filter({ laneReady[$0] <= now }).randomElement() else { continue }
                let own = !queued.isEmpty
                let text: String
                if own { text = queued.removeFirst() }
                else {
                    text = phrases[cursor % phrases.count]
                    cursor += 1
                    if cursor % phrases.count == 0 { phrases.shuffle() }
                }
                let font = UIFont.systemFont(ofSize: fontSize, weight: .semibold)
                let textWidth = ceil((text as NSString).size(withAttributes: [.font: font]).width) + 8
                items.append(MovingComment(text: text, lane: lane, started: now,
                    originX: width + 12, width: textWidth, isOwn: own))
                laneReady[lane] = now.addingTimeInterval(Double((textWidth + 40) / Self.speed))
            }
        }
    }
}

struct ScrollingCommentsView: View {
    let videoID: UUID
    let active: Bool
    let lanes: Int
    let bullet: ShortBullet?
    @StateObject private var flow = ScrollingComments()
    @ScaledMetric(relativeTo: .subheadline) private var textSize: CGFloat = 16
    private var fontSize: CGFloat { min(textSize, 24) }

    var body: some View {
        GeometryReader { bounds in
            TimelineView(.animation(minimumInterval: 1.0 / 30, paused: !active)) { timeline in
                Canvas { context, size in
                    context.addFilter(.shadow(color: .black.opacity(0.9), radius: 1, x: 0, y: 1))
                    for item in flow.items {
                        let elapsed = max(0, timeline.date.timeIntervalSince(item.started))
                        let x = item.originX - CGFloat(elapsed) * ScrollingComments.speed
                        let y = CGFloat(item.lane) * (fontSize + 12) + 4
                        let text = Text(item.text).font(.system(size: fontSize, weight: .semibold))
                            .foregroundColor(item.isOwn ? .init(red: 0.8, green: 1, blue: 0.65) : .white)
                        context.draw(context.resolve(text), at: CGPoint(x: x, y: y), anchor: .topLeading)
                    }
                }
            }
            .task(id: FlowKey(active: active, width: bounds.size.width, font: fontSize, lanes: lanes)) {
                guard active, bounds.size.width > 0 else { return }
                await flow.run(width: bounds.size.width, fontSize: fontSize, lanes: lanes)
            }
            .onChange(of: bullet?.id) { _, _ in
                if let bullet, bullet.videoID == videoID { flow.enqueue(bullet.text) }
            }
        }
        .frame(height: CGFloat(lanes) * (fontSize + 12) + 8)
        .clipped().allowsHitTesting(false).accessibilityHidden(true)
    }

    private struct FlowKey: Equatable {
        let active: Bool
        let width: CGFloat
        let font: CGFloat
        let lanes: Int
    }
}
