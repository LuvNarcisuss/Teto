import Combine
import Foundation

struct ShortComment: Identifiable, Codable {
    var id = UUID()
    let name: String
    let text: String
    var avatarAsset: String? = nil
    var parentID: UUID? = nil
    var replyToName: String? = nil
}

struct ShortBullet: Identifiable {
    let id = UUID()
    let videoID: UUID
    let text: String
}

/// Shared per-video state. Only publish mutations after their atomic disk write succeeds.
@MainActor
final class ShortsInteractionStore: ObservableObject {
    @Published private(set) var liked: Set<UUID> = []
    @Published private(set) var comments: [UUID: [ShortComment]] = [:]
    @Published private(set) var latestBullet: ShortBullet?
    @Published var bulletsEnabled = true
    @Published private var completedShares: [UUID: Int] = [:]
    @Published private(set) var isSaving = false
    @Published private(set) var storageError: String?
    private var loaded = false
    private var sessionActive = false
    private var preparedVideos: Set<UUID> = []
    private let repository: ShortsInteractionRepository
    static let maximumComments = 500

    init(root: URL) { repository = ShortsInteractionRepository(root: root) }

    func setSessionActive(_ active: Bool) { sessionActive = active }

    // Called only after writes have been stopped by AppStore.
    func clearAccountMemory() {
        sessionActive = false
        loaded = false
        preparedVideos = []
        apply(ShortsInteractionSnapshot())
        latestBullet = nil
        bulletsEnabled = true
        storageError = nil
    }

    func load() async throws {
        guard !loaded else { return }
        do {
            let snapshot = try await repository.load()
            apply(snapshot)
            preparedVideos = Set(snapshot.comments.keys)
            loaded = true
        } catch {
            // Keep the original file and prevent all writes until a successful reload.
            throw LocalLibraryError.unreadableLibrary
        }
    }

    func counts(for video: LocalVideo) -> ShortVideoCounts {
        let baseline = video.isBundled ? ShortVideoCounts.authored(for: video.id)
            : ShortVideoCounts(likes: 0, comments: 0, saves: 0, shares: 0)
        return ShortVideoCounts(likes: baseline.likes + (liked.contains(video.id) ? 1 : 0),
            comments: comments[video.id]?.count ?? (video.isBundled ? DanceDiscussionContent.commentCount(for: video.id) : 0),
            saves: baseline.saves + (video.isSaved ? 1 : 0),
            shares: baseline.shares + completedShares[video.id, default: 0])
    }

    func prepareComments(for video: LocalVideo) {
        guard loaded, sessionActive else { return }
        guard preparedVideos.insert(video.id).inserted else { return }
        let initial = (video.isBundled ? DanceDiscussionContent.lines(for: video) : []).map {
            ShortComment(name: $0.name, text: $0.text, avatarAsset: $0.avatarAsset)
        }
        comments[video.id] = initial + (comments[video.id] ?? [])
    }

    @discardableResult
    func toggleLike(_ id: UUID) async -> Bool {
        guard loaded, sessionActive, !isSaving else { return false }
        var updated = snapshot
        if updated.liked.contains(id) { updated.liked.remove(id) }
        else { updated.liked.insert(id) }
        return await commit(updated)
    }

    @discardableResult
    func addComment(_ text: String, to id: UUID, floating: Bool, replyingTo target: ShortComment? = nil) async -> Bool {
        guard loaded, sessionActive, !isSaving else { return false }
        storageError = nil
        let text = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, text.count <= (floating ? 80 : 200) else { return false }
        var entries = comments[id] ?? []
        guard entries.count < Self.maximumComments else { return false }
        if let target {
            guard !floating, entries.contains(where: { $0.id == target.id }),
                  entries.contains(where: { $0.id == (target.parentID ?? target.id) && $0.parentID == nil }) else { return false }
        }
        entries.append(ShortComment(name: "You", text: text,
            parentID: target.map { $0.parentID ?? $0.id }, replyToName: target?.name))
        var updated = snapshot
        updated.comments[id] = entries
        guard await commit(updated) else { return false }
        if floating {
            bulletsEnabled = true
            latestBullet = ShortBullet(videoID: id, text: text)
        }
        return true
    }

    @discardableResult
    func recordCompletedShare(for id: UUID) async -> Bool {
        // A system completion may arrive while a different local write is finishing.
        while isSaving {
            do { try await Task.sleep(for: .milliseconds(50)) } catch { return false }
        }
        guard loaded, sessionActive, !Task.isCancelled else { return false }
        var updated = snapshot
        updated.completedShares[id, default: 0] += 1
        return await commit(updated)
    }

    private var snapshot: ShortsInteractionSnapshot {
        ShortsInteractionSnapshot(liked: liked, comments: comments, completedShares: completedShares)
    }

    private func commit(_ updated: ShortsInteractionSnapshot) async -> Bool {
        guard loaded, sessionActive, !isSaving else { return false }
        isSaving = true
        storageError = nil
        defer { isSaving = false }
        do {
            try await repository.save(updated)
            // Read-only discussion seeding may happen while the actor writes. Preserve
            // newly opened videos without replacing the persisted snapshot's stable IDs.
            var merged = updated
            for (id, entries) in comments where merged.comments[id] == nil { merged.comments[id] = entries }
            apply(merged)
            return true
        } catch {
            storageError = "Your changes could not be saved. Please try again."
            return false
        }
    }

    private func apply(_ snapshot: ShortsInteractionSnapshot) {
        liked = snapshot.liked
        comments = snapshot.comments
        completedShares = snapshot.completedShares
    }
}

extension LocalVideo {
    var danceDescription: String {
        switch bundledClip?.assetName {
        case "dance-studio": return "Finding the groove, one eight-count at a time. Make this combo your own. #Dance #Choreography"
        case "dance-seaside": return "Fresh air, free movement, and a little freestyle. Where do you find your rhythm? #Freestyle #Dance"
        case "dance-hiphop-solo": return "Loose shoulders, grounded steps, and your own rhythm. #HipHop #Groove"
        case "dance-crew-rhythm": return "One beat, three different energies. Find your crew. #HipHop #CrewDance"
        case "dance-white-studio": return "A small combo with plenty of attitude. #HipHop #Practice"
        case "dance-hiphop-duet": return "Trade a step, share the rhythm. #DanceTogether #Choreography"
        case "dance-ballet-duet": return "Finding balance and moving as one. #Ballet #PartnerPractice"
        case "dance-studio-joy": return "Let the groove turn your practice into a good day. #Freestyle #Studio"
        case "dance-practice-partners": return "Learning the steps is better together. #DancePartners #Practice"
        case "dance-purple-groove": return "Follow the music and let your shoulders move. #Freestyle #Groove"
        case "dance-contemporary-flow": return "Explore the space between each movement. #ContemporaryDance #Flow"
        case "dance-ballet-class": return "Floorwork, flowing transitions, and shared rhythm. #ContemporaryDance #Floorwork"
        case "dance-urban-footwork": return "Take your rhythm outside. #StreetDance #Footwork"
        case "dance-street-power": return "Find your balance, then let the floor move you. #Breaking #Footwork"
        case "dance-bridge-freestyle": return "Make space for every move in the circle. #Breaking #DanceCrew"
        case "dance-court-session": return "New transitions, same love for the beat. #Breaking #Practice"
        case "dance-studio-chemistry": return "Count it in and move together. #Choreography #Studio"
        case "dance-group-rehearsal": return "Practice feels better with your people. #DanceTogether #Rehearsal"
        case "dance-expressive-arms": return "Let each movement flow into the next. #ContemporaryDance #Flow"
        case "dance-shared-rhythm": return "A little rhythm brings us closer. #PartnerDance #Groove"
        case "dance-sunny-salsa": return "One turn at a time, together. #Salsa #PartnerDance"
        case "dance-glitter-groove": return "Find your own way through the music. #Freestyle #Dance"
        case "dance-ballet-practice": return "Build the basics with every repetition. #Ballet #Practice"
        case "dance-street-crew": return "Bring your energy to the next eight-count. #StreetDance #DanceCrew"
        default: return "\(title) · Every step tells a story. #Dance #MyMoves"
        }
    }
    func creatorName(profile: LocalProfile) -> String { bundledClip?.creator ?? profile.displayName }
}

enum ShortsPanelKind: String { case floating, comments, profile, share, more, gifts }
struct ShortsPanel: Identifiable {
    let kind: ShortsPanelKind
    let video: LocalVideo
    var id: String { "\(video.id)-\(kind.rawValue)" }
}

/// Stable authored totals; no analytics or remote activity is inferred.
struct ShortVideoCounts {
    let likes: Int
    let comments: Int
    let saves: Int
    let shares: Int

    static func authored(for id: UUID) -> Self {
        func value(_ field: String) -> UInt64 {
            (id.uuidString + ":" + field).utf8.reduce(UInt64(14695981039346656037)) {
                ($0 ^ UInt64($1)) &* 1099511628211
            }
        }
        let likes = 10 + Int(value("likes") % 20)
        let saves = 10 + Int(value("saves") % 20)
        let shares = 10 + Int(value("shares") % 21)
        return Self(likes: likes, comments: DanceDiscussionContent.commentCount(for: id), saves: saves, shares: shares)
    }
}
