import SwiftUI

struct ShortsCommentSheet: View {
    let video: LocalVideo
    let floating: Bool
    @ObservedObject var social: ShortsInteractionStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOver
    @FocusState private var focused: Bool
    @State private var draft = ""
    @State private var failure: String?
    @State private var replyingTo: ShortComment?
    @State private var sending = false
    @State private var reportTarget: ContentSafetyTarget?
    private var limit: Int { floating ? 80 : 200 }
    private var entries: [ShortComment] { social.comments[video.id] ?? [] }
    private var displayedEntries: [ShortComment] {
        var replies: [UUID: [ShortComment]] = [:]
        for entry in entries {
            if let parent = entry.parentID { replies[parent, default: []].append(entry) }
        }
        return entries.filter { $0.parentID == nil }.flatMap { [$0] + replies[$0.id, default: []] }
    }
    private var placeholder: String {
        if let target = replyingTo { return "Reply to \(target.name)…" }
        return floating ? "Add a floating comment…" : "Add a comment…"
    }

    var body: some View {
        NavigationStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 20) {
                        if floating {
                            Toggle("Floating comments", isOn: $social.bulletsEnabled)
                            Text(reduceMotion || voiceOver
                                 ? "Moving text is paused by your accessibility settings. Your comments remain available here."
                                 : "Add a thought and watch it move across the video.")
                                .font(.subheadline).foregroundStyle(TetoStyle.muted)
                        }
                        if entries.isEmpty {
                            ContentUnavailableView("Start the conversation", systemImage: "bubble.left.and.bubble.right",
                                description: Text("Talk about the steps, the rhythm, or your next practice."))
                        }
                        ForEach(displayedEntries) { entry in
                            commentRow(entry).padding(.leading, entry.parentID == nil ? 0 : 24).id(entry.id)
                        }
                    }.padding(20)
                }
                .scrollDismissesKeyboard(.interactively)
                .onChange(of: entries.last?.id) { _, id in
                    if let id { proxy.scrollTo(id, anchor: .bottom) }
                }
            }
            .safeAreaInset(edge: .bottom, spacing: 0) { composer }
            .freshStudioPage()
            .tetoNavigationTitle(floating ? "Floating comments" : "Comments (\(social.counts(for: video).comments))")
            .navigationBarTitleDisplayMode(.inline)
            .interactiveDismissDisabled(sending)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { focused = false; dismiss() }.disabled(sending) } }
            .task { social.prepareComments(for: video); if floating { focused = true } }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
            .sheet(item: $reportTarget) { target in
                NavigationStack {
                    ContentReportView(target: target)
                        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { reportTarget = nil } } }
                }.tint(TetoStyle.emerald).preferredColorScheme(.light)
            }
    }

    private func commentRow(_ entry: ShortComment) -> some View {
        HStack(alignment: .top, spacing: 12) {
            if let asset = entry.avatarAsset {
                Image(asset).resizable().scaledToFill()
                    .frame(width: 36, height: 36).clipShape(Circle()).accessibilityHidden(true)
            } else {
                ProfileAvatar(symbol: "figure.dance", size: 36)
            }
            VStack(alignment: .leading, spacing: 5) {
                Text(entry.name).font(.subheadline.bold())
                if let name = entry.replyToName {
                    Text("Replying to \(name)").font(.caption).foregroundStyle(TetoStyle.emerald)
                }
                Text(entry.text).font(.body).fixedSize(horizontal: false, vertical: true)
                if !floating {
                    Button {
                        replyingTo = entry
                        failure = nil
                        focused = true
                    } label: {
                        Label("Reply", systemImage: "arrowshape.turn.up.left")
                            .font(.caption.weight(.semibold)).frame(minWidth: 44, minHeight: 44, alignment: .leading)
                    }
                    .buttonStyle(.plain).foregroundStyle(TetoStyle.muted).disabled(sending)
                    .accessibilityLabel("Reply to \(entry.name)")
                    .accessibilityHint(entry.text)
                }
            }.frame(maxWidth: .infinity, alignment: .leading)
            if entry.name != "You" {
                Button {
                    focused = false
                    reportTarget = .comment(id: "short:\(video.id):\(entry.id)", name: entry.name, text: entry.text)
                } label: {
                    Image(systemName: "flag").font(.caption).frame(width: 44, height: 44)
                }.buttonStyle(.plain).foregroundStyle(TetoStyle.muted)
                    .accessibilityLabel("Report comment by \(entry.name)")
                    .accessibilityHint(entry.text).disabled(sending)
            }
        }
    }

    private var composer: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let target = replyingTo {
                HStack(spacing: 8) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Replying to \(target.name)").font(.caption.weight(.semibold))
                        Text(target.text).font(.caption).lineLimit(1).foregroundStyle(TetoStyle.muted)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                    Button { replyingTo = nil; failure = nil } label: {
                        Image(systemName: "xmark").frame(width: 44, height: 44)
                    }.buttonStyle(.plain).accessibilityLabel("Cancel reply").disabled(sending)
                }.foregroundStyle(TetoStyle.emerald)
            }
            if let failure { Text(failure).font(.caption).foregroundStyle(.red) }
            HStack(alignment: .bottom, spacing: 10) {
                TextField(placeholder, text: $draft, axis: .vertical)
                    .lineLimit(1...4).padding(12).background(TetoStyle.soft, in: RoundedRectangle(cornerRadius: 20))
                    .focused($focused).submitLabel(.send).onSubmit(send)
                    .accessibilityLabel(replyingTo == nil ? (floating ? "Floating comment" : "Comment") : "Reply")
                    .disabled(sending)
                Button(action: send) {
                    Group {
                        if sending { ProgressView().tint(.white) }
                        else { Image(systemName: "arrow.up").font(.headline) }
                    }.frame(width: 44, height: 44)
                        .background(TetoStyle.emerald, in: Circle()).foregroundStyle(.white)
                }.accessibilityLabel(replyingTo == nil ? "Send comment" : "Send reply")
                    .disabled(sending || social.isSaving || draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || draft.count > limit)
            }
            Text("\(draft.count)/\(limit)").font(.caption2).foregroundStyle(draft.count > limit ? .red : .secondary)
        }.padding(16).background(TetoStyle.chromeGradient)
    }

    private func send() {
        guard !sending, !social.isSaving else { return }
        guard entries.count < ShortsInteractionStore.maximumComments else {
            failure = "This conversation has reached its comment limit."
            return
        }
        let submitted = draft
        let target = replyingTo
        sending = true
        failure = nil
        Task { @MainActor in
            let saved = await social.addComment(submitted, to: video.id, floating: floating, replyingTo: target)
            sending = false
            guard saved else {
                failure = social.storageError ?? "Unable to add this comment. Use up to \(limit) characters and check the reply target."
                return
            }
            draft = ""; failure = nil; replyingTo = nil
            if floating { focused = false; dismiss() }
        }
    }
}
