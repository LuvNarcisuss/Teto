import PhotosUI
import SwiftUI

struct PartyFilterSheet: View {
    @Binding var filter: PartyFilter
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            Form {
                Section("Room type") {
                    Picker("Type", selection: $filter.kind) {
                        ForEach(PartyFilter.Kind.allCases) { Text($0.rawValue).tag($0) }
                    }.pickerStyle(.inline).labelsHidden()
                }
                Section("Order") { Toggle("Most popular first", isOn: $filter.popularFirst) }
                Button("Reset filters") { filter = PartyFilter() }
            }
            .freshStudioPage()
            .tetoNavigationTitle("Filter parties").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}

struct PartyBrowseSheet: View {
    let rooms: [PartyRoom]
    let searchOnOpen: Bool
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    @State private var selection: PartyRoom?
    private var results: [PartyRoom] {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return rooms.filter { term.isEmpty || "\($0.title) \($0.description) \($0.category.title)".localizedCaseInsensitiveContains(term) }
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                if results.isEmpty {
                    ContentUnavailableView.search(text: query).padding(.top, 32)
                } else { PartyRoomGrid(rooms: results) { selection = $0 }.padding(16) }
            }
                .scrollDismissesKeyboard(.interactively)
            .safeAreaInset(edge: .top, spacing: 0) {
                TopSearchBar(query: $query, prompt: "Search parties or dance styles",
                             focusOnAppear: searchOnOpen, isActive: selection == nil,
                             cancelTitle: "Done", cancel: { dismiss() })
            }
            .freshStudioPage()
            .toolbar(.hidden, for: .navigationBar)
            .fullScreenCover(item: $selection) { PartyDetailsView(room: $0) }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}

struct PartyDetailsView: View {
    let room: PartyRoom
    var body: some View { VoicePartyRoomView(room: room) }
}

struct PartyCreationSheet: View {
    @EnvironmentObject private var app: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: VoiceRoomDraft
    @State private var category: PartyCategory
    @State private var type: PartyRoomType
    @State private var failure: String?
    @State private var discard = false
    private let original: VoiceRoomDraft
    init(existing: VoiceRoomDraft? = nil) {
        let draft = existing ?? VoiceRoomDraft()
        original = draft
        _draft = State(initialValue: draft)
        _category = State(initialValue: draft.danceCategory.flatMap(PartyCategory.init(rawValue:)) ?? .freestyle)
        _type = State(initialValue: draft.partyType.flatMap(PartyRoomType.init(rawValue:)) ?? .voice)
    }
    private var changed: Bool {
        draft != original || category.rawValue != (original.danceCategory ?? PartyCategory.freestyle.rawValue)
        || type.rawValue != (original.partyType ?? PartyRoomType.voice.rawValue)
    }
    var body: some View {
        NavigationStack {
            Form {
                Section("Your dance party") {
                    TextField("Party name", text: $draft.title, axis: .vertical).lineLimit(1...3)
                    Text("\(draft.title.count)/60 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                    TextField("What would you like to talk about?", text: $draft.description, axis: .vertical).lineLimit(3...6)
                    Text("\(draft.description.count)/240 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                }
                Section("Make it your space") {
                    Picker("Dance style", selection: $category) { ForEach(PartyCategory.allCases) { Text($0.title).tag($0) } }
                    Picker("Party type", selection: $type) { ForEach(PartyRoomType.allCases) { Text($0.rawValue).tag($0) } }
                }
                Section {
                    Text("Save a private room draft.").font(.footnote).foregroundStyle(TetoStyle.muted)
                    if let failure { Text(failure).foregroundStyle(.red) }
                }
            }
            .scrollDismissesKeyboard(.interactively).disabled(app.isBusy)
            .freshStudioPage()
            .tetoNavigationTitle("Create a party").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { if changed { discard = true } else { dismiss() } }.disabled(app.isBusy) }
                ToolbarItem(placement: .confirmationAction) {
                    Button(app.isBusy ? "Saving…" : "Save") {
                        draft.danceCategory = category.rawValue; draft.partyType = type.rawValue
                        Task {
                            if await app.saveRoom(draft) { dismiss() }
                            else { failure = app.lastSaveError ?? "Check the party name and description." }
                        }
                    }.disabled(app.isBusy || draft.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || draft.title.count > 60 || draft.description.count > 240)
                }
            }
            .interactiveDismissDisabled(app.isBusy || changed)
            .confirmationDialog("Discard changes?", isPresented: $discard, titleVisibility: .visible) {
                Button("Discard", role: .destructive) { dismiss() }
            }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}

struct DancePostSheet: View {
    var body: some View { ShortVideoCreationView() }
}

struct PartyToolSheet: View {
    let tool: PartyTool
    @Environment(\.dismiss) private var dismiss
    @State private var mood: PartyCategory?
    @State private var card = 0
    private let prompts = ["Which song always gets you moving?", "What step are you working on this week?", "Who inspired you to start dancing?", "What was your favorite moment in class?", "What would you like to learn next?"]
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    switch tool {
                    case .mood:
                        Text("What are you feeling today?").font(TetoTypography.section)
                        ForEach(PartyCategory.allCases) { category in
                            Button { mood = category } label: {
                                HStack { Label(category.title, systemImage: category.symbol); Spacer(); if mood == category { Image(systemName: "checkmark") } }
                                    .frame(minHeight: 44)
                            }
                        }
                    case .cards:
                        Text("Break the ice").font(TetoTypography.section)
                        Text(prompts[card]).font(.title3).padding(24).frame(maxWidth: .infinity, minHeight: 140)
                            .background(PartyStyle.surface, in: RoundedRectangle(cornerRadius: 20))
                        Button("Next card") { card = (card + 1) % prompts.count }.frame(minHeight: 44)
                    case .orbit:
                        Image(systemName: "globe.americas").font(.system(size: 48)).foregroundStyle(PartyStyle.teal)
                        Text("Find your dance circle").font(TetoTypography.section)
                        Text("A space for the people who share your love of movement.")
                        Text("Unable to connect right now.").font(.footnote).foregroundStyle(TetoStyle.muted)
                    }
                }.padding(24)
            }
            .freshStudioPage()
            .tetoNavigationTitle(tool.title).navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}
