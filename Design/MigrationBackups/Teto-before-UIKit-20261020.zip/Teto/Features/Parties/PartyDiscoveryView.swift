import SwiftUI

struct PartyDiscoveryView: View {
    @EnvironmentObject private var app: AppStore
    @StateObject private var discovery: PartyDiscoveryStore
    @State private var sheet: PartySheet?
    @State private var selectedRoom: PartyRoom?
    @State private var searching = false
    @State private var query = ""
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var refreshTask: Task<Void, Never>?
    private var allRooms: [PartyRoom] { app.library.roomDrafts.map(DancePartyCatalog.room(from:)) + discovery.rooms }
    private var rooms: [PartyRoom] {
        guard searching else { return discovery.visibleRooms(in: allRooms) }
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return allRooms.filter { term.isEmpty || "\($0.title) \($0.description) \($0.category.title)".localizedCaseInsensitiveContains(term) }
    }

    init(service: (any PartyDiscoveryServing)? = nil) {
        _discovery = StateObject(wrappedValue: PartyDiscoveryStore(service: service))
    }

    var body: some View {
        VStack(spacing: 0) {
            if searching {
                TopSearchBar(query: $query, prompt: "Search parties or dance styles",
                             isActive: selectedRoom == nil, cancel: endSearch)
            } else {
                DiscoveryHeaderView(filtered: discovery.filter.isActive,
                                    tool: { sheet = .tool($0) }, filter: { sheet = .filter }, search: beginSearch,
                                    create: { sheet = .create }, refresh: refresh, all: { sheet = .all })
                    .padding(.horizontal, 16).padding(.top, 4)
                GameCategoryStrip(selected: $discovery.category)
                    .padding(.top, 8).padding(.bottom, 10)
            }
            ScrollView {
                VStack(spacing: 16) {
                    if let failure = discovery.failure {
                        VStack(spacing: 8) {
                            Text(failure).font(.subheadline)
                            Button("Try again", action: refresh).frame(minHeight: 44)
                        }.padding().frame(maxWidth: .infinity).background(PartyStyle.surface, in: RoundedRectangle(cornerRadius: 14))
                    }
                    if discovery.loading && allRooms.isEmpty {
                        ProgressView("Finding your dance circle…").tint(PartyStyle.teal).padding(.top, 60)
                    } else if rooms.isEmpty {
                        if searching {
                            ContentUnavailableView.search(text: query)
                        } else {
                            ContentUnavailableView("No parties found", systemImage: "figure.dance", description: Text("Try another dance style or clear your filters."))
                            Button("Clear filters") { discovery.category = nil; discovery.filter = PartyFilter() }.frame(minHeight: 44)
                        }
                    } else {
                        PartyRoomGrid(rooms: rooms) { selectedRoom = $0 }
                    }
                }.padding(.horizontal, 16).padding(.bottom, 16)
            }
            .id(searching)
            .scrollDismissesKeyboard(.interactively)
            .refreshable { await discovery.refresh() }

        }
        .foregroundStyle(PartyStyle.pageText).background { FreshStudioPageBackground().ignoresSafeArea() }
        .preferredColorScheme(.light).tint(TetoStyle.emerald)
        .toolbar(.hidden, for: .navigationBar)
        .toolbarBackground(.automatic, for: .tabBar)
        .toolbarColorScheme(.dark, for: .tabBar)
        .task { if !discovery.loaded { await discovery.refresh(reorder: false) } }
        .onDisappear { refreshTask?.cancel(); refreshTask = nil }
        .sheet(item: $sheet) { item in
            switch item {
            case .filter:
                PartyFilterSheet(filter: $discovery.filter)
                    .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
            case .create: PartyCreationSheet()
            case .all:
                PartyBrowseSheet(rooms: allRooms, searchOnOpen: false)
            case .tool(let tool): PartyToolSheet(tool: tool)
                .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
            }
        }
        .fullScreenCover(item: $selectedRoom) { room in PartyDetailsView(room: room) }
    }
    private func beginSearch() {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) { searching = true }
    }
    private func endSearch() {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) {
            searching = false
            query = ""
        }
    }
    private func refresh() {
        guard !discovery.loading else { return }
        refreshTask?.cancel()
        refreshTask = Task { await discovery.refresh() }
    }
}

private enum PartySheet: Identifiable, Equatable {
    case filter, create, all, tool(PartyTool)
    var id: String { String(describing: self) }
}

#Preview("Dance parties") {
    NavigationStack { PartyDiscoveryView() }.environmentObject(AppStore())
}
#Preview("Dance parties / Large Type") {
    NavigationStack { PartyDiscoveryView() }
        .environmentObject(AppStore()).environment(\.dynamicTypeSize, .accessibility1)
}
#Preview("Dance room cards") {
    ScrollView { PartyRoomGrid(rooms: DancePartyCatalog.rooms, open: { _ in }).padding(16) }
        .background { FreshStudioPageBackground() }.preferredColorScheme(.light)
}

private struct PartyEmptySource: PartyDiscoveryServing {
    func rooms() async throws -> [PartyRoom] { [] }
}
private struct PartyUnavailableSource: PartyDiscoveryServing {
    func rooms() async throws -> [PartyRoom] { throw URLError(.notConnectedToInternet) }
}
#Preview("No parties") {
    NavigationStack { PartyDiscoveryView(service: PartyEmptySource()) }
        .environmentObject(AppStore())
}
#Preview("Connection failure") {
    NavigationStack { PartyDiscoveryView(service: PartyUnavailableSource()) }
        .environmentObject(AppStore())
}
