import SwiftUI

private enum VoiceRoomPanel: String, Identifiable {
    case details, members, topics, music, note, join, share, edit
    var id: String { rawValue }
}

struct VoicePartyRoomView: View {
    let room: PartyRoom
    @EnvironmentObject private var app: AppStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOver
    @State private var isVisible = false
    @State private var chatFlowEnabled = true
    @State private var followingLatest = true
    @State private var pendingMessages = 0
    @State private var messageCursor = 0
    @State private var chatLines = VoiceRoomChatScript.lines.shuffled()
    @State private var following = false
    @State private var focusedLayout = false
    @State private var panel: VoiceRoomPanel?
    @State private var reportTarget: ContentSafetyTarget?
    @State private var note = ""
    @State private var notes: [VoiceRoomNote] = []
    private var draft: VoiceRoomDraft? { app.library.roomDrafts.first { $0.id == room.draftID } }
    private var current: PartyRoom { draft.map(DancePartyCatalog.room(from:)) ?? room }
    private var members: [PartyParticipant] { current.participants }
    private var chatFlowActive: Bool {
        isVisible && scenePhase == .active && panel == nil && reportTarget == nil && app.notice == nil
        && chatFlowEnabled && !voiceOver && !members.isEmpty
    }
    private var accent: Color { TetoStyle.emerald }

    var body: some View {
        VStack(spacing: 12) {
            header
            if !focusedLayout {
                roomLinks
                topicCards
            }
            if typeSize.isAccessibilitySize && !focusedLayout {
                ScrollView(.horizontal, showsIndicators: false) { memberRail(horizontal: true) }
            }
            HStack(alignment: .top, spacing: 12) {
                conversation
                if !focusedLayout && !typeSize.isAccessibilitySize {
                    ScrollView(showsIndicators: false) { memberRail(horizontal: false) }
                        .frame(width: 70)
                }
            }
        }
        .padding(.horizontal, 12).padding(.top, 6)
        .foregroundStyle(TetoStyle.ink)
        .background { VoiceRoomBackdrop().ignoresSafeArea() }
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomBar }
        .toolbar(.hidden, for: .navigationBar, .tabBar)
        .preferredColorScheme(.light)
        .tint(accent)
        .onAppear { isVisible = true }
        .onDisappear { isVisible = false }
        .task(id: chatFlowActive) { await appendChatLoop() }
        .sheet(item: $reportTarget) { target in
            NavigationStack {
                ContentReportView(target: target)
                    .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { reportTarget = nil } } }
            }.preferredColorScheme(.light).tint(accent)
        }
        .sheet(item: $panel) { value in
            switch value {
            case .share: LiveShareSheet(text: "Join the conversation about \(current.category.title): \(current.title) · Teto")
            case .edit: PartyCreationSheet(existing: draft)
            case .note:
                VoiceRoomNoteSheet(text: $note) { text in
                    followingLatest = true
                    pendingMessages = 0
                    notes.append(VoiceRoomNote(text: text))
                    trimConversation()
                    note = ""
                }
            default: roomPanel(value)
            }
        }
    }

    @MainActor private func appendChatLoop() async {
        guard chatFlowActive else { return }
        while !Task.isCancelled {
            do { try await Task.sleep(for: .seconds(Double.random(in: 1...2))) }
            catch { return }
            guard !Task.isCancelled, chatFlowActive else { return }
            let count = Int.random(in: 1...3)
            for _ in 0..<count {
                if messageCursor >= chatLines.count {
                    chatLines.shuffle()
                    messageCursor = 0
                }
                let index = Int.random(in: 0..<members.count)
                notes.append(VoiceRoomNote(text: chatLines[messageCursor],
                                           name: members[index].name,
                                           asset: members[index].asset, highlighted: true))
                messageCursor += 1
            }
            trimConversation()
            if !followingLatest { pendingMessages = min(pendingMessages + count, 200) }
        }
    }

    private func trimConversation() {
        if notes.count > 200 { notes.removeFirst(notes.count - 200) }
    }

    private var header: some View {
        HStack(alignment: .top, spacing: 8) {
            VStack(alignment: .leading, spacing: 5) {
                Text(current.title).font(TetoTypography.headline).lineLimit(2)
                Text("\(current.category.title) · Dance circle")
                    .font(.caption).foregroundStyle(TetoStyle.muted).lineLimit(1)
            }.frame(maxWidth: .infinity, alignment: .leading)
            Button { following.toggle() } label: {
                Text(following ? "Following" : "Follow")
                    .font(.caption.weight(.semibold)).padding(.horizontal, 12).frame(minWidth: 44, minHeight: 44)
                    .foregroundStyle(Color.white).background(accent, in: Capsule())
            }.accessibilityLabel(following ? "Unfollow room" : "Follow room")
            iconButton(focusedLayout ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right",
                       label: focusedLayout ? "Show room panels" : "Focus on conversation") {
                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) { focusedLayout.toggle() }
            }
            iconButton("xmark", label: "Leave room") { isVisible = false; dismiss() }
        }.buttonStyle(.plain)
    }

    private var roomLinks: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                pill("Dance talk", symbol: "waveform", action: { panel = .details })
                pill("Room notes", symbol: "text.bubble", action: { panel = .topics })
                pill("\(members.count) members", symbol: "person.2", action: { panel = .members })
            }
        }
    }

    private var topicCards: some View {
        HStack(spacing: 8) {
            topicCard("EIGHT COUNT", title: "Find your groove", symbol: current.category.symbol,
                      colors: [TetoStyle.emerald, TetoStyle.ink]) { panel = .topics }
            topicCard("AFTER CLASS", title: "The cool-down", symbol: "music.note",
                      colors: [TetoStyle.ink, TetoStyle.emerald]) { panel = .music }
        }
    }

    private var conversation: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 20) {
                    if !members.isEmpty {
                        chatLine(name: members[0].name, asset: members.first?.asset,
                                 text: "What are you dancing to today?", highlighted: true)
                    }
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Good energy only").font(.subheadline.weight(.semibold))
                        Text("Share a practice tip, celebrate small wins and make space for every dancer. Keep personal details private.")
                            .font(.subheadline).lineSpacing(4)
                        Button("About this room") { panel = .details }
                            .font(.subheadline.weight(.semibold)).foregroundStyle(TetoStyle.emerald)
                            .frame(minHeight: 44)
                    }
                    .foregroundStyle(accent).padding(16).frame(maxWidth: .infinity, alignment: .leading)
                    .background(TetoStyle.lime.opacity(0.32), in: RoundedRectangle(cornerRadius: 16))
                    if members.count > 1 {
                        chatLine(name: members[1].name, asset: members[1].asset,
                                 text: "Working on my \(current.category.title.lowercased()) groove. That last eight-count is tricky!", highlighted: true)
                    }
                    if members.count > 2 {
                        chatLine(name: members[2].name, asset: members[2].asset,
                                 text: "Slow it down, feel the beat, then build it back up.", highlighted: false)
                    }
                    if members.count > 3 {
                        HStack(alignment: .top, spacing: 8) {
                            PartyAvatarView(asset: members[3].asset, size: 32, name: members[3].name)
                            VStack(alignment: .leading, spacing: 10) {
                                Text("A new groove starts with hello.").font(.subheadline)
                                Button("Break the ice") { note = "What song gets you moving?"; panel = .note }
                                    .font(.subheadline.weight(.semibold)).foregroundStyle(Color.white)
                                    .padding(.horizontal, 16).frame(minHeight: 44).background(accent, in: Capsule())
                            }.padding(14).frame(maxWidth: .infinity, alignment: .leading)
                                .background(TetoStyle.card, in: RoundedRectangle(cornerRadius: 16))
                                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(TetoStyle.line))
                        }
                    }
                    ForEach(notes) { note in
                        chatLine(name: note.name, asset: note.asset, text: note.text, highlighted: note.highlighted)
                            .id(note.id)
                    }
                    Color.clear.frame(height: 12).id("latest-note")
                }.padding(.top, 2)
            }.scrollIndicators(.hidden)
                .simultaneousGesture(DragGesture(minimumDistance: 8).onChanged { _ in followingLatest = false })
                .accessibilityAction(named: "Read earlier messages") { followingLatest = false }
                .overlay(alignment: .bottom) {
                    if !followingLatest && pendingMessages > 0 {
                        Button {
                            followingLatest = true
                            pendingMessages = 0
                            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) {
                                proxy.scrollTo("latest-note", anchor: .bottom)
                            }
                        } label: {
                            Label("\(pendingMessages) new messages", systemImage: "arrow.down")
                                .font(.caption.weight(.semibold)).padding(.horizontal, 14).frame(minHeight: 44)
                                .foregroundStyle(Color.white).background(TetoStyle.emerald, in: Capsule())
                        }.buttonStyle(.plain).padding(.bottom, 6)
                    }
                }
                .onChange(of: notes.last?.id) { _, _ in
                    guard followingLatest else { return }
                    withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) { proxy.scrollTo("latest-note", anchor: .bottom) }
                }
        }
    }

    @ViewBuilder private func memberRail(horizontal: Bool) -> some View {
        let layout = horizontal ? AnyLayout(HStackLayout(spacing: 14)) : AnyLayout(VStackLayout(spacing: 18))
        layout {
            ForEach(Array(members.enumerated()), id: \.element.id) { index, person in
                Button { panel = .members } label: {
                    VStack(spacing: 6) {
                        PartyAvatarView(asset: person.asset, size: 48, name: person.name)
                            .overlay(alignment: .topLeading) {
                                if index == 0 {
                                    Image(systemName: "crown.fill").font(.caption).foregroundStyle(.yellow).offset(x: -3, y: -4)
                                }
                            }
                        Text(index == 0 ? "Host" : "\(index + 1)")
                            .font(.caption.weight(.medium)).padding(.horizontal, 10).padding(.vertical, 5)
                            .background(index == 0 ? TetoStyle.lime : TetoStyle.soft, in: Capsule())
                    }.frame(minWidth: 60, minHeight: 80)
                }.accessibilityLabel(index == 0 ? "View host and members" : "View member \(index + 1)")
            }
            if members.isEmpty {
                Image(systemName: "person.crop.circle.badge.plus").font(.largeTitle).frame(width: 60, height: 60)
                    .accessibilityLabel("No members listed")
            }
            Button { panel = .share } label: {
                VStack(spacing: 7) {
                    Image(systemName: "person.badge.plus").font(.title2).frame(width: 48, height: 48)
                        .foregroundStyle(Color.white).background(TetoStyle.emerald, in: Circle())
                    Text("Invite").font(.caption)
                }.frame(minWidth: 60, minHeight: 80)
            }.accessibilityLabel("Share room invitation")
        }.buttonStyle(.plain)
    }

    private var bottomBar: some View {
        VStack(spacing: 10) {
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(["Let's talk dance", "After practice", "Find my groove"], id: \.self) { prompt in
                        Button { note = prompt; panel = .note } label: {
                            Text(prompt).font(.caption).padding(.horizontal, 12).frame(minHeight: 44)
                                .background(TetoStyle.soft, in: Capsule())
                        }
                    }
                }
            }
            ViewThatFits(in: .horizontal) {
                controls(expanded: true)
                controls(expanded: false)
            }
        }.buttonStyle(.plain).foregroundStyle(TetoStyle.ink)
            .padding(.horizontal, 12).padding(.top, 8).padding(.bottom, 8)
            .background(TetoStyle.chromeGradient)
    }

    private func controls(expanded: Bool) -> some View {
        HStack(spacing: 8) {
            iconButton("square.grid.2x2", label: "Room settings") { panel = .details }
            Button { panel = .note } label: {
                Text("Say something…").font(.subheadline).lineLimit(1)
                    .frame(minWidth: 90, maxWidth: .infinity, minHeight: 46, alignment: .leading)
                    .padding(.horizontal, 12).background(TetoStyle.card, in: Capsule())
            }.accessibilityLabel("Write a private room note")
            if expanded { iconButton("music.note", label: "Practice playlist") { panel = .music } }
            Button { panel = .join } label: {
                Text("Join").font(.subheadline.weight(.semibold)).padding(.horizontal, 14).frame(minHeight: 46)
                    .foregroundStyle(Color.white).background(TetoStyle.emerald, in: Capsule())
                    .overlay(Capsule().strokeBorder(.white.opacity(0.25)))
            }.accessibilityLabel("Join voice chat")
        }
    }

    private func chatLine(name: String, asset: String?, text: String, highlighted: Bool) -> some View {
        HStack(alignment: .top, spacing: 8) {
            PartyAvatarView(asset: asset, size: 32, name: name)
            VStack(alignment: .leading, spacing: 8) {
                Text(name).font(.caption).foregroundStyle(TetoStyle.muted)
                Text(text).font(.subheadline).lineSpacing(3)
                    .foregroundStyle(highlighted ? accent : TetoStyle.ink).padding(13)
                    .background(highlighted ? TetoStyle.soft : TetoStyle.card, in: RoundedRectangle(cornerRadius: 16))
            }
            Spacer(minLength: 0)
        }
        .contextMenu {
            if name != "You" {
                Button("Report comment", systemImage: "flag") {
                    reportTarget = .comment(id: "voice:\(current.id):\(name):\(text)", name: name, text: text)
                }
            }
        }
    }

    private func iconButton(_ symbol: String, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: symbol).font(.system(size: 19, weight: .medium)).frame(width: 44, height: 44)
                .background(TetoStyle.card, in: Circle())
        }.accessibilityLabel(label)
    }

    private func pill(_ title: String, symbol: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: symbol).font(.caption).padding(.horizontal, 12).frame(minHeight: 44)
                .background(TetoStyle.soft, in: Capsule())
        }.buttonStyle(.plain)
    }

    private func topicCard(_ eyebrow: String, title: String, symbol: String, colors: [Color], action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 6) {
                Label(eyebrow, systemImage: symbol).font(.system(size: 9, weight: .bold)).tracking(1)
                Text(title).font(.subheadline.weight(.semibold))
            }.foregroundStyle(Color.white).frame(maxWidth: .infinity, minHeight: 44, alignment: .leading).padding(12)
                .background(LinearGradient(colors: colors, startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 13))
        }.buttonStyle(.plain)
    }

    private func roomPanel(_ value: VoiceRoomPanel) -> some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    switch value {
                    case .members:
                        Text("Room members").font(TetoTypography.section)
                        ForEach(Array(members.enumerated()), id: \.element.id) { index, member in
                            HStack(spacing: 12) {
                                PartyAvatarView(asset: member.asset, size: 44, name: member.name)
                                Text(member.name)
                                Spacer()
                                if index == 0 { Text("Host").foregroundStyle(TetoStyle.muted) }
                            }
                        }
                        if members.isEmpty { Text("No members listed yet.") }
                    case .join:
                        Image(systemName: "mic.slash").font(.largeTitle).foregroundStyle(PartyStyle.teal)
                        Text("Voice chat is unavailable").font(TetoTypography.section)
                        Text("Your microphone is off.")
                    case .topics:
                        Text("Find your next conversation").font(TetoTypography.section)
                        ForEach(["Which eight-count needs more practice?", "What makes a groove feel like you?", "Share your favorite warm-up.", "What did you learn in your last class?"], id: \.self) {
                            Text($0).padding(16).frame(maxWidth: .infinity, alignment: .leading)
                                .background(TetoStyle.soft, in: RoundedRectangle(cornerRadius: 16))
                        }
                    case .music:
                        Text("Build your practice playlist").font(TetoTypography.section)
                        Text("Start slow, find your rhythm, then finish with a track you love.")
                        Label("Warm-up · Gentle grooves", systemImage: "sun.max")
                        Label("Practice · Eight-count loops", systemImage: "repeat")
                        Label("Cool-down · Slow rhythms", systemImage: "moon")
                        Text("Music playback is unavailable.").font(.footnote).foregroundStyle(TetoStyle.muted)
                    default:
                        Text(current.title).font(TetoTypography.section)
                        Text(current.description.isEmpty ? "A space to connect through dance." : current.description)
                        Label(current.category.title, systemImage: current.category.symbol)
                        Toggle("Chat flow", isOn: $chatFlowEnabled)
                        Text("Room notes are private and are cleared when you leave.")
                            .font(.footnote).foregroundStyle(TetoStyle.muted)
                        if draft != nil {
                            Text("Private draft · Not published").font(.footnote)
                            Button("Edit party") { panel = .edit }.frame(minHeight: 44)
                        }
                    }
                }.padding(24).frame(maxWidth: .infinity, alignment: .leading)
            }
            .freshStudioPage().tetoNavigationTitle("Dance circle").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { panel = nil } } }
        }.preferredColorScheme(.light)
            .presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }
}

private struct VoiceRoomNote: Identifiable {
    let id = UUID()
    let text: String
    var name = "You · Private note"
    var asset: String? = nil
    var highlighted = false
}

/// Authored conversation lines; no network messages or delivery events are generated.
private enum VoiceRoomChatScript {
    static let lines = [
        "What track is everyone practicing to?",
        "That last eight-count has been stuck in my head all day.",
        "I finally got the transition without looking at the mirror.",
        "Slow practice makes the fast version feel so much easier.",
        "Anyone else count out loud while learning a routine?",
        "The groove matters more than rushing through the steps.",
        "A little shoulder bounce changes the whole feeling.",
        "I am working on cleaner weight transfers this week.",
        "My warm-up playlist is getting longer than my practice playlist.",
        "Try keeping your knees soft through that section.",
        "The music feels different when you listen for the bass.",
        "What was your favorite part of class today?",
        "I love seeing everyone bring their own style to a combo.",
        "Five minutes of freestyle is my favorite way to reset.",
        "That pause before the beat drops is everything.",
        "I keep forgetting what my arms are supposed to do!",
        "Footwork first, then I add the upper body.",
        "One clean eight-count is still progress.",
        "What dance style would you like to try next?",
        "Jazz class always reminds me to finish my lines.",
        "House footwork is such a good stamina workout.",
        "Learning a chorus with friends makes it so much more fun.",
        "I am trying to look up instead of watching my feet.",
        "A softer landing made that step feel much better.",
        "Does anyone have a favorite way to practice turns?",
        "Finding a spot to focus on really helps my balance.",
        "Remember to leave a little time for a cool-down.",
        "I filmed one take just to check my timing.",
        "The small details make a simple move look so good.",
        "Sometimes the best practice is just listening to the song.",
        "New goal: enjoy the routine without checking the mirror.",
        "I am learning to make the quiet moments count too.",
        "A little practice every day adds up.",
        "That rhythm makes me want to get up and move.",
        "Which part of the routine feels most like you?",
        "Today was a good day for finding my own groove.",
        "Water break, then one more round.",
        "I like marking the steps before trying them full out.",
        "The second half is finally starting to click.",
        "No perfect takes needed. Just keep exploring.",
        "How do you remember a long combination?",
        "I break it into sections and connect them slowly.",
        "A change of direction can make a move feel brand new.",
        "I want to try the same combo with a different texture.",
        "Relaxing my shoulders helped more than I expected.",
        "There is always something new to hear in the music.",
        "Taking a rest day is part of getting better too.",
        "Same beat, a whole room of different grooves.",
        "Do you prefer learning from the front or a mirrored view?",
        "I finally remembered the arms without forgetting the feet.",
        "Anyone practicing a new style this month?",
        "My favorite warm-up is a few minutes of easy groove.",
        "I used to skip the slow practice. Not anymore.",
        "What helps you feel less nervous in an open class?",
        "I stand where I can see the teacher's feet clearly.",
        "A small dance circle with friends sounds perfect tonight.",
        "Trying the same move with different music is surprisingly fun.",
        "I wrote the counts down before I forgot them again.",
        "The first class is always the hardest one to show up for.",
        "A relaxed face makes my whole routine feel less tense.",
        "Who else has a favorite side for turns?",
        "Today I am working on the side I usually avoid.",
        "I like ending practice with a song and no planned steps.",
        "Any tips for remembering the second half of a chorus?",
        "I start from the middle sometimes so it gets equal practice.",
        "Hearing how everyone practices is giving me new ideas.",
        "That moment when the combination finally clicks is the best.",
        "New playlist, water bottle ready, let's find a groove."
    ]
}

private struct VoiceRoomNoteSheet: View {
    @Binding var text: String
    let save: (String) -> Void
    @Environment(\.dismiss) private var dismiss
    @FocusState private var focused: Bool
    private var trimmed: String { text.trimmingCharacters(in: .whitespacesAndNewlines) }
    private var valid: Bool { !trimmed.isEmpty && trimmed.count <= 200 && !trimmed.unicodeScalars.contains { $0.properties.isAlphabetic && !$0.isASCII } }
    var body: some View {
        NavigationStack {
            Form {
                Section("Your room note") {
                    TextField("Share a dance thought…", text: $text, axis: .vertical).lineLimit(3...6).focused($focused)
                    Text("\(text.count)/200 characters · English only").font(.caption).foregroundStyle(TetoStyle.muted)
                }
                Section {
                    Text("Private note · Cleared when you leave").font(.footnote)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .freshStudioPage().tetoNavigationTitle("Write a note").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("Add note") { save(trimmed); dismiss() }.disabled(!valid) }
            }
            .task { focused = true }
        }.presentationDetents([.medium, .large]).presentationDragIndicator(.visible)
    }
}

private struct VoiceRoomBackdrop: View {
    var body: some View {
        FreshStudioPageBackground()
    }
}

#Preview("Dance room") {
    NavigationStack { VoicePartyRoomView(room: DancePartyCatalog.rooms[0]) }.environmentObject(AppStore())
}
#Preview("Dance room / Large Type") {
    NavigationStack { VoicePartyRoomView(room: DancePartyCatalog.rooms[1]) }
        .environmentObject(AppStore()).environment(\.dynamicTypeSize, .accessibility1)
}
#Preview("Dance room / Empty") {
    NavigationStack { VoicePartyRoomView(room: PartyRoom(id: "empty-room", title: "Your dance circle", description: "", type: .voice, category: .freestyle)) }.environmentObject(AppStore())
}
