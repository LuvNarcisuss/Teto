import SwiftUI

enum PartyStyle {
    static let background = TetoStyle.background
    static let pageText = TetoStyle.ink
    static let teal = TetoStyle.emerald
    static let text = Color.white.opacity(0.95)
    static let surface = TetoStyle.soft
    static let outline = LinearGradient(colors: [TetoStyle.lime, TetoStyle.emerald], startPoint: .topLeading, endPoint: .bottomTrailing)
    static func categoryColor(_ category: PartyCategory) -> Color { TetoStyle.soft }
}

struct DiscoveryHeaderView: View {
    let filtered: Bool
    let tool: (PartyTool) -> Void
    let filter: () -> Void
    let search: () -> Void
    let create: () -> Void
    let refresh: () -> Void
    let all: () -> Void
    var body: some View {
        HStack(spacing: 0) {
            Menu {
                Button("All parties", action: all)
                Button("Create party", action: create)
                Button("Refresh", action: refresh)
                Button("Dance circle") { tool(.orbit) }
                Button("Filter parties", action: filter)
                Button("Dance mood") { tool(.mood) }
                Button("Conversation cards") { tool(.cards) }
            } label: {
                HStack(spacing: 8) {
                    Image("VoiceHeadphones").resizable().scaledToFit().frame(width: 48, height: 48).accessibilityHidden(true)
                    Text("Voice").font(TetoTypography.largeTitle).tracking(-1)
                }.frame(minHeight: 44, alignment: .leading)
            }.accessibilityLabel("Voice party options")
            Spacer(minLength: 8)
            if filtered { Circle().fill(TetoStyle.emerald).frame(width: 6, height: 6).accessibilityLabel("Filters active") }
            Button(action: search) {
                Image(systemName: "magnifyingglass").font(.system(size: 23, weight: .regular))
                    .frame(width: 44, height: 44)
            }.accessibilityLabel("Search parties")
        }.foregroundStyle(PartyStyle.pageText).buttonStyle(.plain)
    }
}

struct PartySectionHeaderView: View {
    let all: () -> Void
    var body: some View {
        HStack(spacing: 8) {
            Text("Find your dance circle").font(.subheadline).foregroundStyle(TetoStyle.muted)
            Spacer(minLength: 0)
            Button(action: all) {
                HStack(spacing: 4) {
                    Text("All parties").font(.caption.weight(.semibold))
                    Image(systemName: "chevron.right").font(.caption2.weight(.bold))
                }.frame(minHeight: 44)
            }.foregroundStyle(TetoStyle.emerald).accessibilityLabel("All parties")
        }.buttonStyle(.plain)
    }
}

struct GameCategoryStrip: View {
    @Binding var selected: PartyCategory?
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                categoryButton("All", category: nil)
                ForEach(PartyCategory.allCases) { category in categoryButton(category.title, category: category) }
            }.padding(.horizontal, 16)
        }
    }
    private func categoryButton(_ title: String, category: PartyCategory?) -> some View {
        Button { selected = category } label: {
            Text(title).font(.subheadline.weight(.medium)).fixedSize()
                .padding(.horizontal, 16).padding(.vertical, 10)
                .foregroundStyle(selected == category ? Color.white : TetoStyle.muted)
                .background(selected == category ? TetoStyle.emerald : TetoStyle.soft, in: Capsule())
                .frame(minHeight: 44)
        }.buttonStyle(.plain).accessibilityAddTraits(selected == category ? .isSelected : [])
    }
}

struct RoomTypeBadge: View {
    let type: PartyRoomType
    var tag: String?
    var body: some View {
        HStack(spacing: 5) {
            ZStack {
                Circle().fill(.black.opacity(0.85))
                if type == .voice {
                    HStack(alignment: .center, spacing: 2.5) {
                        ForEach([13.0, 10.0, 5.0], id: \.self) { height in
                            Capsule().fill(TetoStyle.lime).frame(width: 2.5, height: height)
                        }
                    }
                } else { Image(systemName: "video.fill").font(.system(size: 12)).foregroundStyle(TetoStyle.lime) }
            }.frame(width: 24, height: 24)
            if let label = tag ?? (type == .video ? "Video party" : nil) {
                Text(label).font(.caption2).lineLimit(1).padding(.trailing, 6)
            }
        }.background(tag != nil || type == .video ? Color.black.opacity(0.2) : .clear, in: Capsule())
            .accessibilityLabel(type.rawValue)
    }
}

struct PartyAvatarView: View {
    let asset: String?
    var size: CGFloat = 22
    var name: String? = nil
    var body: some View {
        Group {
            if let asset, let image = UIImage(named: FreshStudioPhotos.avatar(asset)) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                ZStack {
                    TetoStyle.emerald
                    if let name {
                        Text(String(name.prefix(3)).uppercased()).font(.system(size: size * 0.30, weight: .semibold)).foregroundStyle(.white)
                    } else { Image(systemName: "person.fill").font(.system(size: size * 0.55)).foregroundStyle(.white) }
                }
            }
        }.frame(width: size, height: size).clipShape(Circle())
            .overlay(Circle().strokeBorder(.white.opacity(0.55), lineWidth: 0.7)).accessibilityHidden(true)
    }
}

struct OverlappingAvatarGroup: View {
    let people: [PartyParticipant]
    let maximum: Int
    var body: some View {
        HStack(spacing: -6) {
            ForEach(Array(people.prefix(maximum))) { person in PartyAvatarView(asset: person.asset, name: person.name) }
        }.fixedSize()
    }
}
struct PopularityLabel: View {
    let popularity: PartyPopularity
    var body: some View {
        Label(popularity.label, systemImage: "flame.fill").font(.system(size: 12)).fixedSize()
            .accessibilityLabel("Popularity \(popularity.label)")
    }
}
struct PartyRoomCard: View {
    let room: PartyRoom
    @ScaledMetric(relativeTo: .body) private var height: CGFloat = 190

    var body: some View {
        content
            .padding(12)
            .frame(maxWidth: .infinity, minHeight: height, alignment: .bottomLeading)
            .foregroundStyle(Color.white)
            .background { PartyRoomCardBackground(room: room) }
            .clipShape(RoundedRectangle(cornerRadius: 16))
            .overlay { border }
            .shadow(color: TetoStyle.ink.opacity(0.06), radius: 8, y: 4)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel(accessibilitySummary)
            .accessibilityHint("Opens party details")
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(room.title)
                .font(TetoTypography.headline)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
                .frame(maxWidth: .infinity, alignment: .leading)
            adaptiveFooter
        }
    }

    private var adaptiveFooter: some View {
        ViewThatFits(in: .horizontal) {
            footer(4)
            footer(3)
            footer(2)
            footer(0)
        }
    }

    private var border: some View {
        RoundedRectangle(cornerRadius: 16)
            .strokeBorder(borderColor, lineWidth: borderWidth)
    }

    private var borderColor: Color {
        Color.white.opacity(0.18)
    }

    private var borderWidth: CGFloat { 0.5 }

    private var accessibilitySummary: String {
        var description = "\(room.title), \(room.type.rawValue), \(room.category.title)"
        if let count = room.onlineCount {
            description += ", \(count) members"
        }
        return description
    }

    private func footer(_ count: Int) -> some View {
        HStack(spacing: 6) {
            if count > 0 { OverlappingAvatarGroup(people: room.participants, maximum: count) }
            if let count = room.onlineCount {
                Label("\(count)", systemImage: "person.2.fill").font(.system(size: 12)).fixedSize()
                    .accessibilityLabel("\(count) members")
            }
            if room.participants.isEmpty && room.popularity == nil {
                Text("Your party").font(.caption).foregroundStyle(Color.white.opacity(0.8))
            }
        }.frame(minHeight: 22).fixedSize(horizontal: true, vertical: false)
    }
}

private struct PartyRoomCardBackground: View {
    let room: PartyRoom

    var body: some View {
        GeometryReader { bounds in
            artwork
                .frame(width: bounds.size.width, height: bounds.size.height)
                .clipped()
                .overlay { shading }
        }
    }

    @ViewBuilder
    private var artwork: some View {
        if room.draftID != nil {
            Rectangle().fill(TetoStyle.emerald.gradient)
        } else {
            Image(FreshStudioPhotos.cover(for: room)).resizable().scaledToFill()
        }
    }

    private var shading: LinearGradient {
        LinearGradient(
            colors: [Color.black.opacity(0.1), Color.clear, TetoStyle.night.opacity(0.9)],
            startPoint: .top,
            endPoint: .bottom
        )
    }
}

struct PartyRoomGrid: View {
    let rooms: [PartyRoom]
    let open: (PartyRoom) -> Void
    @Environment(\.dynamicTypeSize) private var typeSize
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 12, alignment: .top), count: typeSize.isAccessibilitySize ? 1 : 2)
    }
    var body: some View {
        LazyVGrid(columns: columns, alignment: .center, spacing: 12) {
            ForEach(rooms) { room in
                Button { open(room) } label: { PartyRoomCard(room: room) }.buttonStyle(.plain)
            }
        }
    }
}

struct FloatingPartyActions: View {
    let loading: Bool
    let refresh: () -> Void
    let create: () -> Void
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        VStack(spacing: 16) {
            Button(action: refresh) {
                Group {
                    if loading && !reduceMotion { ProgressView().tint(.black) }
                    else { Image(systemName: loading ? "hourglass" : "arrow.clockwise").font(.system(size: 25, weight: .medium)) }
                }.frame(width: 48, height: 48).background(.white, in: Circle()).foregroundStyle(.black.opacity(0.75))
                    .overlay(Circle().strokeBorder(.black.opacity(0.12), lineWidth: 0.8))
                    .shadow(color: .black.opacity(0.08), radius: 5, y: 2)
            }.disabled(loading).accessibilityLabel(loading ? "Refreshing parties" : "Refresh parties")
            Button(action: create) {
                Text("Create\nparty").font(.system(size: 11, weight: .semibold)).multilineTextAlignment(.center)
                    .foregroundStyle(.white).frame(width: 52, height: 52).background(TetoStyle.accentGradient, in: Circle())
            }.accessibilityLabel("Create a party")
        }.buttonStyle(.plain)
    }
}
