import SwiftUI

struct SignInView: View {
    let onContinue: () -> Void
    let onBack: () -> Void
    @EnvironmentObject private var store: AppStore
    @State private var agreed = false
    @State private var showingConsent = false
    @State private var agreementDocument: AgreementDocument?
    @State private var saving = false
    @State private var error: String?

    var body: some View {
        GeometryReader { bounds in
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    HStack {
                        Button(action: onBack) {
                            Image(systemName: "chevron.left").font(.title3.weight(.semibold))
                                .frame(width: 44, height: 44).background(.black.opacity(0.22), in: Circle())
                        }.accessibilityLabel("Back to welcome").disabled(saving)
                        Spacer()
                        TetoBrandLockup(compact: true)
                    }
                    Spacer(minLength: 100)
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Your dance\nstarts here.").font(TetoTypography.largeTitle).tracking(-1)
                        Text("Keep the moves you love.").font(.title3).foregroundStyle(.white.opacity(0.9))
                    }
                    VStack(alignment: .leading, spacing: 12) {
                        Button(saving ? "Opening Teto…" : "One-tap sign in") { requestSignIn() }
                            .buttonStyle(PrimaryButtonStyle()).disabled(saving)
                        HStack(alignment: .top, spacing: 4) {
                            Button { agreed.toggle(); error = nil } label: {
                                Image(systemName: agreed ? "checkmark.square.fill" : "square")
                                    .font(.title2).frame(width: 44, height: 44).contentShape(Rectangle())
                                    .foregroundStyle(agreed ? TetoStyle.lime : .white)
                            }
                            .accessibilityLabel("Agree to the Terms of Service and Privacy Policy")
                            .accessibilityValue(agreed ? "Checked" : "Not checked")
                            .accessibilityHint("Required to continue")
                            .disabled(saving)
                            VStack(alignment: .leading, spacing: 0) {
                                Text("I have read and agree to the").font(.subheadline).foregroundStyle(.white.opacity(0.9))
                                AgreementLink(document: .terms) { agreementDocument = $0 }
                                    .font(.subheadline.weight(.semibold))
                                Text("and").font(.subheadline).foregroundStyle(.white.opacity(0.9))
                                AgreementLink(document: .privacy) { agreementDocument = $0 }
                                    .font(.subheadline.weight(.semibold))
                            }.padding(.top, 10)
                        }
                        if let error {
                            Label(error, systemImage: "exclamationmark.circle")
                                .font(.footnote).padding(12).frame(maxWidth: .infinity, alignment: .leading)
                                .background(.black.opacity(0.65), in: RoundedRectangle(cornerRadius: 14))
                                .accessibilityLabel("Error: \(error)")
                        }
                    }
                }
                .frame(maxWidth: 480, minHeight: max(0, bounds.size.height - 48), alignment: .leading)
                .padding(24).frame(maxWidth: .infinity)
            }
        }
        .foregroundStyle(.white).buttonStyle(.plain)
        .background { FreshStudioEntryBackground().ignoresSafeArea() }
        .preferredColorScheme(.dark)
        .sheet(item: $agreementDocument) { UserAgreementView(document: $0) }
        .alert("Agree to continue", isPresented: $showingConsent) {
            Button("Cancel", role: .cancel) {}
            Button("Agree and sign in") {
                agreed = true
                signIn()
            }
        } message: {
            Text("Please agree to the Terms of Service and Privacy Policy to sign in to Teto. You can read both documents using the links on this page.")
        }
    }

    private func requestSignIn() {
        guard !saving else { return }
        error = nil
        if agreed { signIn() }
        else { showingConsent = true }
    }

    private func signIn() {
        guard agreed, !saving else { return }
        guard TetoUserAgreement.version != "unavailable" else {
            error = "The agreement files are unavailable. Please reinstall the app and try again."
            return
        }
        saving = true
        error = nil
        Task { @MainActor in
            let accepted = await store.acceptUserAgreement()
            saving = false
            if accepted { onContinue() }
            else { error = store.lastSaveError ?? "Your agreement could not be saved. Please try again." }
        }
    }
}
