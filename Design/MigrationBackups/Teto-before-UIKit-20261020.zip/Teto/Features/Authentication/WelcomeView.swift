import SwiftUI

struct WelcomeView: View {
    let onContinue: () -> Void
    var body: some View {
        GeometryReader { bounds in
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    TetoBrandLockup()
                    Spacer(minLength: 70)
                    VStack(alignment: .leading, spacing: 16) {
                        Text("Move with\nyour people.")
                            .font(TetoTypography.hero).tracking(-1.5)
                            .fixedSize(horizontal: false, vertical: true)
                        Text("Dance. Support. Belong.").font(.title3).foregroundStyle(.white.opacity(0.9))
                    }
                    Spacer(minLength: 20)
                    Button(action: onContinue) {
                        HStack(spacing: 10) { Text("Get started"); Image(systemName: "arrow.right").accessibilityHidden(true) }
                    }.buttonStyle(PrimaryButtonStyle())
                    Text("Find your rhythm. Make it yours.").font(.footnote).foregroundStyle(.white.opacity(0.8))
                        .frame(maxWidth: .infinity).multilineTextAlignment(.center)
                    Spacer(minLength: 24)
                }
                .frame(maxWidth: 480, minHeight: max(0, bounds.size.height - 48), alignment: .leading)
                .padding(24).frame(maxWidth: .infinity)
            }
        }
        .foregroundStyle(.white)
        .background { FreshStudioEntryBackground().ignoresSafeArea() }
        .preferredColorScheme(.dark)
    }
}
