import SwiftUI
import WebKit

/// A real local-file link, handled in-app so bundled HTML remains available offline.
struct AgreementLink: View {
    let document: AgreementDocument
    let open: (AgreementDocument) -> Void
    var body: some View {
        Group {
            if let url = document.fileURL {
                Link(document.title, destination: url)
                    .environment(\.openURL, OpenURLAction { _ in
                        open(document)
                        return .handled
                    })
            } else {
                Button(document.title) { open(document) }
            }
        }
        .underline().frame(minHeight: 44, alignment: .leading)
        .accessibilityHint("Opens the document")
    }
}

struct UserAgreementView: View {
    var document: AgreementDocument = .terms
    @Environment(\.dismiss) private var dismiss
    @State private var loading = true
    @State private var failed = false
    @State private var attempt = UUID()

    var body: some View {
        NavigationStack {
            Group {
                if let url = document.fileURL {
                    ZStack {
                        LocalAgreementWebView(url: url, loading: $loading, failed: $failed)
                            .id(attempt)
                        if loading { ProgressView("Loading document…") }
                        if failed {
                            ContentUnavailableView {
                                Label("Unable to open document", systemImage: "doc.text")
                            } description: {
                                Text("Please try opening this document again.")
                            } actions: {
                                Button("Try again") { failed = false; loading = true; attempt = UUID() }
                            }.background(TetoStyle.chromeGradient)
                        }
                    }
                } else {
                    ContentUnavailableView("Document unavailable", systemImage: "doc.text",
                        description: Text("This document could not be found in the app."))
                }
            }
            .tetoNavigationTitle(document.title).navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .background(TetoStyle.chromeGradient)
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}

private struct LocalAgreementWebView: UIViewRepresentable {
    let url: URL
    @Binding var loading: Bool
    @Binding var failed: Bool

    func makeCoordinator() -> Coordinator { Coordinator(self) }
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        configuration.websiteDataStore = .nonPersistent()
        configuration.defaultWebpagePreferences.allowsContentJavaScript = false
        let view = WKWebView(frame: .zero, configuration: configuration)
        view.navigationDelegate = context.coordinator
        view.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        return view
    }
    func updateUIView(_ view: WKWebView, context: Context) { context.coordinator.parent = self }
    static func dismantleUIView(_ view: WKWebView, coordinator: Coordinator) {
        view.navigationDelegate = nil
        view.stopLoading()
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        var parent: LocalAgreementWebView
        init(_ parent: LocalAgreementWebView) { self.parent = parent }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.loading = false
            parent.failed = false
        }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { fail(error) }
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) { fail(error) }
        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            parent.loading = false
            parent.failed = true
        }
        private func fail(_ error: Error) {
            guard (error as NSError).code != NSURLErrorCancelled else { return }
            parent.loading = false
            parent.failed = true
        }
        func webView(_ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
                     decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let target = action.request.url else { decisionHandler(.cancel); return }
            let directory = parent.url.deletingLastPathComponent().standardizedFileURL
            if target.isFileURL, target.deletingLastPathComponent().standardizedFileURL == directory {
                decisionHandler(.allow)
            } else {
                decisionHandler(.cancel)
                if action.navigationType == .linkActivated,
                   ["https", "http", "mailto"].contains(target.scheme?.lowercased() ?? "") {
                    UIApplication.shared.open(target)
                }
            }
        }
    }
}
