import SwiftUI

struct CreatorProfileView: View {
    let creator: CreatorProfile
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.dynamicTypeSize) private var typeSize
    @State private var messaging = false
    @State private var playingVideo: LocalVideo?
    private var blocked: Bool { store.isCreatorBlocked(creator.id) }
    private var following: Bool { store.isFollowingCreator(creator.id) }
    private var creatorStatistics: CreatorStatistics { store.statistics(for: creator) }
    private var name: String { creator.isLocalOwner ? store.library.profile.displayName : creator.name }
    private var biography: String { creator.isLocalOwner ? store.library.profile.biography : creator.biography }
    private var works: [LocalVideo] { blocked ? [] : store.creatorWorks(for: creator.id) }
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 2), count: typeSize.isAccessibilitySize ? 2 : 3)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                hero
                VStack(alignment: .leading, spacing: 22) {
                    statistics
                    VStack(alignment: .leading, spacing: 12) {
                        Text(biography.isEmpty ? "Every step tells a story." : biography)
                            .font(.body).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                        Text("IP: \(creator.ipRegion ?? "Unavailable")")
                            .font(.caption).foregroundStyle(TetoStyle.muted)
                            .padding(.horizontal, 9).padding(.vertical, 6)
                            .background(Color.black.opacity(0.04), in: RoundedRectangle(cornerRadius: 5))
                    }.padding(.horizontal, 16)
                    actions.padding(.horizontal, 16)
                    HStack(spacing: 8) {
                        Text("Videos").font(TetoTypography.headline)
                        Text("\(works.count)").font(TetoTypography.headline).monospacedDigit()
                        Spacer()
                        Image(systemName: "square.grid.3x3").foregroundStyle(TetoStyle.muted)
                    }.padding(.horizontal, 16).padding(.top, 6)
                    LazyVGrid(columns: columns, spacing: 2) {
                        ForEach(works) { video in
                            Button { playingVideo = video } label: {
                                workTile(video)
                            }.buttonStyle(.plain).accessibilityLabel("Play \(video.title), \(video.durationLabel)")
                        }
                    }
                    if works.isEmpty {
                        ContentUnavailableView("No videos yet", systemImage: "video",
                                               description: Text("Dance videos will appear here."))
                    }
                    if let sourceURL = creator.sourceURL {
                        Link("Film credits · Pexels", destination: sourceURL)
                            .font(.footnote).frame(minHeight: 44).padding(.horizontal, 16)
                    }
                }
                .padding(.top, 22).padding(.bottom, 24)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(.white.opacity(0.88), in: UnevenRoundedRectangle(topLeadingRadius: 24, topTrailingRadius: 24))
            }
        }
        .background { FreshStudioPageBackground().ignoresSafeArea() }
        .foregroundStyle(TetoStyle.ink)
        .safeAreaInset(edge: .top, spacing: 0) {
            HStack {
                Button { dismiss() } label: {
                    Image(systemName: "chevron.left").font(.system(size: 21, weight: .semibold))
                        .frame(width: 44, height: 44).background(.white, in: Circle())
                }.accessibilityLabel("Back to video")
                Spacer()
                Text("Creator").font(.subheadline.weight(.medium))
                Spacer()
                Color.clear.frame(width: 44, height: 44).accessibilityHidden(true)
            }.buttonStyle(.plain).foregroundStyle(TetoStyle.ink).padding(.horizontal, 12).padding(.vertical, 4)
                .background(TetoStyle.chromeGradient.ignoresSafeArea(edges: .top))
        }
        .toolbar(.hidden, for: .navigationBar, .tabBar)
        .preferredColorScheme(.light).tint(TetoStyle.emerald)
        .fullScreenCover(isPresented: $messaging) { CreatorConversationView(creator: creator) }
        .fullScreenCover(item: $playingVideo) { video in
            ShortsFeedView(isTabActive: true, isSearching: .constant(false),
                           collectionVideoIDs: [video.id], onClose: { playingVideo = nil },
                           closeLabel: "Back to creator", allowsCreatorNavigation: false)
                .preferredColorScheme(.dark)
        }
    }

    private var hero: some View {
        VStack(spacing: 16) {
            Group {
                if let coverURL = creator.coverURL, creator.avatarAsset == nil, !creator.isLocalOwner {
                    LocalVideoCover(url: coverURL)
                } else { LiveAvatar(asset: creator.avatarAsset, symbol: creator.avatarSymbol, size: 92) }
            }.frame(width: 92, height: 92).clipShape(Circle())
                .padding(4).background(.white, in: Circle())
                .overlay(Circle().strokeBorder(TetoStyle.lime, lineWidth: 2)).accessibilityHidden(true)
            Text(name).font(TetoTypography.section)
                .multilineTextAlignment(.center).fixedSize(horizontal: false, vertical: true)
            Label("Dance creator", systemImage: "figure.dance").font(.subheadline).foregroundStyle(TetoStyle.muted)
        }.foregroundStyle(TetoStyle.ink).frame(maxWidth: .infinity).padding(28)
            .background { FreshStudioBackdrop() }
    }

    private var statistics: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), alignment: .leading),
                                  count: typeSize.isAccessibilitySize ? 2 : 4), alignment: .leading, spacing: 16) {
            metric(creatorStatistics.likes, title: "Likes")
            metric(creatorStatistics.saves, title: "Saves")
            metric(creatorStatistics.following, title: "Following")
            metric(creatorStatistics.followers, title: "Followers")
        }.padding(.horizontal, 16)
    }

    private func metric(_ count: Int, title: String) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(count.formatted(.number.notation(.compactName).locale(Locale(identifier: "en_US"))))
                .font(TetoTypography.section).monospacedDigit()
            Text(title).font(.subheadline).foregroundStyle(TetoStyle.muted)
        }.frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("\(title): \(count)")
    }

    private var actions: some View {
        HStack(spacing: 10) {
            Button { Task { await store.toggleCreatorFollow(creator.id) } } label: {
                Label(blocked ? "Blocked" : (following ? "Following" : "Follow"), systemImage: following ? "checkmark" : "plus")
                    .font(.headline).frame(maxWidth: .infinity, minHeight: 48)
                    .foregroundStyle(following ? TetoStyle.ink : .white)
                    .background(following ? TetoStyle.soft : TetoStyle.emerald, in: Capsule())
            }.disabled(store.isBusy || blocked).accessibilityHint("Saved")
            Button { messaging = true } label: {
                Image(systemName: "paperplane.fill").font(.title3).frame(width: 56, height: 48)
                    .background(TetoStyle.soft, in: Capsule())
            }.accessibilityLabel("Message \(name)").disabled(blocked)
        }.buttonStyle(.plain)
    }

    private func workTile(_ video: LocalVideo) -> some View {
        Color.clear.aspectRatio(0.72, contentMode: .fit)
            .overlay { LocalVideoCover(url: store.coverURL(video)) }
            .overlay(alignment: .bottom) {
                VStack(alignment: .leading, spacing: 6) {
                    Text(video.title).font(.caption.weight(.semibold)).lineLimit(2)
                    Label(video.durationLabel, systemImage: "play.fill").font(.caption2)
                }.foregroundStyle(.white).frame(maxWidth: .infinity, alignment: .leading).padding(8)
                    .background(LinearGradient(colors: [.clear, .black.opacity(0.75)], startPoint: .top, endPoint: .bottom))
            }.clipShape(RoundedRectangle(cornerRadius: 10)).contentShape(Rectangle())
    }
}

struct CreatorConversationView: View {
    let creator: CreatorProfile
    var backLabel = "Back to creator"
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    private var conversation: DanceConversation {
        DanceConversation(id: "creator-chat:\(creator.id)", name: creator.name, avatars: [], kind: .person,
                          time: "", initialUnread: 0, initiallyPinned: false, story: nil, messages: [], creator: creator)
    }
    var body: some View {
        NavigationStack {
            ChatConversationView(conversation: conversation)
                .toolbar {
                    ToolbarItem(placement: .topBarLeading) {
                        Button { dismiss() } label: {
                            Image(systemName: "chevron.left").frame(width: 44, height: 44)
                        }.accessibilityLabel(backLabel).disabled(store.isBusy)
                    }
                }
        }
        .interactiveDismissDisabled(store.isBusy)
    }
}

#Preview("Creator profile") {
    let video = DanceVideoCatalog.entries[0].localVideo
    CreatorProfileView(creator: .from(video: video, profile: LocalProfile(), coverURL: video.bundledClip!.resourceURL(fileExtension: "jpg")))
        .environmentObject(AppStore())
}
