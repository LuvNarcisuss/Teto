import SwiftUI

enum ChatStyle {
    static let ink = TetoStyle.ink
    static let secondary = TetoStyle.muted
    static let badge = TetoStyle.emerald
    static let teal = TetoStyle.emerald
}

struct ChatAvatar: View {
    let conversation: DanceConversation
    var size: CGFloat = 56
    var body: some View {
        Group {
            if let creator = conversation.creator {
                if let url = creator.coverURL, creator.avatarAsset == nil, !creator.isLocalOwner {
                    LocalVideoCover(url: url)
                } else { LiveAvatar(asset: creator.avatarAsset, symbol: creator.avatarSymbol, size: size) }
            } else if conversation.kind == .activity {
                ZStack {
                    TetoStyle.lime.opacity(0.4)
                    Image("ChatSpark").resizable().scaledToFit().padding(4)
                }
            } else if conversation.kind == .group {
                VStack(spacing: 1) {
                    HStack(spacing: 1) { portrait(0); portrait(1) }
                    HStack(spacing: 1) { portrait(2); portrait(3) }
                }
            } else { portrait(0) }
        }.frame(width: size, height: size).clipShape(Circle()).accessibilityHidden(true)
    }
    private func portrait(_ index: Int) -> some View {
        Group {
            if conversation.avatars.indices.contains(index), let image = UIImage(named: FreshStudioPhotos.avatar(conversation.avatars[index])) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                ZStack { TetoStyle.soft; Image(systemName: "person.fill").foregroundStyle(ChatStyle.teal) }
            }
        }
        .frame(width: conversation.kind == .group ? (size - 1) / 2 : size,
               height: conversation.kind == .group ? (size - 1) / 2 : size).clipped()
    }
}

struct ChatStoriesView: View {
    let people: [DanceConversation]
    let post: () -> Void
    let open: (DanceConversation) -> Void
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(alignment: .top, spacing: 12) {
                Button(action: post) {
                    VStack(alignment: .leading, spacing: 8) {
                        ZStack(alignment: .bottomTrailing) {
                            RoundedRectangle(cornerRadius: 20).fill(TetoStyle.lime.opacity(0.5))
                            Image("DanceSneakers").resizable().scaledToFit().padding(10)
                            Image(systemName: "plus").font(.system(size: 13, weight: .bold))
                                .foregroundStyle(.white).frame(width: 28, height: 28)
                                .background(TetoStyle.emerald, in: Circle()).padding(8)
                        }.frame(width: 132, height: 108)
                        Text("Your day, your moves").font(.caption.weight(.medium)).lineLimit(2)
                    }.frame(width: 132, alignment: .leading)
                }.accessibilityLabel("Add a dance to your day")
                ForEach(people) { person in
                    Button { open(person) } label: {
                        VStack(alignment: .leading, spacing: 8) {
                            Image(FreshStudioPhotos.story(for: person.id)).resizable().scaledToFill()
                                .frame(width: 132, height: 108).clipped()
                                .clipShape(RoundedRectangle(cornerRadius: 20))
                                .overlay(alignment: .bottomLeading) {
                                    ChatAvatar(conversation: person, size: 28)
                                        .overlay(Circle().strokeBorder(.white, lineWidth: 2)).padding(8)
                                }
                            Text(person.name.split(separator: " ").first.map(String.init) ?? person.name)
                                .font(.caption.weight(.medium)).lineLimit(1)
                        }.frame(width: 132, alignment: .leading)
                    }.accessibilityLabel("View \(person.name)'s dance note")
                }
            }.foregroundStyle(ChatStyle.ink).buttonStyle(.plain)
                .padding(.horizontal, 16).padding(.top, 10).padding(.bottom, 16)
        }
    }
}

struct ChatConversationRow: View {
    let conversation: DanceConversation
    let unread: Int
    let pinned: Bool
    let draft: String?
    @Environment(\.dynamicTypeSize) private var typeSize
    private var summary: String { draft.flatMap { $0.isEmpty ? nil : "Draft: \($0)" } ?? conversation.summary }
    var body: some View {
        HStack(spacing: 13) {
            ChatAvatar(conversation: conversation)
            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .firstTextBaseline, spacing: 8) {
                    Text(conversation.name).font(.system(.body, weight: .semibold)).foregroundStyle(ChatStyle.ink)
                        .lineLimit(typeSize.isAccessibilitySize ? 2 : 1)
                    if pinned { Image(systemName: "pin.fill").font(.caption2).foregroundStyle(ChatStyle.secondary).accessibilityHidden(true) }
                    Spacer(minLength: 0)
                    Text(conversation.time).font(.caption).foregroundStyle(ChatStyle.secondary).fixedSize()
                }
                HStack(spacing: 6) {
                    Text(summary).font(.subheadline).foregroundStyle(draft?.isEmpty == false ? TetoStyle.emerald : ChatStyle.secondary)
                        .lineLimit(typeSize.isAccessibilitySize ? 2 : 1).frame(maxWidth: .infinity, alignment: .leading)
                    if unread > 0 {
                        Text(unread > 99 ? "99+" : "\(unread)").font(.system(size: 12, weight: .semibold)).foregroundStyle(.white)
                            .padding(.horizontal, 5).frame(minWidth: 19, minHeight: 19).background(ChatStyle.badge, in: Capsule())
                    }
                }
            }
        }.padding(.horizontal, 16).padding(.vertical, 13)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.48))
            .overlay(alignment: .bottom) { Rectangle().fill(TetoStyle.line.opacity(0.35)).frame(height: 0.5).padding(.leading, 83) }
            .contentShape(Rectangle())
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("\(conversation.name)\(pinned ? ", pinned" : ""), \(summary), \(conversation.time)\(unread > 0 ? ", \(unread) unread messages" : "")")
    }
}
