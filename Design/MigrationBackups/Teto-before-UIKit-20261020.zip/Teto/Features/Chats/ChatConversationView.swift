import SwiftUI

struct ChatConversationView: View {
    let conversation: DanceConversation
    @EnvironmentObject private var store: AppStore
    @State private var draft = ""
    @State private var loaded = false
    @State private var failure: String?
    @State private var callKind: ChatCallKind?
    @FocusState private var composing: Bool
    private var messages: [ChatMessage] { store.messages(for: conversation) }
    private var allowed: Bool { store.canSendChatMessage(conversation) }
    private var blocked: Bool { conversation.creator.map { store.isCreatorBlocked($0.id) } ?? false }
    private var valid: Bool { !draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && draft.count <= 2_000 }

    var body: some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 18) {
                    if conversation.kind == .person { relationshipCard }
                    ForEach(messages) { message in
                        ChatMessageBubble(message: message, conversation: conversation).id(message.id)
                    }
                    Color.clear.frame(height: 1).id("message-bottom")
                }.padding(16)
            }
            .defaultScrollAnchor(.bottom)
            .scrollDismissesKeyboard(.interactively)
            .onChange(of: messages.count) { _, _ in proxy.scrollTo("message-bottom", anchor: .bottom) }
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            if conversation.kind != .activity { composer }
        }
        .freshStudioPage()
        .tetoNavigationTitle(conversation.name).navigationBarTitleDisplayMode(.inline)
        .toolbar(.visible, for: .navigationBar)
        .toolbar(.hidden, for: .tabBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                if conversation.kind != .activity {
                    ChatCallButtons { kind in composing = false; callKind = kind }
                        .disabled(conversation.creator.map { store.isCreatorBlocked($0.id) } ?? false)
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button { Task { await store.toggleChatPin(conversation) } } label: {
                    Image(systemName: store.isChatPinned(conversation) ? "pin.fill" : "pin")
                        .frame(width: 44, height: 44)
                }.accessibilityLabel(store.isChatPinned(conversation) ? "Unpin chat" : "Pin chat")
            }
            ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { composing = false } }
        }
        .task(id: conversation.id) {
            guard !loaded else { return }
            draft = store.chatDraft(for: conversation) ?? ""
            if let creator = conversation.creator {
                if !(await store.openCreatorConversation(creator)) {
                    failure = store.lastSaveError ?? "Unable to open this conversation."
                }
            }
            await store.markChatRead(conversation.id)
            loaded = true
        }
        .fullScreenCover(item: $callKind) { kind in ChatCallView(kind: kind, conversation: conversation) }
        .onChange(of: draft) { _, _ in failure = nil }
        .onDisappear {
            composing = false
            guard loaded, draft != (store.chatDraft(for: conversation) ?? "") else { return }
            let value = draft
            Task {
                if let creator = conversation.creator { _ = await store.saveCreatorMessageDraft(value, creator: creator) }
                else { _ = await store.saveChatDraft(value, conversationID: conversation.id) }
            }
        }
        .preferredColorScheme(.light).tint(TetoStyle.emerald)
    }

    private var relationshipCard: some View {
        HStack(spacing: 12) {
            Image("ChatSpark").resizable().scaledToFit().frame(width: 56, height: 56).accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 5) {
                Text(store.isMutualChat(conversation) ? "You're mutuals" : "Start with a hello")
                    .font(.subheadline.weight(.semibold))
                Text(store.isMutualChat(conversation) ? "Keep the conversation moving." : "One introduction. More messages when you follow each other.")
                    .font(.caption).foregroundStyle(TetoStyle.muted).fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
            if !store.followsChatPartner(conversation), conversation.creator?.isLocalOwner != true {
                Button(store.chatPartnerFollowsMe(conversation) ? "Follow back" : "Follow") {
                    Task { await store.toggleChatFollow(conversation) }
                }.font(.caption.weight(.semibold)).padding(.horizontal, 10).frame(minHeight: 44)
                    .foregroundStyle(.white).background(TetoStyle.emerald, in: Capsule()).disabled(store.isBusy || blocked)
            }
        }.padding(14).background(TetoStyle.lime.opacity(0.3), in: RoundedRectangle(cornerRadius: 22))
    }

    private var composer: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let failure { Text(failure).font(.caption).foregroundStyle(.red) }
            if !allowed {
                Label(blocked ? "Unblock this person to chat." : "Follow each other to continue chatting.", systemImage: "lock.fill")
                    .font(.caption).foregroundStyle(TetoStyle.muted)
            }
            HStack(alignment: .bottom, spacing: 10) {
                TextField("Write a message…", text: $draft, axis: .vertical)
                    .lineLimit(1...4).padding(12).background(TetoStyle.soft, in: RoundedRectangle(cornerRadius: 22))
                    .focused($composing).accessibilityLabel("Message").disabled(store.isBusy || blocked)
                Button {
                    Task {
                        if await store.sendChatMessage(draft, to: conversation) { draft = "" }
                        else { failure = store.lastSaveError ?? "Your message could not be saved. Try again." }
                    }
                } label: {
                    Image(systemName: "arrow.up").font(.system(size: 20, weight: .semibold))
                        .foregroundStyle(.white).frame(width: 44, height: 44)
                        .background(allowed && valid ? TetoStyle.emerald : TetoStyle.sage, in: Circle())
                }.accessibilityLabel("Send message").disabled(store.isBusy || !loaded || !valid || !allowed)
            }
            HStack {
                Spacer(minLength: 8)
                Text("\(draft.count)/2,000").monospacedDigit().foregroundStyle(draft.count > 2_000 ? Color.red : ChatStyle.secondary)
            }.font(.caption2).foregroundStyle(ChatStyle.secondary)
        }.padding(.horizontal, 16).padding(.top, 12).padding(.bottom, 8).background(TetoStyle.chromeGradient)
    }
}

private struct ChatMessageBubble: View {
    let message: ChatMessage
    let conversation: DanceConversation
    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            if message.isOwn { Spacer(minLength: 40) }
            else { ChatAvatar(conversation: conversation, size: 32) }
            VStack(alignment: message.isOwn ? .trailing : .leading, spacing: 5) {
                if !message.isOwn { Text(message.author).font(.caption.weight(.medium)).foregroundStyle(ChatStyle.secondary) }
                Text(message.text).font(.body).foregroundStyle(ChatStyle.ink).textSelection(.enabled)
                    .padding(.horizontal, 14).padding(.vertical, 11)
                    .background(message.isOwn ? TetoStyle.lime.opacity(0.65) : .white,
                                in: RoundedRectangle(cornerRadius: 18))
                Text(message.isPending == true ? "\(message.time) · Pending" : message.time).font(.caption2).foregroundStyle(ChatStyle.secondary)
            }
            if !message.isOwn { Spacer(minLength: 40) }
        }.accessibilityElement(children: .combine)
            .accessibilityLabel("\(message.author), \(message.text), \(message.time)")
    }
}

struct ChatContactsSheet: View {
    @EnvironmentObject private var store: AppStore
    let select: (DanceConversation) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var query = ""
    private var people: [DanceConversation] {
        store.chatConversations.filter { $0.kind != .activity && (query.isEmpty || $0.name.localizedCaseInsensitiveContains(query)) }
    }
    var body: some View {
        NavigationStack {
            List(people) { conversation in
                Button { select(conversation); dismiss() } label: {
                    HStack(spacing: 12) {
                        ChatAvatar(conversation: conversation, size: 44)
                        VStack(alignment: .leading, spacing: 5) {
                            Text(conversation.name).font(TetoTypography.headline).foregroundStyle(ChatStyle.ink)
                            Text(conversation.creator != nil ? "Dance creator" : (conversation.kind == .group ? "Dance group" : "Dance friend")).font(.subheadline).foregroundStyle(ChatStyle.secondary)
                        }
                    }.padding(.vertical, 4)
                }.buttonStyle(.plain)
            }
            .overlay { if people.isEmpty { ContentUnavailableView.search(text: query) } }
            .searchable(text: $query, prompt: "Find a dancer or group")
            .freshStudioPage()
            .tetoNavigationTitle("New chat").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}

struct ChatStorySheet: View {
    let conversation: DanceConversation
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    HStack(spacing: 12) {
                        ChatAvatar(conversation: conversation, size: 44)
                        Text(conversation.name).font(TetoTypography.headline)
                    }
                    Image(FreshStudioPhotos.story(for: conversation.id)).resizable().scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 24))
                    Text(conversation.story ?? "Every step is a new story.").font(.title3.weight(.medium))
                    Text("Photography · Pexels").font(.caption).foregroundStyle(TetoStyle.muted)
                }.padding(20)
            }
                .freshStudioPage()
            .tetoNavigationTitle("Dance notes").navigationBarTitleDisplayMode(.inline)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}

#Preview("Dance conversation") {
    NavigationStack { ChatConversationView(conversation: DanceChatCatalog.conversations[1]) }.environmentObject(AppStore())
}
