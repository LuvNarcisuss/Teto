import SwiftUI

struct MessageDraftEditor: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var text: String
    @State private var failure: String?
    @State private var confirmingDiscard = false
    @FocusState private var focused: Bool
    private let original: String

    init(text: String) {
        original = text
        _text = State(initialValue: text)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    ScreenHeading(title: "A thought for later", subtitle: "Just for you, for now.")
                    StatusPill(text: "DRAFT")
                    TextField("Write something you would like to say…", text: $text, axis: .vertical)
                        .lineLimit(8...18).focused($focused).padding(18)
                        .background(.white, in: RoundedRectangle(cornerRadius: 20))
                        .accessibilityLabel("Message draft")
                        .disabled(store.isBusy)
                    Text("\(text.count)/2,000 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                    FormError(message: failure)
                    ServiceNote(symbol: "paperplane", text: "A private draft for later.")
                    if !text.isEmpty {
                        Button("Clear text", role: .destructive) { text = "" }.disabled(store.isBusy)
                        Text("Save to clear this draft.")
                            .font(.caption).foregroundStyle(TetoStyle.muted)
                    }
                }.padding(20)
            }
            .freshStudioPage()
            .tetoNavigationTitle("Message draft").navigationBarTitleDisplayMode(.inline)
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if text != original { confirmingDiscard = true } else { dismiss() } }.disabled(store.isBusy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.isBusy ? "Saving…" : "Save") {
                        focused = false
                        Task {
                            if await store.saveMessageDraft(text) { dismiss() }
                            else { failure = store.lastSaveError ?? "Keep your draft within 2,000 characters." }
                        }
                    }.disabled(store.isBusy || text.count > 2_000)
                }
                ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { focused = false } }
            }
            .interactiveDismissDisabled(store.isBusy || text != original)
            .confirmationDialog("Discard unsaved changes?", isPresented: $confirmingDiscard, titleVisibility: .visible) {
                Button("Discard changes", role: .destructive) { dismiss() }
            }
        }
    }
}
