import SwiftUI

struct ChatsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var query = ""
    @State private var searching = false
    @FocusState private var searchFocused: Bool
    @Namespace private var searchTransition
    @State private var filter = ChatInboxFilter.all
    @State private var selected: DanceConversation?
    @State private var selectedCreator: CreatorProfile?
    @State private var sheet: ChatSheet?
    @State private var pendingConversation: DanceConversation?
    private var conversations: [DanceConversation] {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        let source = store.chatConversations
        return source.filter { conversation in
            guard term.isEmpty || "\(conversation.name) \(conversation.messages.map(\.text).joined(separator: " ")) \(store.chatDraft(for: conversation) ?? "")".localizedCaseInsensitiveContains(term) else { return false }
            switch filter {
            case .all: return true
            case .unread: return store.chatUnreadCount(conversation) > 0
            case .pinned: return store.isChatPinned(conversation)
            case .drafts: return store.chatDraft(for: conversation)?.isEmpty == false
            }
        }.sorted {
            if $0.id == $1.id { return false }
            if $0.kind == .activity { return true }
            if $1.kind == .activity { return false }
            let leftPinned = store.isChatPinned($0)
            let rightPinned = store.isChatPinned($1)
            if leftPinned != rightPinned { return leftPinned }
            let leftIndex = source.firstIndex(of: $0) ?? 0
            let rightIndex = source.firstIndex(of: $1) ?? 0
            return leftIndex < rightIndex
        }
    }

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                if filter == .all && !searching {
                    ChatStoriesView(people: DanceChatCatalog.people, post: { sheet = .post }, open: { sheet = .story($0) })
                }
                if filter != .all && !searching {
                    HStack {
                        Text(filter.rawValue).font(.subheadline.weight(.medium))
                        Spacer()
                        Button("Show all") { filter = .all }.frame(minHeight: 44)
                    }.padding(.horizontal, 16)
                }
                if conversations.isEmpty {
                    ContentUnavailableView("No chats found", systemImage: "bubble.left.and.bubble.right",
                                           description: Text("Try another name or change your inbox filter.")).padding(.top, 40)
                }
                ForEach(conversations) { conversation in
                    Button { open(conversation) } label: {
                        ChatConversationRow(conversation: conversation, unread: store.chatUnreadCount(conversation),
                            pinned: store.isChatPinned(conversation), draft: store.chatDraft(for: conversation))
                    }
                    .buttonStyle(.plain)
                    .contextMenu {
                        Button("Mark as read") { Task { await store.markChatRead(conversation.id) } }
                        Button(store.isChatPinned(conversation) ? "Unpin chat" : "Pin chat") { Task { await store.toggleChatPin(conversation) } }
                    }
                }
            }.padding(.bottom, 12)
        }
        .background { FreshStudioPageBackground().ignoresSafeArea() }.foregroundStyle(ChatStyle.ink)
        .safeAreaInset(edge: .top, spacing: 0) { inboxHeader }
        .scrollDismissesKeyboard(.interactively)
        .toolbar(.hidden, for: .navigationBar)
        .toolbarBackground(.automatic, for: .tabBar)
        .toolbarColorScheme(.light, for: .tabBar)
        .onDisappear { searchFocused = false }
        .navigationDestination(item: $selected) { ChatConversationView(conversation: $0) }
        .fullScreenCover(item: $selectedCreator) { creator in
            CreatorConversationView(creator: creator, backLabel: "Back to chats")
        }
        .sheet(item: $sheet, onDismiss: {
            if let conversation = pendingConversation { open(conversation); pendingConversation = nil }
        }) { value in
            switch value {
            case .notes: MessageDraftEditor(text: store.library.messageDraft)
            case .post: DancePostSheet()
            case .contacts:
                ChatContactsSheet { pendingConversation = $0 }
            case .story(let conversation): ChatStorySheet(conversation: conversation)
            }
        }
    }

    private func open(_ conversation: DanceConversation) {
        searchFocused = false
        if let creator = conversation.creator { selectedCreator = creator }
        else { selected = conversation }
    }

    private var inboxHeader: some View {
        HStack(spacing: 8) {
            if searching {
                HStack(spacing: 8) {
                    searchIcon
                    TextField("Search chats or messages", text: $query)
                        .font(.body).focused($searchFocused)
                        .textInputAutocapitalization(.never).autocorrectionDisabled()
                        .submitLabel(.search).onSubmit { searchFocused = false }
                        .accessibilityLabel("Search chats or messages")
                    if !query.isEmpty {
                        Button { query = "" } label: {
                            Image(systemName: "xmark.circle.fill").foregroundStyle(ChatStyle.secondary)
                                .frame(width: 44, height: 44)
                        }.accessibilityLabel("Clear search")
                    }
                }
                .padding(.leading, 12).padding(.trailing, query.isEmpty ? 12 : 0)
                .frame(minHeight: 44)
                .background(TetoStyle.soft, in: Capsule())
                Button("Cancel") { endSearch() }.frame(minHeight: 44)
                    .foregroundStyle(TetoStyle.emerald)
                    .fixedSize(horizontal: true, vertical: false)
            } else {
                HStack(spacing: 8) {
                    Image("ChatSpark").resizable().scaledToFit()
                        .frame(width: 48, height: 48).accessibilityHidden(true)
                    Text("Chats").font(TetoTypography.title).tracking(-0.8)
                        .accessibilityAddTraits(.isHeader)
                        .contextMenu {
                            Picker("Inbox", selection: $filter) { ForEach(ChatInboxFilter.allCases) { Text($0.rawValue).tag($0) } }
                            Button("Mark all as read") { Task { await store.markChatRead() } }
                            Button("My notes") { sheet = .notes }
                        }
                    Spacer(minLength: 0)
                    trailingTools
                }.frame(minHeight: 44)
            }
        }
        .buttonStyle(.plain).foregroundStyle(ChatStyle.ink)
        .padding(.horizontal, 16).padding(.vertical, 6).background(TetoStyle.chromeGradient)
        .task(id: searching) {
            guard searching else { return }
            await Task.yield()
            guard !Task.isCancelled else { return }
            searchFocused = true
        }
    }

    private var searchIcon: some View {
        Image(systemName: "magnifyingglass").font(.system(size: 24))
            .matchedGeometryEffect(id: "inboxSearch", in: searchTransition)
            .accessibilityHidden(true)
    }

    private func beginSearch() {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) { searching = true }
    }

    private func endSearch() {
        searchFocused = false
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) {
            query = ""
            searching = false
        }
    }

    private var leadingTools: some View {
        HStack(spacing: 2) {
            Menu {
                Picker("Inbox", selection: $filter) { ForEach(ChatInboxFilter.allCases) { Text($0.rawValue).tag($0) } }
                Button("Mark all as read") { Task { await store.markChatRead() } }
                Button("My notes") { sheet = .notes }
            } label: {
                Image(systemName: "line.3.horizontal.decrease").font(.system(size: 20, weight: .medium)).frame(width: 44, height: 44)
            }.accessibilityLabel("Inbox options")
        }.buttonStyle(.plain).foregroundStyle(ChatStyle.ink)
    }
    private var trailingTools: some View {
        HStack(spacing: 2) {
            Button(action: beginSearch) { searchIcon.frame(width: 44, height: 44).contentShape(Rectangle()) }
                .accessibilityLabel("Search chats")
            Button { sheet = .contacts } label: { Image(systemName: "plus.circle.fill").font(.system(size: 27)).foregroundStyle(TetoStyle.emerald).frame(width: 44, height: 44) }
                .accessibilityLabel("Open a conversation")
        }.buttonStyle(.plain).foregroundStyle(ChatStyle.ink)
    }
}

private enum ChatSheet: Identifiable {
    case notes, post, contacts, story(DanceConversation)
    var id: String {
        switch self { case .notes: return "notes"; case .post: return "post"; case .contacts: return "contacts"; case .story(let value): return "story-\(value.id)" }
    }
}

#Preview("Dance inbox") { NavigationStack { ChatsView() }.environmentObject(AppStore()) }
#Preview("Dance inbox / Large Type") {
    NavigationStack { ChatsView() }.environmentObject(AppStore()).environment(\.dynamicTypeSize, .accessibility1)
}
