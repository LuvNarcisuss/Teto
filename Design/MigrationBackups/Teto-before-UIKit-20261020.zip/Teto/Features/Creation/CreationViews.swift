import PhotosUI
import SwiftUI

struct LiveCreationView: View {
    var body: some View { CreationFormView(kind: .live) }
}

struct ShortVideoCreationView: View {
    var body: some View { CreationFormView(kind: .shortVideo) }
}

private struct CreationFormView: View {
    let kind: CreationKind
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    private enum Field: Hashable { case title, caption }
    @FocusState private var focused: Field?
    @State private var title = ""
    @State private var caption = ""
    @State private var category: PartyCategory = .freestyle
    @State private var video: PhotosPickerItem?
    @State private var cover: PhotosPickerItem?
    @State private var confirmsDance = false
    @State private var saving = false
    @State private var completed = false
    @State private var discard = false
    @State private var error: String?
    private var changed: Bool { !title.isEmpty || !caption.isEmpty || video != nil || cover != nil || confirmsDance }
    private var english: Bool { CreationValidation.isEnglish(title) && CreationValidation.isEnglish(caption) }
    private var valid: Bool {
        CreationValidation.valid(title: title, caption: caption) && confirmsDance && (kind == .live || video != nil)
    }

    var body: some View {
        NavigationStack {
            Group {
                if completed { completion }
                else { form }
            }
            .freshStudioPage()
            .tetoNavigationTitle(kind.title).navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("Done") { focused = nil }
                }
                ToolbarItem(placement: .cancellationAction) {
                    Button(completed ? "Done" : "Cancel") {
                        focused = nil
                        if !completed && changed { discard = true } else { dismiss() }
                    }.disabled(saving)
                }
            }
            .interactiveDismissDisabled(saving || (!completed && changed))
            .confirmationDialog("Discard this creation?", isPresented: $discard, titleVisibility: .visible) {
                Button("Discard", role: .destructive) { dismiss() }
            } message: { Text("Your selected media will stay in Photos.") }
        }.tint(TetoStyle.emerald).preferredColorScheme(.light)
    }

    private var form: some View {
        Form {
            introduction
            details
            media
            submissionActions
        }.disabled(saving || store.isBusy).scrollDismissesKeyboard(.interactively)
    }

    private var introduction: some View {
        Section {
            HStack(spacing: 14) {
                Image(kind == .live ? "TabLive" : "DanceSneakers")
                    .resizable().scaledToFit().frame(width: 60, height: 60).accessibilityHidden(true)
                VStack(alignment: .leading, spacing: 5) {
                    Text(kind == .live ? "Make room for your rhythm." : "Share your next move.")
                        .font(TetoTypography.subsection)
                    Text(kind == .live ? "Plan a dance session for your community." : "Choreography, practice or a little freestyle.")
                        .font(.subheadline).foregroundStyle(TetoStyle.muted)
                }
            }.padding(.vertical, 8)
        }
    }

    private var details: some View {
        Section(kind == .live ? "Session details" : "Video details") {
            TextField("Title", text: $title, axis: .vertical).lineLimit(1...3).focused($focused, equals: .title)
                .accessibilityLabel("Title")
            Text("\(title.count)/80").font(.caption).foregroundStyle(title.count > 80 ? .red : TetoStyle.muted)
            TextField(kind == .live ? "What will you be dancing?" : "Tell the story behind your dance", text: $caption, axis: .vertical)
                .lineLimit(3...6).focused($focused, equals: .caption).accessibilityLabel("Description")
            Text("\(caption.count)/500").font(.caption).foregroundStyle(caption.count > 500 ? .red : TetoStyle.muted)
            if !english { Text("Please use English for your title and description.").font(.caption).foregroundStyle(.red) }
            Picker("Dance style", selection: $category) {
                ForEach(PartyCategory.allCases) { value in Text(value.title).tag(value) }
            }
        }
    }

    private var media: some View {
        Section(kind == .live ? "Cover" : "Dance video") {
            if kind == .live {
                PhotosPicker(selection: $cover, matching: .images) {
                    Label(cover == nil ? "Choose a cover (optional)" : "Change cover", systemImage: "photo.badge.plus")
                        .frame(minHeight: 44)
                }
                if cover != nil {
                    Label("Cover selected", systemImage: "checkmark.circle").foregroundStyle(TetoStyle.emerald)
                    Button("Remove cover", role: .destructive) { cover = nil }
                }
            } else {
                PhotosPicker(selection: $video, matching: .videos) {
                    Label(video == nil ? "Choose a dance video" : "Change video", systemImage: "video.badge.plus")
                        .frame(minHeight: 44)
                }
                if video != nil { Label("Video selected", systemImage: "checkmark.circle").foregroundStyle(TetoStyle.emerald) }
                Text("Up to 3 minutes · Up to 250 MB").font(.caption).foregroundStyle(TetoStyle.muted)
            }
        }
    }

    private var submissionActions: some View {
        Section {
            Toggle("This is dance content I have permission to share.", isOn: $confirmsDance)
            Text("Your content stays private while awaiting review.").font(.footnote).foregroundStyle(TetoStyle.muted)
            if let error { Text(error).foregroundStyle(.red).accessibilityAddTraits(.isStaticText) }
            Button(action: submit) {
                HStack(spacing: 10) {
                    if saving { ProgressView().tint(.white) }
                    Text(saving ? "Preparing…" : "Submit for review")
                }.frame(maxWidth: .infinity)
            }.buttonStyle(PrimaryButtonStyle()).disabled(!valid || saving || store.isBusy)
        }
    }

    private var completion: some View {
        ScrollView {
            VStack(spacing: 20) {
                Image(systemName: "clock").font(.system(size: 46)).foregroundStyle(TetoStyle.emerald).accessibilityHidden(true)
                Text("Pending review").font(TetoTypography.title)
                Text("Waiting to submit. Your content is not public.")
                    .font(.body).foregroundStyle(TetoStyle.muted).multilineTextAlignment(.center)
                NavigationLink { PendingCreationsView() } label: {
                    Label("View pending works", systemImage: "square.stack")
                }.buttonStyle(PrimaryButtonStyle())
                Button("Done") { dismiss() }.frame(minHeight: 44)
            }.padding(24).padding(.top, 40).frame(maxWidth: .infinity)
        }
    }

    private func submit() {
        guard valid, !saving, !store.isBusy else { return }
        focused = nil; saving = true; error = nil
        Task { @MainActor in
            let id = await store.queueCreation(kind: kind, title: title, caption: caption,
                category: category, videoItem: video, coverItem: cover)
            saving = false
            if id != nil { completed = true; video = nil; cover = nil }
            else { error = store.lastSaveError ?? "Your content could not be saved. Try again." }
        }
    }
}

struct PendingCreationsView: View {
    @EnvironmentObject private var store: AppStore
    var body: some View {
        List {
            if store.pendingSubmissions.isEmpty {
                ContentUnavailableView("No pending works", systemImage: "checkmark.circle",
                    description: Text("Live sessions and short videos awaiting review will appear here."))
            }
            ForEach(store.pendingSubmissions) { submission in
                NavigationLink {
                    PendingCreationDetailView(submissionID: submission.id)
                } label: {
                    HStack(spacing: 12) {
                        SubmissionCoverView(submission: submission).frame(width: 68, height: 84)
                            .clipShape(RoundedRectangle(cornerRadius: 12))
                        VStack(alignment: .leading, spacing: 6) {
                            Text(submission.title).font(TetoTypography.headline).lineLimit(2)
                            Text(submission.kind.label + " · " + submission.category).font(.caption).foregroundStyle(TetoStyle.muted)
                            Label("Pending review", systemImage: "clock").font(.caption.weight(.semibold)).foregroundStyle(TetoStyle.emerald)
                        }.padding(.vertical, 8)
                    }
                }
            }
        }.freshStudioPage().tetoNavigationTitle("Pending review").navigationBarTitleDisplayMode(.inline)
    }
}

private struct SubmissionCoverView: View {
    let submission: CreationSubmission
    @EnvironmentObject private var store: AppStore
    var body: some View {
        Group {
            if let url = store.submissionCoverURL(submission) { LocalVideoCover(url: url) }
            else {
                ZStack {
                    TetoStyle.lime.opacity(0.45)
                    Image(systemName: submission.kind.symbol).font(.title).foregroundStyle(TetoStyle.emerald)
                }
            }
        }.accessibilityHidden(true)
    }
}

private struct PendingCreationDetailView: View {
    let submissionID: UUID
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var removing = false
    @State private var error: String?
    private var submission: CreationSubmission? { store.pendingSubmissions.first { $0.id == submissionID } }
    var body: some View {
        Form {
            if let submission {
                Section {
                    SubmissionCoverView(submission: submission).frame(height: 220)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    Text(submission.title).font(TetoTypography.section)
                    if !submission.caption.isEmpty { Text(submission.caption) }
                    LabeledContent("Type", value: submission.kind.label)
                    LabeledContent("Dance style", value: submission.category)
                }
                Section("Review status") {
                    Label("Pending review", systemImage: "clock").foregroundStyle(TetoStyle.emerald)
                    Text("Waiting to submit. Your content is not public.").font(.subheadline)
                    LabeledContent("Created", value: submission.createdAt.formatted(.dateTime.month().day().hour().minute().locale(Locale(identifier: "en_US"))))
                }
                Section {
                    Button("Remove submission", role: .destructive) { removing = true }.disabled(store.isBusy)
                    if let error { Text(error).foregroundStyle(.red) }
                }
            }
        }.freshStudioPage().tetoNavigationTitle("Your submission").navigationBarTitleDisplayMode(.inline)
            .confirmationDialog("Remove this submission?", isPresented: $removing, titleVisibility: .visible) {
                Button("Remove", role: .destructive) {
                    Task { @MainActor in
                        if await store.removeSubmission(submissionID) { dismiss() }
                        else { error = store.lastSaveError ?? "Unable to remove this submission. Try again." }
                    }
                }
            } message: { Text("Your original media in Photos will not be removed.") }
    }
}
