import SwiftUI

struct BottomActionBarView: View {
    @Binding var text: String
    let focus: FocusState<Bool>.Binding
    let sending: Bool
    let likePulse: Int
    let send: () -> Void
    let like: () -> Void
    let gift: () -> Void
    let share: () -> Void
    @Environment(\.dynamicTypeSize) private var typeSize
    var body: some View {
        Group {
            if focus.wrappedValue || typeSize.isAccessibilitySize {
                VStack(spacing: 6) {
                    HStack(spacing: 6) {
                        input
                        if focus.wrappedValue {
                            Button(action: send) { Text(sending ? "Adding…" : "Send").font(.subheadline.bold()).frame(minWidth: 44, minHeight: 44) }
                                .disabled(sending || text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                            Button { focus.wrappedValue = false } label: { Image(systemName: "keyboard.chevron.compact.down").frame(width: 44, height: 44) }
                                .accessibilityLabel("Dismiss keyboard")
                        }
                    }
                    if !focus.wrappedValue { HStack(spacing: 10) { Spacer(); actions } }
                }
            } else {
                HStack(spacing: 5) { input; actions }
            }
        }
        .foregroundStyle(.white).buttonStyle(.plain)
        .padding(.horizontal, 12).padding(.top, 8).padding(.bottom, 6)
    }
    private var input: some View {
        HStack(spacing: 0) {
            TextField("", text: $text, prompt: Text("Say something…").foregroundColor(.white.opacity(0.65)))
                .font(.body).focused(focus).submitLabel(.send).onSubmit(send)
                .accessibilityLabel("Comment")
                .padding(.leading, 12).frame(minHeight: 44)
                .onChange(of: text) { _, value in if value.count > 200 { text = String(value.prefix(200)) } }
            Button { text += "☺️"; focus.wrappedValue = true } label: {
                Image(systemName: "face.smiling").font(.system(size: 24)).foregroundStyle(.white.opacity(0.8)).frame(width: 44, height: 44)
            }.accessibilityLabel("Add a smile")
        }.background(LiveRoomStyle.panel, in: Capsule()).frame(maxWidth: .infinity)
    }
    private var actions: some View {
        Group {
            action(.heart, label: "Like", action: like)
            action(.gift, label: "Gifts", action: gift)
            action(.share, label: "Share", action: share)
        }
    }
    private func action(_ kind: LiveActionIcon.Kind, label: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            LiveActionIcon(kind: kind)
                .phaseAnimator([false, true, false], trigger: likePulse) { icon, enlarged in
                    icon.scaleEffect(kind == .heart && enlarged ? 1.15 : 1)
                }
                .contentShape(Rectangle())
        }.accessibilityLabel(label)
    }
}

struct LiveFloatingHeart: Identifiable {
    let id = UUID()
    let lane: Int
}

struct FloatingHeartView: View {
    let lane: Int
    @State private var lifted = false
    var body: some View {
        Image(systemName: "heart.fill").font(.system(size: 30)).foregroundStyle(.pink.gradient)
            .scaleEffect(lifted ? 1.2 : 0.5)
            .offset(x: CGFloat(lane - 1) * 18, y: lifted ? -180 : 0)
            .opacity(lifted ? 0 : 0.95)
            .onAppear { withAnimation(.easeOut(duration: 1.2)) { lifted = true } }
            .accessibilityHidden(true).allowsHitTesting(false)
    }
}
