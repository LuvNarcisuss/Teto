import AVFoundation
import SwiftUI

@MainActor
struct LiveRoomView: View {
    @EnvironmentObject private var app: AppStore
    @State private var showingCreator = false
    @State private var reportTarget: ContentSafetyTarget?
    @StateObject private var room: LiveRoomStore
    @StateObject private var playback = LiveRoomPlayback()
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.dynamicTypeSize) private var typeSize
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @Environment(\.accessibilityVoiceOverEnabled) private var voiceOverEnabled
    @FocusState private var composing: Bool
    @State private var draft = ""
    @State private var panel: LiveRoomPanel?
    @State private var hearts: [LiveFloatingHeart] = []
    @State private var likePulse = 0
    @State private var visible = false
    private var config: LiveRoomConfiguration { room.configuration }
    private var canPlay: Bool { visible && scenePhase == .active && panel == nil && reportTarget == nil && !showingCreator && !app.isCreatorBlocked(creator.id) }
    private var creator: CreatorProfile {
        if let id = config.sourceVideoID, let video = app.collectionVideos.first(where: { $0.id == id }) {
            return .from(video: video, profile: app.library.profile, coverURL: app.coverURL(video))
        }
        return .from(room: config)
    }
    private var countsAsViewing: Bool {
        canPlay && playback.player != nil && !playback.loading && playback.failure == nil && !playback.pausedByUser
    }
    private var compact: Bool { verticalSizeClass == .compact }

    init(configuration: LiveRoomConfiguration) {
        _room = StateObject(wrappedValue: LiveRoomStore(configuration: configuration))
    }

    var body: some View {
        ZStack {
            LiveVideoView(configuration: config, playback: playback)
            VStack(spacing: 0) {
                LinearGradient(colors: [.black.opacity(0.42), .clear], startPoint: .top, endPoint: .bottom).frame(height: 170)
                Spacer(minLength: 0)
                LinearGradient(colors: [.clear, .black.opacity(0.53)], startPoint: .top, endPoint: .bottom).frame(height: 300)
            }.ignoresSafeArea().allowsHitTesting(false)
            VStack(spacing: 0) {
                header.padding(.horizontal, 12)
                if !composing && !compact {
                    SecondaryNavigationView(mode: config.mode, studio: { open(.studio) }, community: { open(.community) })
                        .padding(.horizontal, 12)
                }
                playbackStatus.padding(.horizontal, 12).padding(.top, 4)
                Spacer(minLength: 8)
                lowerContent
                    .frame(minHeight: 70, idealHeight: commentHeight, maxHeight: commentHeight)
                    .layoutPriority(-1)
                    .padding(.horizontal, 12)
            }
            .padding(.top, 4)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        // Only the media ignores keyboard insets. The HUD and input follow the keyboard.
        .safeAreaInset(edge: .bottom, spacing: 0) {
            BottomActionBarView(text: $draft, focus: $composing,
                sending: room.isSending, likePulse: likePulse, send: send, like: like,
                gift: { open(.gifts) }, share: { open(.share) })
        }
        .overlay(alignment: .bottomTrailing) {
            ZStack {
                ForEach(hearts) { heart in
                    FloatingHeartView(lane: heart.lane)
                        .task {
                            do { try await Task.sleep(for: .milliseconds(1300)) } catch { return }
                            hearts.removeAll { $0.id == heart.id }
                        }
                }
            }.frame(width: 90, height: 1).padding(.trailing, 64).padding(.bottom, 65)
                .allowsHitTesting(false).accessibilityHidden(true)
        }
        .overlay(alignment: .top) {
            if let notice = room.notice, panel == nil {
                Text(notice).font(.caption).multilineTextAlignment(.center)
                    .padding(10).background(.black.opacity(0.8), in: Capsule())
                    .padding(.horizontal, 24).padding(.top, 108)
                    .allowsHitTesting(false).accessibilityAddTraits(.updatesFrequently)
            }
        }
        .foregroundStyle(.white).tint(.white)
        .preferredColorScheme(.dark)
        .toolbar(.hidden, for: .navigationBar, .tabBar)
        .statusBarHidden(false)
        .sensoryFeedback(.impact(weight: .light), trigger: likePulse)
        .onAppear {
            guard !app.isCreatorBlocked(creator.id) else { dismiss(); return }
            visible = true
            room.start()
            playback.prepare(config.media)
            syncActivity()
        }
        .task(id: countsAsViewing) {
            guard countsAsViewing, let id = config.sourceVideoID else { return }
            let start = playback.player?.currentTime().seconds ?? 0
            do { try await Task.sleep(for: .seconds(2)) } catch { return }
            guard !Task.isCancelled, countsAsViewing,
                  let player = playback.player, player.rate > 0,
                  player.currentTime().seconds != start else { return }
            await app.recordVideoViewed(id)
        }
        .onChange(of: app.isCreatorBlocked(creator.id)) { _, blocked in
            if blocked { playback.stop(); room.stop() }
        }
        .onChange(of: showingCreator) { _, _ in syncActivity() }
        .onChange(of: reportTarget?.id) { _, _ in syncActivity() }
        .sheet(item: $reportTarget, onDismiss: syncActivity) { target in
            NavigationStack {
                ContentReportView(target: target)
                    .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Close") { reportTarget = nil } } }
            }.preferredColorScheme(.light).tint(TetoStyle.emerald)
        }
        .onChange(of: scenePhase) { _, _ in syncActivity() }
        .onChange(of: panel) { _, _ in syncActivity() }
        .onChange(of: reduceMotion) { _, reduced in if reduced { hearts.removeAll() }; syncActivity() }
        .onChange(of: voiceOverEnabled) { _, _ in syncActivity() }
        .onChange(of: composing) { _, _ in syncActivity() }
        .onChange(of: playback.pausedByUser) { _, _ in syncActivity() }
        .onChange(of: playback.loading) { _, _ in syncActivity() }
        .onChange(of: playback.failure) { _, _ in syncActivity() }
        .onChange(of: room.commentFlowEnabled) { _, _ in syncActivity() }
        .onDisappear {
            visible = false; composing = false; hearts.removeAll()
            playback.stop(); room.stop()
        }
        .fullScreenCover(isPresented: $showingCreator, onDismiss: syncActivity) {
            CreatorProfileView(creator: creator)
        }
        .sheet(item: $panel, onDismiss: {
            if app.isCreatorBlocked(creator.id) { playback.stop(); room.stop(); dismiss() }
            else { syncActivity() }
        }) { panel in
            if panel == .share {
                LiveShareSheet(text: config.shareText).presentationDetents([.medium, .large])
            } else {
                NavigationStack {
                    panelContent(panel)
                        .freshStudioPage().tetoNavigationTitle(panel.title).navigationBarTitleDisplayMode(.inline)
                        .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { self.panel = nil } } }
                        .safeAreaInset(edge: .bottom) {
                            if let notice = room.notice {
                                Text(notice).font(.footnote).padding(12).frame(maxWidth: .infinity).foregroundStyle(TetoStyle.ink).background(TetoStyle.soft)
                            }
                        }
                }
                .tint(TetoStyle.emerald).preferredColorScheme(.light)
                .presentationDetents(typeSize.isAccessibilitySize || panel == .gifts ? [.large] : [.medium, .large])
                .presentationDragIndicator(.visible)
            }
        }
    }

    private var commentHeight: CGFloat {
        compact ? 108 : (composing ? 140 : (typeSize.isAccessibilitySize ? 260 : 245))
    }

    private var header: some View {
        Group {
            if composing {
                HStack {
                    Text(config.streamer.name).font(.subheadline.weight(.semibold)).lineLimit(1)
                    Spacer(minLength: 8)
                    closeButton
                }
            } else if typeSize.isAccessibilitySize {
                VStack(spacing: 4) {
                    streamer
                    HStack { audience(0); Spacer(); closeButton }
                }
            } else {
                ViewThatFits(in: .horizontal) {
                    headerRow(avatars: 3)
                    headerRow(avatars: 1)
                    headerRow(avatars: 0)
                }
            }
        }
    }
    private var streamer: some View {
        StreamerHeaderView(streamer: config.streamer,
            likes: room.likes, following: app.isFollowingCreator(creator.id), busy: app.isBusy,
            follow: { Task { await app.toggleCreatorFollow(creator.id) } },
            openCreator: { composing = false; showingCreator = true; syncActivity() })
    }
    private func headerRow(avatars: Int) -> some View {
        HStack(spacing: 4) { streamer.frame(minWidth: 155); Spacer(minLength: 0); audience(avatars); closeButton }
    }
    private func audience(_ maximum: Int) -> some View {
        AudienceAvatarsView(members: config.audience, maxAvatars: maximum, action: { open(.audience) })
            .fixedSize(horizontal: true, vertical: false)
    }
    private var closeButton: some View {
        Button {
            composing = false; playback.stop(); room.stop(); dismiss()
        } label: {
            Image(systemName: "xmark").font(.system(size: 20, weight: .semibold))
                .frame(width: 44, height: 44).background(LiveRoomStyle.panel, in: Circle())
        }.buttonStyle(.plain).accessibilityLabel("Close room")
    }
    private var playbackStatus: some View {
        HStack(spacing: 8) {
            if playback.loading { ProgressView().tint(.white).accessibilityLabel("Loading video") }
            if let failure = playback.failure {
                Button("Retry") { playback.retry(config.media, active: canPlay) }
                    .font(.caption).frame(minHeight: 44).accessibilityHint(failure)
            }
            Spacer(minLength: 0)
            Button { open(.media) } label: {
                Image(systemName: "ellipsis").frame(width: 44, height: 44)
                    .background(LiveRoomStyle.panel, in: Circle())
            }.buttonStyle(.plain).accessibilityLabel("More options")
        }
    }

    private var lowerContent: some View {
        GeometryReader { bounds in
            CommentFeedView(comments: room.comments, report: { comment in
                composing = false
                reportTarget = .comment(id: "live:\(config.id):\(comment.id)", name: comment.nickname, text: comment.text)
            })
                .frame(width: bounds.size.width * 0.85)
                .frame(maxHeight: .infinity, alignment: .bottom)
        }
    }

    private func syncActivity() {
        playback.setActive(canPlay)
        room.setCommentLoopActive(canPlay && playback.player != nil && !playback.loading && playback.failure == nil
            && !playback.pausedByUser && !composing && !voiceOverEnabled && !reduceMotion)
    }

    private func open(_ value: LiveRoomPanel) { composing = false; panel = value }
    private func send() {
        let submitted = draft
        room.run {
            if await room.send(submitted), !Task.isCancelled {
                if draft == submitted { draft = "" }
                composing = false
            }
        }
    }
    private func like() {
        room.run { await room.perform(.like) }
        guard !reduceMotion else { return }
        likePulse += 1
        if hearts.count < 8 { hearts.append(LiveFloatingHeart(lane: likePulse % 3)) }
    }

    @ViewBuilder private func panelContent(_ panel: LiveRoomPanel) -> some View {
        switch panel {
        case .gifts:
            GiftSheetView(wallet: app.wallet, roomID: config.id)
        case .audience:
            AudienceListView(audience: config.audience)
        case .studio:
            List {
                Section(config.mode.title) {
                    Label("Start with the groove", systemImage: "waveform")
                    Text("Listen for the beat, then break the combination into eight-counts.")
                    Label("Make it your own", systemImage: "figure.dance")
                    Text("Try the steps slowly, then add your own style.")
                }
                Section("Your next move") {
                    Text("Save a routine you love. Add your own dance clip from the Live tab.")
                }
            }
        case .community:
            List {
                Section("Find your people") {
                    Label("Choreography", systemImage: "figure.dance")
                    Label("Freestyle", systemImage: "music.note")
                    Text("Share your progress, trade practice tips, and celebrate every small win.")
                }
            }
        case .media:
            List {
                ContentSafetyActions(target: ContentSafetyTarget(id: config.sourceVideoID?.uuidString ?? config.id,
                    title: config.title, kind: .live, creator: creator), onBlocked: { self.panel = nil })
                Section("Playback") {
                    Text(config.title).font(TetoTypography.headline)
                    if let failure = playback.failure { Text(failure).foregroundStyle(.orange) }
                    if playback.player != nil {
                        Button(playback.pausedByUser ? "Resume" : "Pause") { playback.togglePause() }
                        Button(playback.muted ? "Turn sound on" : "Mute") { playback.toggleMute() }
                        Text("Speed: 1× · Looping")
                    }
                    Toggle("Chat flow", isOn: $room.commentFlowEnabled)
                }
                if config.media.credit != nil || config.media.sourceURL != nil {
                    Section("Credits") {
                        if let credit = config.media.credit { Text(credit) }
                        if let url = config.media.sourceURL { Link("Original film", destination: url) }
                    }
                }
            }
        case .share: EmptyView()
        }
    }
}

#Preview("Choreography") { LiveRoomView(configuration: DanceRoomLibrary.featured(.choreography)).environmentObject(AppStore()) }
#Preview("Freestyle") { LiveRoomView(configuration: DanceRoomLibrary.featured(.freestyle)).environmentObject(AppStore()) }
#Preview("Empty / Large Type") {
    var config = DanceRoomLibrary.featured(.choreography)
    config.audience = []; config.initialComments = []; config.commentLoop = []
    config.streamer.name = "The Eight Count Collective and Friends"
    config.media = LiveRoomMedia(source: .coverOnly)
    return LiveRoomView(configuration: config).environmentObject(AppStore()).environment(\.dynamicTypeSize, .accessibility1)
}
#Preview("Missing local video") {
    var config = DanceRoomLibrary.featured(.freestyle)
    config.media.source = .local(URL(fileURLWithPath: "/missing-dance.mp4"))
    return LiveRoomView(configuration: config).environmentObject(AppStore())
}
