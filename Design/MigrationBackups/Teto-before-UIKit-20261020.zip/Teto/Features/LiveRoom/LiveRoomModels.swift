import Foundation

enum LiveRoomMode: String, CaseIterable, Identifiable {
    case choreography = "Choreography", freestyle = "Freestyle"
    var id: String { rawValue }
    var title: String { rawValue }
    var symbol: String { "figure.dance" }
}

enum LiveMediaSource: Equatable {
    case local(URL), remote(URL), coverOnly
    var url: URL? {
        switch self { case .local(let url), .remote(let url): return url; case .coverOnly: return nil }
    }
}

enum LiveVideoScaling { case fill, fit }

struct LiveRoomMedia {
    var source: LiveMediaSource
    var scaling: LiveVideoScaling = .fill
    var coverAsset: String? = nil
    var coverURL: URL? = nil
    var credit: String? = nil
    var sourceURL: URL? = nil
}

struct Streamer {
    var name: String
    var avatarAsset: String? = nil
    var likeCount = 0
}

struct AudienceMember: Identifiable {
    let id: String
    var name: String
    var avatarAsset: String? = nil
    var symbol: String = "person.fill"
}

struct UserBadge: Identifiable {
    enum Kind { case level, fan, moderator, streamer }
    let kind: Kind
    let text: String
    var id: String { "\(kind)-\(text)" }
}

struct LiveComment: Identifiable {
    enum Kind { case regular, streamer, moderator, arrival, system }
    var id = UUID()
    var nickname: String
    var text: String
    var badges: [UserBadge] = []
    var kind: Kind = .regular
    var isLocal = false
}

struct LiveRoomConfiguration: Identifiable {
    var id: String
    var mode: LiveRoomMode
    var title: String
    var streamer: Streamer
    var audience: [AudienceMember] = []
    var initialComments: [LiveComment]
    var commentLoop: [LiveComment]
    var media: LiveRoomMedia
    var sourceVideoID: UUID? = nil
    var shareText: String { "\(title) · Find your rhythm with Teto." }
}

/// Authored chat atmosphere, not a network subscription or real account activity.
/// Handles are fictional. No viewer counts, delivery receipts or transactions are generated.
enum DanceCommentScript {
    static let lines: [(String, String)] = [
        ("BeatBloom", "That footwork is so clean!"),
        ("EightCount", "Five, six, seven, eight!"),
        ("GrooveGarden", "The way you hit that beat!"),
        ("StepStories", "That transition was smooth."),
        ("RhythmFox", "Adding this combo to my practice list."),
        ("MotionMuse", "Love the energy in this routine."),
        ("TempoTrail", "Can we run that eight-count again?"),
        ("BeatBloom", "The shoulder groove is everything."),
        ("FlowClub", "Small steps, big confidence."),
        ("EightCount", "Your timing is on point."),
        ("GrooveGarden", "That turn into the next step!"),
        ("StepStories", "What style are you practicing today?"),
        ("RhythmFox", "Taking notes on that weight shift."),
        ("MotionMuse", "Such a satisfying finish."),
        ("TempoTrail", "One more round, let's go!"),
        ("FlowClub", "Dance breaks make the day better."),
        ("BeatBloom", "The details make this combo shine."),
        ("EightCount", "Feel the rhythm before the next step."),
        ("GrooveGarden", "This is my sign to get up and move."),
        ("StepStories", "That freestyle has so much personality."),
        ("RhythmFox", "Clean lines and a relaxed groove."),
        ("MotionMuse", "Would love a slower breakdown of the steps."),
        ("TempoTrail", "That little pause before the drop!"),
        ("FlowClub", "Keep moving. Keep finding your style."),
        ("BeatBloom", "That bounce feels effortless."),
        ("EightCount", "The groove starts in the knees."),
        ("GrooveGarden", "Love that change of direction."),
        ("StepStories", "Such a clean step-touch."),
        ("RhythmFox", "Your arms tell the story."),
        ("MotionMuse", "That heel-toe pattern is crisp."),
        ("TempoTrail", "A little groove goes a long way."),
        ("FlowClub", "Love the control in that isolation."),
        ("BeatBloom", "The rhythm is in the details."),
        ("EightCount", "That foot slide was seamless."),
        ("GrooveGarden", "Nice balance through the turn."),
        ("StepStories", "The textures in this routine!"),
        ("RhythmFox", "Every accent has its own moment."),
        ("MotionMuse", "Those level changes are smooth."),
        ("TempoTrail", "That last step caught my eye."),
        ("FlowClub", "Feeling the music through movement."),
        ("BeatBloom", "This combo has a great flow."),
        ("EightCount", "The rebound looks so natural."),
        ("GrooveGarden", "What a fun way to warm up."),
        ("StepStories", "Love a relaxed freestyle session."),
        ("RhythmFox", "The confidence in that walk!"),
        ("MotionMuse", "That shoulder roll is so fluid."),
        ("TempoTrail", "Let the movement breathe."),
        ("FlowClub", "The foot placement is so precise."),
        ("BeatBloom", "One beat, a hundred possibilities."),
        ("EightCount", "That change of pace is clever."),
        ("GrooveGarden", "The groove never stops."),
        ("StepStories", "Finding a new favorite step."),
        ("RhythmFox", "Your musicality shines through."),
        ("MotionMuse", "Love the travel across the floor."),
        ("TempoTrail", "That little wrist accent!"),
        ("FlowClub", "The body wave is beautiful."),
        ("BeatBloom", "This sequence feels playful."),
        ("EightCount", "Strong shapes, soft transitions."),
        ("GrooveGarden", "Try it slow, then find the flow."),
        ("StepStories", "Would love to learn this combo."),
        ("RhythmFox", "Every practice counts."),
        ("MotionMuse", "That pivot was sharp."),
        ("TempoTrail", "Nice control on the stop."),
        ("FlowClub", "The ending ties it all together."),
        ("BeatBloom", "Taking this energy into practice."),
        ("EightCount", "Dance is a whole mood."),
        ("GrooveGarden", "That diagonal step is a nice touch."),
        ("StepStories", "The timing of that release!"),
        ("RhythmFox", "Such a good use of space."),
        ("MotionMuse", "A clean groove always hits."),
        ("TempoTrail", "The small accents make it yours."),
        ("FlowClub", "The movement looks so free."),
        ("BeatBloom", "That rhythm switch is fun."),
        ("EightCount", "Love the expression in this."),
        ("GrooveGarden", "This makes me want to practice."),
        ("StepStories", "That slow moment adds so much."),
        ("RhythmFox", "Smooth entry into the next count."),
        ("MotionMuse", "The footwork has its own melody."),
        ("TempoTrail", "Building confidence one combo at a time."),
        ("FlowClub", "What inspired this routine?"),
        ("BeatBloom", "The flow between steps is lovely."),
        ("EightCount", "Keeping the shoulders loose helps."),
        ("GrooveGarden", "Great energy from start to finish."),
        ("StepStories", "That turn feels perfectly placed."),
        ("RhythmFox", "A little practice, a little progress."),
        ("MotionMuse", "The groove is contagious."),
        ("TempoTrail", "Love the shape of that reach."),
        ("FlowClub", "Every dancer brings a different story."),
        ("BeatBloom", "That side step has personality."),
        ("EightCount", "The pause makes the next move pop."),
        ("GrooveGarden", "This is a great practice reminder."),
        ("StepStories", "Nice rhythm through the whole combo."),
        ("RhythmFox", "Your style makes the steps unique."),
        ("MotionMuse", "Let your feet find the beat."),
        ("TempoTrail", "A fresh take on a familiar groove."),
        ("FlowClub", "Keep exploring your movement.")
    ]
    static var comments: [LiveComment] { lines.map { LiveComment(nickname: $0.0, text: $0.1) } }
}

enum DanceRoomLibrary {
    static func room(video: LocalVideo, videoURL: URL, coverURL: URL, displayName: String) -> LiveRoomConfiguration {
        let opening = DanceDiscussionContent.lines(for: video).map {
            LiveComment(nickname: $0.name, text: $0.text)
        }
        let sequence = opening + DanceCommentScript.comments.shuffled()
        return LiveRoomConfiguration(id: video.id.uuidString,
            mode: video.bundledClip?.assetName == "dance-seaside" ? .freestyle : .choreography,
            title: video.title,
            streamer: Streamer(name: video.bundledClip?.creator ?? displayName,
                               avatarAsset: FreshStudioPhotos.creatorAvatar(for: video.creatorID)),
            initialComments: Array(sequence.prefix(5)), commentLoop: sequence,
            media: LiveRoomMedia(source: .local(videoURL), coverURL: coverURL,
                credit: video.bundledClip.map { "\($0.creator) / Pexels" }, sourceURL: video.bundledClip?.sourceURL), sourceVideoID: video.id)
    }
    static func featured(_ mode: LiveRoomMode) -> LiveRoomConfiguration {
        let entry = mode == .freestyle ? DanceVideoCatalog.entries[1] : DanceVideoCatalog.entries[0]
        return room(video: entry.localVideo, videoURL: entry.resourceURL(fileExtension: "mp4"),
                    coverURL: entry.resourceURL(fileExtension: "jpg"), displayName: entry.creator)
    }
}
