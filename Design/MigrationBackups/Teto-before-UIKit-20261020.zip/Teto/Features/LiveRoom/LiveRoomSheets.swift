import SwiftUI
import UIKit

enum LiveRoomPanel: String, Identifiable {
    case gifts, share, audience, studio, community, media
    var id: String { rawValue }
    var title: String {
        switch self {
        case .gifts: return "Send some love"; case .share: return "Share"; case .audience: return "People"
        case .studio: return "Practice notes"; case .community: return "Dance floor"; case .media: return "More options"
        }
    }
}

struct AudienceListView: View {
    let audience: [AudienceMember]
    var body: some View {
        Group {
            if audience.isEmpty {
                ContentUnavailableView("No connections yet", systemImage: "person.2", description: Text("Your dance circle starts here."))
            } else {
                List(audience) { member in
                    HStack(spacing: 12) { LiveAvatar(asset: member.avatarAsset, symbol: member.symbol); Text(member.name) }.padding(.vertical, 4)
                }
            }
        }
    }
}

struct LiveShareSheet: UIViewControllerRepresentable {
    let text: String
    var onCompleted: (() -> Void)? = nil
    func makeUIViewController(context: Context) -> UIActivityViewController {
        let controller = UIActivityViewController(activityItems: [text], applicationActivities: nil)
        controller.completionWithItemsHandler = { _, completed, _, error in
            // Completion is an activity result, not confirmation of recipient delivery.
            guard completed, error == nil else { return }
            Task { @MainActor in onCompleted?() }
        }
        return controller
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
