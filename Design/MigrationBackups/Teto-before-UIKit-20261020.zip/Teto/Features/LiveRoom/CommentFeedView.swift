import SwiftUI

struct CommentFeedView: View {
    let comments: [LiveComment]
    var report: ((LiveComment) -> Void)? = nil
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var followingLatest = true
    @State private var pending = 0
    @State private var bottomVisible = true
    @State private var viewportHeight: CGFloat = 1
    @Namespace private var coordinateSpace

    var body: some View {
        ScrollViewReader { proxy in
            ZStack(alignment: .bottomLeading) {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 5) {
                        ForEach(comments) { comment in
                            if let report, !comment.isLocal, comment.kind != .system {
                                CommentBubbleView(comment: comment)
                                    .contextMenu { Button("Report comment", systemImage: "flag") { report(comment) } }
                                    .accessibilityAction(named: "Report comment") { report(comment) }
                                    .id(comment.id)
                            } else { CommentBubbleView(comment: comment).id(comment.id) }
                        }
                        Color.clear.frame(height: 1).id("comment-bottom")
                            .background(GeometryReader { geometry in
                                Color.clear.preference(key: CommentBottomPreference.self,
                                    value: geometry.frame(in: .named(coordinateSpace)).maxY)
                            })
                    }.padding(.top, 14).padding(.bottom, 2)
                }
                .coordinateSpace(name: coordinateSpace)
                .scrollIndicators(.hidden)
                .defaultScrollAnchor(.bottom)
                .accessibilityAction(named: "Pause scrolling to read earlier comments") { followingLatest = false }
                .accessibilityAction(named: "Latest comments") {
                    followingLatest = true; pending = 0
                    proxy.scrollTo("comment-bottom", anchor: .bottom)
                }
                .background(GeometryReader { geometry in
                    Color.clear.onAppear { viewportHeight = geometry.size.height }
                        .onChange(of: geometry.size.height) { _, height in viewportHeight = height }
                })
                .simultaneousGesture(DragGesture(minimumDistance: 8).onChanged { _ in followingLatest = false }
                    .onEnded { _ in if bottomVisible { followingLatest = true; pending = 0 } })
                .onPreferenceChange(CommentBottomPreference.self) { bottom in
                    bottomVisible = bottom <= viewportHeight + 12 && bottom >= 0
                    if bottomVisible { followingLatest = true; pending = 0 }
                }
                .mask(LinearGradient(stops: [.init(color: .clear, location: 0), .init(color: .black, location: 0.08), .init(color: .black, location: 1)], startPoint: .top, endPoint: .bottom))
                if pending > 0 {
                    Button {
                        followingLatest = true; pending = 0
                        proxy.scrollTo("comment-bottom", anchor: .bottom)
                    } label: {
                        Label("\(pending) new comments", systemImage: "arrow.down")
                            .font(.caption.bold()).padding(10).background(.black.opacity(0.8), in: Capsule())
                            .frame(minHeight: 44)
                    }.buttonStyle(.plain)
                }
            }
            .onChange(of: comments.last?.id) { _, _ in
                if followingLatest {
                    withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) {
                        proxy.scrollTo("comment-bottom", anchor: .bottom)
                    }
                } else { pending += 1 }
            }
            .onChange(of: viewportHeight) { _, _ in
                if followingLatest { proxy.scrollTo("comment-bottom", anchor: .bottom) }
            }
        }.foregroundStyle(.white)
        .overlay {
            if comments.isEmpty {
                Text("Be the first to say something").font(.caption).foregroundStyle(.white.opacity(0.65))
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
            }
        }
    }
}

private struct CommentBottomPreference: PreferenceKey {
    // An off-screen lazy sentinel must not look like the bottom is visible at y = 0.
    static var defaultValue: CGFloat = .infinity
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) { value = nextValue() }
}

struct CommentBubbleView: View {
    let comment: LiveComment
    var body: some View {
        richText
            .font(.subheadline).lineSpacing(3)
            .fixedSize(horizontal: false, vertical: true)
            .padding(.horizontal, 9).padding(.vertical, 5)
            .background(LiveRoomStyle.panel, in: RoundedRectangle(cornerRadius: 15))
            .frame(maxWidth: .infinity, alignment: .leading)
            .accessibilityElement(children: .ignore)
            .accessibilityLabel("\(comment.badges.map(\.text).joined(separator: " ")) \(comment.nickname): \(comment.text)")
    }
    private var richText: Text {
        let badges = comment.badges.reduce(Text("")) { result, badge in
            let color: Color
            let label: String
            switch badge.kind {
            case .level: color = TetoStyle.emerald; label = "◆\(badge.text)"
            case .fan: color = TetoStyle.emerald; label = "♥\(badge.text)"
            case .moderator, .streamer: color = TetoStyle.ink; label = badge.text
            }
            var text = AttributedString(" \(label) ")
            text.foregroundColor = .white
            text.backgroundColor = color.opacity(0.7)
            text.font = .caption2.bold()
            return result + Text(text) + Text(" ")
        }
        let name = Text(comment.nickname + (comment.kind == .arrival ? " " : ": ")).foregroundColor(LiveRoomStyle.nickname)
        let body = Text(comment.text).foregroundColor(comment.kind == .system ? .white.opacity(0.8) : .white)
        return badges + name + body
    }
}
