import SwiftUI

enum LiveRoomStyle {
    static let panel = TetoStyle.night.opacity(0.38)
    static let nickname = TetoStyle.lime
}

struct LiveAvatar: View {
    var asset: String?
    var symbol = "figure.dance"
    var size: CGFloat = 36
    var body: some View {
        Group {
            if let asset, let image = UIImage(named: FreshStudioPhotos.avatar(asset)) {
                Image(uiImage: image).resizable().scaledToFill()
            } else {
                ZStack {
                    TetoStyle.emerald
                    Image(systemName: symbol).font(.system(size: size * 0.47)).foregroundStyle(.white)
                }
            }
        }
        .frame(width: size, height: size).clipShape(Circle())
        .overlay(Circle().strokeBorder(.white.opacity(0.55), lineWidth: 0.75))
        .accessibilityHidden(true)
    }
}

struct StreamerHeaderView: View {
    let streamer: Streamer
    let likes: Int
    let following: Bool
    let busy: Bool
    let follow: () -> Void
    let openCreator: () -> Void
    var body: some View {
        HStack(spacing: 6) {
            Button(action: openCreator) {
                HStack(spacing: 6) {
                    LiveAvatar(asset: streamer.avatarAsset).frame(width: 44, height: 44)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(streamer.name).font(.subheadline.weight(.semibold)).lineLimit(1).truncationMode(.tail)
                        Text("\(likes) likes").font(.caption2).foregroundStyle(.white.opacity(0.8)).lineLimit(1)
                    }.frame(maxWidth: .infinity, alignment: .leading)
                }.contentShape(Rectangle())
            }.buttonStyle(.plain).accessibilityLabel("View creator \(streamer.name)")
            Button(action: follow) {
                Text(following ? "Following" : "Follow").font(.caption.weight(.semibold))
                    .padding(.horizontal, 10).frame(minHeight: 44)
                    .background(following ? Color.white.opacity(0.18) : TetoStyle.emerald, in: Capsule())
            }.buttonStyle(.plain).disabled(busy)
                .accessibilityLabel(following ? "Unfollow" : "Follow")
        }
        .padding(.horizontal, 3).padding(.vertical, 2)
        .background(LiveRoomStyle.panel, in: Capsule()).foregroundStyle(.white)
    }
}

struct AudienceAvatarsView: View {
    let members: [AudienceMember]
    let maxAvatars: Int
    let action: () -> Void
    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                if maxAvatars > 0 {
                    HStack(spacing: -9) {
                        ForEach(Array(members.prefix(maxAvatars))) { member in
                            LiveAvatar(asset: member.avatarAsset, symbol: member.symbol, size: 27)
                        }
                    }
                }
                Image(systemName: "person.2.fill").font(.caption)
                    .frame(width: 36, height: 36).background(LiveRoomStyle.panel, in: Circle())
            }.frame(minHeight: 44)
        }.buttonStyle(.plain).foregroundStyle(.white).accessibilityLabel("People")
    }
}

struct SecondaryNavigationView: View {
    let mode: LiveRoomMode
    let studio: () -> Void
    let community: () -> Void
    var body: some View {
        HStack {
            Button(action: studio) {
                Label(mode.title, systemImage: "figure.dance")
                    .font(.caption.weight(.semibold)).padding(.horizontal, 10).padding(.vertical, 7)
                    .background(LiveRoomStyle.panel, in: Capsule()).frame(minHeight: 44)
            }
            Spacer(minLength: 8)
            Button(action: community) {
                HStack(spacing: 6) { Text("Dance floor"); Image(systemName: "chevron.right").font(.caption.bold()) }
                    .font(.caption).padding(.horizontal, 10).padding(.vertical, 7)
                    .background(LiveRoomStyle.panel, in: Capsule()).frame(minHeight: 44)
            }
        }.buttonStyle(.plain).foregroundStyle(.white)
    }
}

struct LiveActionIcon: View {
    enum Kind: String {
        case heart = "LiveHeart", gift = "LiveGift", share = "LiveShare"
        var symbol: String {
            switch self { case .heart: return "heart"; case .gift: return "gift"; case .share: return "arrowshape.turn.up.right" }
        }
        var color: Color {
            switch self { case .heart: return .white; case .gift: return TetoStyle.lime; case .share: return .white }
        }
    }
    let kind: Kind
    var body: some View {
        ZStack {
            Circle().fill(LiveRoomStyle.panel)
            Image(systemName: kind.symbol)
                .font(.system(size: 24, weight: .regular)).foregroundStyle(kind.color)

        }.frame(width: 44, height: 44).accessibilityHidden(true)
    }
}
