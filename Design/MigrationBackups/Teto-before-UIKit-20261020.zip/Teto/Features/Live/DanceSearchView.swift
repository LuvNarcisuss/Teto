import SwiftUI

/// An explicit top search field keeps placement consistent across iOS versions.
/// The owning page supplies its safe-area placement, just like the Chats header.
struct TopSearchBar: View {
    @Binding var query: String
    let prompt: String
    var focusOnAppear = true
    var isActive = true
    var cancelTitle = "Cancel"
    var drawsBackground = true
    let cancel: () -> Void
    @FocusState private var focused: Bool

    var body: some View {
        HStack(spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").font(.system(size: 24))
                    .accessibilityHidden(true)
                TextField(prompt, text: $query)
                    .font(.body).focused($focused)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                    .submitLabel(.search).onSubmit { focused = false }
                    .accessibilityLabel(prompt)
                if !query.isEmpty {
                    Button { query = "" } label: {
                        Image(systemName: "xmark.circle.fill").foregroundStyle(TetoStyle.muted)
                            .frame(width: 44, height: 44)
                    }.accessibilityLabel("Clear search")
                }
            }
            .padding(.leading, 12).padding(.trailing, query.isEmpty ? 12 : 0)
            .frame(minHeight: 44)
            .background(TetoStyle.soft, in: Capsule())
            Button(cancelTitle) { focused = false; cancel() }
                .frame(minHeight: 44).foregroundStyle(TetoStyle.emerald)
                .fixedSize(horizontal: true, vertical: false)
        }
        .buttonStyle(.plain).foregroundStyle(TetoStyle.ink).tint(TetoStyle.emerald)
        .padding(.horizontal, 16).padding(.vertical, 6)
        .background {
            if drawsBackground { TetoStyle.chromeGradient.ignoresSafeArea(edges: .top) }
        }
        .task {
            guard focusOnAppear else { return }
            await Task.yield()
            guard !Task.isCancelled else { return }
            focused = true
        }
        .onChange(of: isActive) { _, active in
            if !active { focused = false }
        }
        .onDisappear { focused = false }
    }
}

struct DanceSearchResults: View {
    let videos: [LocalVideo]
    let profile: LocalProfile
    let query: String
    var drawsBackground = true
    let select: (UUID) -> Void

    private var matches: [LocalVideo] {
        let term = query.trimmingCharacters(in: .whitespacesAndNewlines)
        return videos.filter { term.isEmpty || "\($0.title) \($0.creatorName(profile: profile)) \($0.danceDescription)".localizedCaseInsensitiveContains(term) }
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 0) {
                if matches.isEmpty {
                    ContentUnavailableView.search(text: query)
                } else {
                    ForEach(matches) { video in
                        Button { select(video.id) } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                Text(video.title).font(TetoTypography.headline)
                                Text(video.creatorName(profile: profile)).font(.subheadline).foregroundStyle(TetoStyle.muted)
                                Text(video.danceDescription).font(.caption).foregroundStyle(TetoStyle.muted).lineLimit(2)
                            }
                            .padding(.vertical, 14).padding(.horizontal, 16)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .contentShape(Rectangle())
                        }.buttonStyle(.plain)
                        Divider().padding(.leading, 16)
                    }
                }
            }
        }
        .scrollDismissesKeyboard(.interactively)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .foregroundStyle(TetoStyle.ink)
        .background {
            if drawsBackground { FreshStudioPageBackground().ignoresSafeArea(edges: .bottom) }
        }
        .environment(\.colorScheme, .light)
    }
}
