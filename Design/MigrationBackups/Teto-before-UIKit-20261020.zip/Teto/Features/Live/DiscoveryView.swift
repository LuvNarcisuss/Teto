import SwiftUI

enum DiscoverySection: String, CaseIterable {
    case live = "Live", shorts = "Shorts"
}

struct DiscoveryView: View {
    @Binding var section: DiscoverySection
    let isTabActive: Bool
    @EnvironmentObject private var store: AppStore
    @State private var isSearchingShorts = false
    @State private var isSearchingLive = false
    @State private var creation: CreationKind?
    @State private var searchQuery = ""
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var searchedRoom: LiveRoomConfiguration?
    private var immersive: Bool { section == .shorts }
    private var searching: Bool { isSearchingLive || isSearchingShorts }

    var body: some View {
        Group {
            if section == .live {
                VideoLibraryView(embedded: true)
                    .opacity(isSearchingLive ? 0 : 1)
                    .accessibilityHidden(isSearchingLive)
                    .allowsHitTesting(!isSearchingLive)
                    .overlay {
                        if isSearchingLive {
                            DanceSearchResults(videos: store.discoveryVideos, profile: store.library.profile,
                                               query: searchQuery, drawsBackground: false, select: openSearchResult)
                        }
                    }
            } else {
                ShortsFeedView(isTabActive: isTabActive && creation == nil,
                               isSearching: $isSearchingShorts, searchQuery: searchQuery)
            }
        }
        .safeAreaInset(edge: .top, spacing: 0) {
            if searching {
                TopSearchBar(query: $searchQuery, prompt: "Search dances or creators", drawsBackground: immersive, cancel: endSearch)
                    .environment(\.colorScheme, .light)
            } else { header }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background {
            if !immersive { FreshStudioPageBackground().ignoresSafeArea() }
        }
        .preferredColorScheme(immersive && !searching ? .dark : .light)
        .onChange(of: isTabActive) { _, active in
            if !active { endSearch() }
        }
        .toolbar(.hidden, for: .navigationBar)
        .toolbarBackground(.automatic, for: .tabBar)
        .toolbarColorScheme(immersive && !searching ? .dark : .light, for: .tabBar)
        .sheet(item: $creation) { kind in
            if kind == .live { LiveCreationView() }
            else { ShortVideoCreationView() }
        }
        .fullScreenCover(item: $searchedRoom) { configuration in
            LiveRoomView(configuration: configuration)
        }

    }

    private var header: some View {
        HStack(spacing: 8) {
            Button { creation = section == .live ? .live : .shortVideo } label: {
                Image(systemName: "video").font(.system(size: 22)).frame(width: 44, height: 44)
            }.accessibilityLabel(section == .live ? "Create a live session" : "Create a short video").disabled(store.isBusy)
            Spacer(minLength: 0)
            HStack(spacing: 0) {
                ForEach(DiscoverySection.allCases, id: \.self) { item in
                    Button { section = item } label: {
                        Text(item.rawValue).font(TetoTypography.tabTitle)
                            .padding(.horizontal, 18).frame(minHeight: 44)
                            .foregroundStyle(section == item ? (immersive ? TetoStyle.ink : Color.white) : (immersive ? Color.white : TetoStyle.muted))
                            .background {
                                if section == item { Capsule().fill(immersive ? Color.white : TetoStyle.emerald).padding(.vertical, 5) }
                            }
                    }.accessibilityAddTraits(section == item ? .isSelected : [])
                }
            }.padding(.horizontal, 4).background(immersive ? Color.black.opacity(0.25) : TetoStyle.soft, in: Capsule())
            Spacer(minLength: 0)
            Button {
                searchQuery = ""
                withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) {
                    if section == .shorts { isSearchingShorts = true }
                    else { isSearchingLive = true }
                }
            } label: {
                Image(systemName: "magnifyingglass").font(.system(size: 23)).frame(width: 44, height: 44)
            }.accessibilityLabel("Search dances")
        }.buttonStyle(.plain).foregroundStyle(immersive ? Color.white : TetoStyle.ink)
            .padding(.horizontal, 12).padding(.vertical, 4)
    }

    private func endSearch() {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.25)) {
            isSearchingLive = false
            isSearchingShorts = false
            searchQuery = ""
        }
    }

    private func openSearchResult(_ id: UUID) {
        guard let video = store.discoveryVideos.first(where: { $0.id == id }) else { return }
        endSearch()
        searchedRoom = DanceRoomLibrary.room(video: video, videoURL: store.videoURL(video),
            coverURL: store.coverURL(video), displayName: store.library.profile.displayName)
    }
}
