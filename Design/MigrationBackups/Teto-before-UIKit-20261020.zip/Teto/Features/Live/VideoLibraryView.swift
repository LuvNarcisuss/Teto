import SwiftUI

struct VideoLibraryView: View {
    @EnvironmentObject private var store: AppStore
    var savedOnly = false
    var embedded = false
    @State private var showSaved = false
    @State private var creating = false
    @State private var search = ""
    @State private var searching = false
    @State private var presentedRoom: LiveRoomConfiguration?
    @State private var presentedSavedVideo: LocalVideo?
    private var videos: [LocalVideo] {
        let source = embedded
            ? (showSaved ? store.discoveryVideos.filter(\.isSaved) : store.discoveryVideos)
            : (savedOnly || showSaved ? store.savedVideos : store.personalWorks)
        return source.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) }
    }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack(alignment: .top) {
                    VStack(alignment: .leading, spacing: 7) {
                        Eyebrow(text: savedOnly ? "Your collection" : "Feel the beat")
                        Text(savedOnly ? "The keepers." : "Find your rhythm.")
                            .font(TetoTypography.largeTitle).tracking(-1.3)
                    }
                    Spacer(minLength: 0)
                    Image("DanceSneakers").resizable().scaledToFit()
                        .frame(width: 72, height: 72).accessibilityHidden(true)
                    if !embedded {
                        Button { searching.toggle() } label: { CircleAction(symbol: searching ? "xmark" : "magnifyingglass") }
                            .accessibilityLabel(searching ? "Hide search" : "Search videos")
                    }
                }.foregroundStyle(TetoStyle.ink)
                if searching || !search.isEmpty {
                    HStack(spacing: 10) {
                        Image(systemName: "magnifyingglass").foregroundStyle(TetoStyle.muted)
                        TextField("Search your videos", text: $search).submitLabel(.search)
                        if !search.isEmpty {
                            Button { search = "" } label: { Image(systemName: "xmark.circle.fill") }.accessibilityLabel("Clear search")
                        }
                    }.padding(14).background(.white, in: RoundedRectangle(cornerRadius: 16))
                }
                if !savedOnly {
                    HStack(spacing: 10) {
                        FilterChip(title: "For you", selected: !showSaved) { showSaved = false }
                        FilterChip(title: "Saved", symbol: "bookmark", selected: showSaved) { showSaved = true }
                        Spacer(minLength: 0)
                        Text("\(videos.count) clips").font(.caption).foregroundStyle(TetoStyle.muted)
                    }
                }
                if videos.isEmpty {
                    if !search.isEmpty {
                        EmptyLibraryView(title: "No matching videos", description: "Try a different title.", symbol: "magnifyingglass")
                    } else if savedOnly || showSaved {
                        EmptyLibraryView(title: "Keep your favorites close", description: "Tap Save on a video to keep it here.", symbol: "bookmark")
                    } else {
                        EditorialHero(eyebrow: "Your next routine", title: "Every step\nis a new story.", subtitle: "Bring a dance from your camera roll.")
                        VStack(alignment: .leading, spacing: 16) {
                            SectionTitle(title: "Start your collection", detail: "01 / CREATE")
                            Text("Your latest choreography. A freestyle session. A step worth keeping.")
                                .font(.subheadline).foregroundStyle(TetoStyle.muted)
                            importButton.buttonStyle(PrimaryButtonStyle())
                            Text("Up to 250 MB · Up to 3 minutes")
                                .font(.caption).foregroundStyle(TetoStyle.muted).frame(maxWidth: .infinity)
                        }.tetoCard()
                    }
                } else {
                    if !savedOnly, !showSaved, search.isEmpty, let first = videos.first {
                        videoEntry(first, featured: true)
                    }
                    let gridVideos = !savedOnly && !showSaved && search.isEmpty ? Array(videos.dropFirst()) : videos
                    if !gridVideos.isEmpty {
                        SectionTitle(title: savedOnly || showSaved ? "Worth another watch" : "More moves", detail: "YOUR COLLECTION")
                    }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 150), spacing: 14)], spacing: 18) {
                        ForEach(gridVideos) { video in
                            videoEntry(video)
                        }
                    }
                }
                ServiceNote(symbol: "internaldrive", text: embedded
                            ? "Find your groove. Make it your own."
                            : "Your dance collection, all in one place.")
            }.padding(20)
        }
        .freshStudioPage(drawsBackground: !embedded)
            .tetoNavigationTitle(embedded ? "" : (savedOnly ? "Saved videos" : "Your videos"))
        .navigationBarTitleDisplayMode(.inline)
        .scrollDismissesKeyboard(.interactively)
        .danceFeedRefresh(enabled: embedded) { await store.refreshLiveRecommendations() }
        .toolbar {
            if !embedded {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { creating = true } label: {
                        Image(systemName: "plus").frame(minWidth: 44, minHeight: 44)
                    }.accessibilityLabel("Create a short video").disabled(store.isBusy)
                }
            }
        }
        .fullScreenCover(item: $presentedRoom) { config in LiveRoomView(configuration: config) }
        .fullScreenCover(item: $presentedSavedVideo) { video in
            ShortsFeedView(isTabActive: true, isSearching: .constant(false),
                           collectionVideoIDs: [video.id], onClose: { presentedSavedVideo = nil })
                .preferredColorScheme(.dark)
        }
        .sheet(isPresented: $creating) { ShortVideoCreationView() }
    }

    @ViewBuilder private func videoEntry(_ video: LocalVideo, featured: Bool = false) -> some View {
        if savedOnly || showSaved {
            Button { presentedSavedVideo = video } label: {
                VideoCard(video: video, coverURL: store.coverURL(video), featured: featured, showsDuration: !embedded)
            }
            .buttonStyle(.plain).accessibilityHint("Plays the saved video full screen")
        } else if embedded {
            Button {
                presentedRoom = DanceRoomLibrary.room(video: video, videoURL: store.videoURL(video),
                    coverURL: store.coverURL(video), displayName: store.library.profile.displayName)
            } label: { VideoCard(video: video, coverURL: store.coverURL(video), featured: featured, showsDuration: !embedded) }
                .buttonStyle(.plain).accessibilityHint("Opens a dance room")
        } else {
            // Keep the detail above this library, which is itself a view-based destination.
            NavigationLink {
                VideoDetailView(videoID: video.id)
            } label: {
                VideoCard(video: video, coverURL: store.coverURL(video), featured: featured, showsDuration: !embedded)
            }
                .buttonStyle(.plain)
        }
    }

    private var importButton: some View {
        Button { creating = true } label: {
            Label("Create a short video", systemImage: "plus")
        }.disabled(store.isBusy)
    }
}

struct VideoCard: View {
    @EnvironmentObject private var store: AppStore
    let video: LocalVideo
    let coverURL: URL
    var featured = false
    var showsDuration = true
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            LocalVideoCover(url: coverURL)
            LinearGradient(colors: [.black.opacity(0.16), .clear, .black.opacity(0.78)], startPoint: .top, endPoint: .bottom)
            VStack(alignment: .leading, spacing: 8) {
                Text(video.title).font(featured ? TetoTypography.section : TetoTypography.headline).lineLimit(2)
                if showsDuration || video.isSaved {
                    HStack(spacing: 5) {
                        if showsDuration {
                            Image(systemName: "play.fill").font(.caption2)
                            Text(video.durationLabel).monospacedDigit()
                        }
                        Spacer(minLength: 0)
                        if video.isSaved { Image(systemName: "bookmark.fill") }
                    }
                    .font(.caption).foregroundStyle(.white.opacity(0.88))
                }
            }.foregroundStyle(.white).padding(featured ? 22 : 14)
        }
        .frame(height: featured ? 330 : 230)
        .overlay(alignment: .top) {
            HStack(spacing: 8) {
                Text(video.isBundled ? "DANCE" : "YOUR VIDEO").font(.system(size: 9, weight: .bold)).tracking(0.8)
                    .padding(.horizontal, 9).padding(.vertical, 6).foregroundStyle(.white)
                    .background(.black.opacity(0.45), in: Capsule())
                Spacer(minLength: 0)
                if video.isBundled {
                    LiveAvatar(asset: FreshStudioPhotos.creatorAvatar(for: video.creatorID), size: featured ? 38 : 30)
                } else {
                    ProfileAvatar(symbol: store.library.profile.avatarSymbol, size: featured ? 38 : 30)
                }
            }.padding(featured ? 18 : 12)
        }
        .clipShape(RoundedRectangle(cornerRadius: 16))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(video.title), \(video.isBundled ? "dance film" : "your video")\(showsDuration ? ", " + video.durationLabel : "")\(video.isSaved ? ", saved" : "")")
        .accessibilityHint("Opens video details")
    }
}

struct LocalVideoCover: View {
    let url: URL
    @State private var image: UIImage?
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                TetoStyle.emerald.opacity(0.12)
                if let image {
                    Image(uiImage: image).resizable().scaledToFill()
                        .frame(width: geometry.size.width, height: geometry.size.height).clipped()
                } else {
                    Image(systemName: "video").font(.largeTitle).foregroundStyle(TetoStyle.emerald)
                }
            }
        }
        .accessibilityHidden(true)
        .task(id: url) {
            image = nil
            let data = await Task.detached(priority: .utility) { try? Data(contentsOf: url) }.value
            guard !Task.isCancelled else { return }
            if let data { image = UIImage(data: data) }
        }
    }
}
