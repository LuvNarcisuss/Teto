import SwiftUI

struct VideoDetailView: View {
    let videoID: UUID
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @StateObject private var playback = LocalVideoPlayback()
    @State private var showingRename = false
    @State private var confirmingDelete = false
    @State private var showingControls = false
    private var video: LocalVideo? { store.collectionVideos.first { $0.id == videoID } }
    private var canAutoplay: Bool { scenePhase == .active && store.notice == nil }
    // Loading and failure feedback must remain visible even in unobstructed playback.
    private var overlaysVisible: Bool {
        showingControls || playback.isLoading || playback.error != nil || video == nil
    }

    var body: some View {
        ScrollView {
            if let video {
                VStack(alignment: .leading, spacing: 22) {
                    VStack(spacing: 16) {
                        Spacer(minLength: 0)
                        if let error = playback.error {
                            VStack(spacing: 16) {
                                Image(systemName: "exclamationmark.triangle").font(.title)
                                Text(error).multilineTextAlignment(.center)
                                Button("Try again") { playback.prepare(url: store.videoURL(video), autoplay: canAutoplay) }
                                    .buttonStyle(FloatingVideoButtonStyle())
                            }.foregroundStyle(.white).padding(24)
                        } else {
                            if playback.isLoading {
                                ProgressView("Preparing video…").tint(.white).foregroundStyle(.white)
                            } else {
                                Button { playback.togglePlayback() } label: {
                                    Image(systemName: playback.isPlaying ? "pause.fill" : "play.fill")
                                        .font(.system(size: 32, weight: .semibold))
                                        .frame(width: 72, height: 72)
                                        .overlay(Circle().strokeBorder(.white.opacity(0.7), lineWidth: 1))
                                        .shadow(color: .black.opacity(0.6), radius: 8)
                                }
                                .buttonStyle(.plain)
                                .accessibilityLabel(playback.isPlaying ? "Pause video" : "Play video")
                            }
                        }
                        Spacer(minLength: 0)
                        playbackControls(for: video)
                    }
                    .frame(height: 340)
                    .background {
                        if !playback.isLoading && playback.error == nil { toggleControlsButton }
                    }
                    StatusPill(text: video.isBundled ? "DANCE" : "YOUR VIDEO", dark: true)
                    Text(video.title).font(TetoTypography.largeTitle).foregroundStyle(.white)
                    HStack {
                        Label(video.durationLabel, systemImage: "clock")
                        Spacer()
                        if video.isBundled {
                            Text("Dance film · No audio")
                        } else {
                            Text(video.importedAt, format: .dateTime.month(.abbreviated).day().year())
                        }
                    }.font(.footnote).foregroundStyle(.white.opacity(0.85))
                    Button {
                        Task { await store.toggleSaved(video.id) }
                    } label: {
                        Label(video.isSaved ? "Saved" : "Save to favorites",
                              systemImage: video.isSaved ? "bookmark.fill" : "bookmark")
                    }.buttonStyle(FloatingVideoButtonStyle()).disabled(store.isBusy)
                    if let clip = video.bundledClip {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Footage by \(clip.creator) / Pexels").font(TetoTypography.headline)
                            Text("A dance film shared under the Pexels License.")
                                .font(.subheadline).foregroundStyle(.white.opacity(0.85))
                            Link("View original video", destination: clip.sourceURL)
                                .frame(minHeight: 44)
                            Link("Pexels License", destination: URL(string: "https://www.pexels.com/license/")!)
                                .frame(minHeight: 44)
                        }.padding(18)
                            .overlay(RoundedRectangle(cornerRadius: 24).strokeBorder(.white.opacity(0.3), lineWidth: 0.75))
                    } else {
                        if video.isDance != true {
                            Button("Add to dance feed") { Task { await store.markAsDance(video.id) } }
                                .buttonStyle(FloatingVideoButtonStyle()).disabled(store.isBusy)
                        }
                        Label("Private video · Only you", systemImage: "lock")
                            .font(.caption).foregroundStyle(.white.opacity(0.85))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 4).padding(.vertical, 8)
                        Button("Rename video") { playback.pause(); showingRename = true }.buttonStyle(FloatingVideoButtonStyle())
                        Button("Remove video", role: .destructive) {
                            playback.pause()
                            confirmingDelete = true
                        }.buttonStyle(FloatingVideoButtonStyle(destructive: true, height: 44))
                    }
                }.padding(20)
            } else {
                VStack(spacing: 14) {
                    Image(systemName: "video.slash").font(.largeTitle)
                    Text("Video removed").font(TetoTypography.subsection)
                    Text("This video is no longer in your collection.").font(.subheadline)
                }.padding(24).frame(maxWidth: .infinity)
            }
        }
        .scrollDisabled(!overlaysVisible)
        .opacity(overlaysVisible ? 1 : 0)
        .allowsHitTesting(overlaysVisible)
        .accessibilityHidden(!overlaysVisible)
        .overlay {
            if !overlaysVisible { toggleControlsButton }
        }
        .foregroundStyle(.white)
        .background {
            GeometryReader { geometry in
                ZStack {
                    Color.black
                    if let video { LocalVideoCover(url: store.coverURL(video)) }
                    if playback.player != nil { VideoPlaybackSurface(player: playback.player) }
                    LinearGradient(colors: [.black.opacity(0.35), .black.opacity(overlaysVisible ? 0.1 : 0), .black.opacity(overlaysVisible ? 0.8 : 0.2)], startPoint: .top, endPoint: .bottom)
                }
                .frame(width: geometry.size.width, height: geometry.size.height).clipped()
            }
            .ignoresSafeArea(.container)
            .allowsHitTesting(false)
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.18), value: overlaysVisible)
        .tetoNavigationTitle("Your moment").navigationBarTitleDisplayMode(.inline)
        .toolbarBackground(.hidden, for: .navigationBar, .tabBar)
        .toolbarColorScheme(.dark, for: .navigationBar, .tabBar)
        .tint(.white)
        .task(id: videoID) {
            showingControls = false
            if let video { playback.prepare(url: store.videoURL(video), autoplay: canAutoplay) }
        }
        .onDisappear { playback.stop() }
        .onChange(of: scenePhase) { _, phase in if phase != .active { playback.pause() } }
        .onChange(of: store.notice?.id) { _, id in if id != nil { playback.pause() } }
        .sheet(isPresented: $showingRename) {
            if let video { RenameVideoView(video: video).foregroundStyle(TetoStyle.ink).tint(TetoStyle.emerald) }
        }
        .confirmationDialog("Remove this video?", isPresented: $confirmingDelete, titleVisibility: .visible) {
            Button("Remove video", role: .destructive) {
                Task {
                    playback.stop()
                    if await store.deleteVideo(videoID) { dismiss() }
                    else if let video { playback.prepare(url: store.videoURL(video), autoplay: canAutoplay) }
                }
            }
        } message: { Text("The video and its favorite status will be removed from Teto. Your original in Photos will be kept.") }
    }

    private var toggleControlsButton: some View {
        Button { showingControls.toggle() } label: {
            Color.clear
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .accessibilityLabel(showingControls ? "Hide video controls" : "Show video controls")
        .accessibilityHint("Toggles playback controls and video information without pausing the video.")
    }

    private func playbackControls(for video: LocalVideo) -> some View {
        HStack(spacing: 12) {
            Button { playback.togglePlayback() } label: {
                Image(systemName: playback.isPlaying ? "pause.fill" : "play.fill").frame(width: 44, height: 44)
            }.accessibilityLabel(playback.isPlaying ? "Pause video" : "Play video")
            Spacer(minLength: 0)
            if !video.isBundled {
                Button { playback.toggleMuted() } label: {
                    Image(systemName: playback.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill").frame(width: 44, height: 44)
                }.accessibilityLabel(playback.isMuted ? "Unmute video" : "Mute video")
            }
        }
        .buttonStyle(.plain).tint(.white)
        .disabled(playback.isLoading || playback.error != nil)
    }
}

private struct FloatingVideoButtonStyle: ButtonStyle {
    var destructive = false
    var height: CGFloat = 50
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.font(.headline)
            .frame(maxWidth: .infinity, minHeight: height)
            .foregroundStyle(destructive ? Color(red: 1, green: 0.55, blue: 0.5) : .white)
            .background(TetoStyle.night.opacity(0.32), in: Capsule())
            .overlay(Capsule().strokeBorder(.white.opacity(0.3), lineWidth: 0.75))
            .contentShape(RoundedRectangle(cornerRadius: 18))
            .shadow(color: .black.opacity(0.5), radius: 4)
            .opacity(configuration.isPressed ? 0.6 : 1)
    }
}

private struct RenameVideoView: View {
    let video: LocalVideo
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var title: String
    @State private var failure: String?
    @State private var confirmingDiscard = false
    @FocusState private var isFocused: Bool

    init(video: LocalVideo) {
        self.video = video
        _title = State(initialValue: video.title)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Video title") {
                    TextField("Title", text: $title, axis: .vertical).focused($isFocused)
                    Text("\(title.count)/80 characters").font(.caption).foregroundStyle(.secondary)
                    FormError(message: failure)
                }
            }
            .disabled(store.isBusy)
            .freshStudioPage().tetoNavigationTitle("Rename video").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if title != video.title { confirmingDiscard = true } else { dismiss() } }.disabled(store.isBusy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.isBusy ? "Saving…" : "Save") {
                        isFocused = false
                        Task {
                            if await store.renameVideo(video.id, title: title) { dismiss() }
                            else { failure = store.lastSaveError ?? "Enter a title of up to 80 characters." }
                        }
                    }.disabled(store.isBusy || title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || title.count > 80)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .interactiveDismissDisabled(store.isBusy || title != video.title)
            .confirmationDialog("Discard unsaved changes?", isPresented: $confirmingDiscard, titleVisibility: .visible) {
                Button("Discard changes", role: .destructive) { dismiss() }
            }
        }
    }
}
