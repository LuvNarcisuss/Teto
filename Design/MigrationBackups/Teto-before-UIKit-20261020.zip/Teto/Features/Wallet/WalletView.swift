import SwiftUI

struct WalletView: View {
    @ObservedObject var wallet: WalletStore
    private let currency: WalletCurrency = .diamonds
    @State private var selectedAmount = 400
    @State private var confirming = false
    @State private var error: String?
    @Environment(\.dynamicTypeSize) private var typeSize
    private var packages: [WalletPackage] { WalletCatalog.packages(for: currency) }
    private var selected: WalletPackage { packages.first { $0.amount == selectedAmount } ?? packages[0] }
    private var columns: [GridItem] { Array(repeating: GridItem(.flexible(), spacing: 10), count: typeSize.isAccessibilitySize ? 2 : 3) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 12) {
                balanceCard
                VStack(alignment: .leading, spacing: 14) {
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(packages) { package in
                            Button { selectedAmount = package.amount; error = nil } label: {
                                VStack(spacing: 6) {
                                    CurrencyArtwork(currency: currency, size: 42)
                                    Text(package.amountText).font(TetoTypography.headline).monospacedDigit()
                                    Text(package.price).font(.caption).foregroundStyle(TetoStyle.muted)
                                }.frame(maxWidth: .infinity).padding(.vertical, 14).padding(.horizontal, 4)
                                    .background(package.amount == selectedAmount ? TetoStyle.lime.opacity(0.4) : .white, in: RoundedRectangle(cornerRadius: 16))
                                    .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(package.amount == selectedAmount ? TetoStyle.emerald : TetoStyle.line, lineWidth: package.amount == selectedAmount ? 2 : 1))
                                    .overlay(alignment: .topTrailing) {
                                        if package.amount == selectedAmount {
                                            Image(systemName: "checkmark.circle.fill").foregroundStyle(TetoStyle.emerald).padding(7).accessibilityHidden(true)
                                        }
                                    }
                            }.buttonStyle(.plain)
                                .accessibilityLabel("\(package.amountText) \(currency.rawValue), \(package.price) USD")
                                .accessibilityAddTraits(package.amount == selectedAmount ? .isSelected : [])
                        }
                    }
                }
                Text("Prices in USD · Purchases unavailable")
                    .font(.footnote).foregroundStyle(TetoStyle.muted)
                VStack(alignment: .leading, spacing: 10) {
                    Text("How diamonds work").font(TetoTypography.headline)
                    Label("Use diamonds to send gifts and support dancers in Live.", systemImage: "gift")
                    Label("Chats and floating comments are free. No diamonds are used.", systemImage: "bubble.left.and.bubble.right")
                }
                .font(.subheadline).foregroundStyle(TetoStyle.ink)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding(16).background(TetoStyle.lime.opacity(0.22), in: RoundedRectangle(cornerRadius: 16))
            }.frame(maxWidth: 560).padding(.horizontal, 16).padding(.vertical, 12).frame(maxWidth: .infinity)
        }
        .foregroundStyle(TetoStyle.ink)
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(alignment: .leading, spacing: 10) {
                FormError(message: error)
                Button(wallet.isBusy ? "Please wait…" : "Recharge \(selected.price)") { confirming = true }
                    .buttonStyle(PrimaryButtonStyle()).disabled(wallet.isBusy)
            }.padding(20).background(TetoStyle.chromeGradient)
        }
        .freshStudioPage()
            .tetoNavigationTitle("Wallet").navigationBarTitleDisplayMode(.inline)
        .toolbar(.hidden, for: .tabBar)
        .toolbar(.visible, for: .navigationBar)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                NavigationLink { WalletHistoryView(wallet: wallet) } label: {
                    Image(systemName: "clock.arrow.circlepath").frame(width: 44, height: 44)
                }.accessibilityLabel("Transaction history")
            }
        }
        .confirmationDialog("Recharge \(selected.amountText) \(currency.rawValue)?", isPresented: $confirming, titleVisibility: .visible) {
            Button("Continue · \(selected.price) USD") {
                let package = selected
                Task { error = await wallet.purchase(package) }
            }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Purchases are unavailable. You will not be charged.") }
        .preferredColorScheme(.light).tint(TetoStyle.emerald)
    }

    private var balanceCard: some View {
        VStack(spacing: 12) {
            Label("Diamonds", systemImage: "diamond.fill")
                .font(.subheadline.weight(.semibold)).foregroundStyle(.white)
                .padding(.horizontal, 24).frame(minHeight: 44)
                .background(TetoStyle.accentGradient, in: Capsule()).padding(.bottom, 12)
            Text("Your balance").font(.subheadline).foregroundStyle(TetoStyle.muted)
            HStack(spacing: 12) {
                CurrencyArtwork(currency: currency, size: 46)
                Text(wallet.snapshot.balance(currency), format: .number)
                    .font(TetoTypography.largeTitle).monospacedDigit()
            }
        }.frame(maxWidth: .infinity).padding(.horizontal, 20).padding(.vertical, 20)
            .background { FreshStudioBackdrop() }
            .accessibilityElement(children: .combine)
    }
}
