import Foundation

enum WalletCurrency: String, CaseIterable, Identifiable {
    case diamonds = "Diamonds"
    var id: String { rawValue }
    var symbol: String { "diamond.fill" }
}

struct WalletPackage: Identifiable {
    let currency: WalletCurrency
    let amount: Int
    let usdCents: Int
    // Catalog identifier; availability must be resolved through the purchase service.
    let storeProductID: String
    var id: String { "\(currency.id)-\(amount)" }
    var price: String { String(format: "$%d.%02d", usdCents / 100, usdCents % 100) }
    var amountText: String { amount.formatted(.number.locale(Locale(identifier: "en_US"))) }
}

enum WalletCatalog {
    // Seven IDs supplied by the user, plus two proposed IDs requiring store registration.
    // USD amounts are catalog references, not localized StoreKit prices.
    private static let diamondTiers: [(amount: Int, usdCents: Int, productID: String)] = [
        (400, 99, "hoewtkchclzkuruf"),
        (800, 199, "qbfuucwaccetjljs"),
        (2_450, 499, "mdnrsibqccschjcg"),
        (5_150, 999, "olfouxazhsdntxzs"),
        (10_800, 1_999, "ejtvapyfnomaimlf"),
        (16_800, 2_999, "qlrpflukqugckska"),
        (29_400, 4_999, "uficsdpshzadegnz"),
        (42_600, 6_999, "zhkxxppfqwqfwhcp"),
        (63_700, 9_999, "cbhpozbwbvfwgqxp")
    ]

    static func packages(for currency: WalletCurrency) -> [WalletPackage] {
        diamondTiers.map { tier in
            WalletPackage(currency: currency, amount: tier.amount,
                          usdCents: tier.usdCents, storeProductID: tier.productID)
        }
    }
}

struct DanceGift: Identifiable {
    let id: String
    let name: String
    let symbol: String
    let diamonds: Int
    let hue: Double

    static let catalog: [Self] = [
        .init(id: "rose", name: "Rose", symbol: "camera.macro", diamonds: 10, hue: 0.96),
        .init(id: "balloons", name: "Balloons", symbol: "balloon.2.fill", diamonds: 50, hue: 0.54),
        .init(id: "heart", name: "Heart", symbol: "heart.fill", diamonds: 100, hue: 0.94),
        .init(id: "beat", name: "Beat Drop", symbol: "music.note", diamonds: 200, hue: 0.72),
        .init(id: "spotlight", name: "Spotlight", symbol: "sparkles", diamonds: 500, hue: 0.12),
        .init(id: "bouquet", name: "Bouquet", symbol: "camera.macro", diamonds: 1_000, hue: 0.88),
        .init(id: "crown", name: "Dance Crown", symbol: "crown.fill", diamonds: 2_000, hue: 0.10),
        .init(id: "encore", name: "Encore", symbol: "party.popper.fill", diamonds: 5_000, hue: 0.04),
        .init(id: "galaxy", name: "Dance Galaxy", symbol: "moon.stars.fill", diamonds: 10_000, hue: 0.67)
    ]
}

struct WalletActivity: Identifiable {
    let id: String
    let title: String
    let currency: WalletCurrency
    let amount: Int
    let date: Date
}

struct WalletSnapshot {
    var diamonds = 0
    var activity: [WalletActivity] = []
    func balance(_ currency: WalletCurrency) -> Int { diamonds }
}
