import Combine
import Foundation

@MainActor
protocol WalletServicing {
    // A production implementation must return only verified, authoritative balances.
    func purchase(_ package: WalletPackage) async throws -> WalletSnapshot
    func send(_ gift: DanceGift, quantity: Int, roomID: String) async throws -> WalletSnapshot
}

private enum WalletServiceError: LocalizedError {
    case purchasesUnavailable, giftsUnavailable
    var errorDescription: String? {
        switch self {
        case .purchasesUnavailable: return "Purchase unavailable. You have not been charged."
        case .giftsUnavailable: return "Gift not sent. No diamonds were spent."
        }
    }
}

private struct UnconnectedWalletService: WalletServicing {
    func purchase(_ package: WalletPackage) async throws -> WalletSnapshot { throw WalletServiceError.purchasesUnavailable }
    func send(_ gift: DanceGift, quantity: Int, roomID: String) async throws -> WalletSnapshot { throw WalletServiceError.giftsUnavailable }
}

@MainActor
final class WalletStore: ObservableObject {
    @Published private(set) var snapshot = WalletSnapshot()
    @Published private(set) var isBusy = false
    private let service: any WalletServicing

    init(service: (any WalletServicing)? = nil) { self.service = service ?? UnconnectedWalletService() }

    func clearAccountMemory() { snapshot = WalletSnapshot() }

    func purchase(_ package: WalletPackage) async -> String? {
        guard !isBusy else { return "Please wait for the current request to finish." }
        isBusy = true
        defer { isBusy = false }
        do { snapshot = try await service.purchase(package); return nil }
        catch { return error.localizedDescription }
    }

    func send(_ gift: DanceGift, quantity: Int, roomID: String) async -> String? {
        guard !isBusy, (1...99).contains(quantity) else { return "Please check the quantity and try again." }
        isBusy = true
        defer { isBusy = false }
        do { snapshot = try await service.send(gift, quantity: quantity, roomID: roomID); return nil }
        catch { return error.localizedDescription }
    }
}
