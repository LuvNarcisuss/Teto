import SwiftUI

struct GiftSheetView: View {
    @ObservedObject var wallet: WalletStore
    let roomID: String
    @State private var selectedID = DanceGift.catalog[0].id
    @State private var quantity = 1
    @State private var showingWallet = false
    @State private var confirming = false
    @State private var error: String?
    @Environment(\.dynamicTypeSize) private var typeSize
    private var selected: DanceGift { DanceGift.catalog.first { $0.id == selectedID } ?? DanceGift.catalog[0] }
    private var total: Int { selected.diamonds * quantity }
    private var columns: [GridItem] { Array(repeating: GridItem(.flexible(), spacing: 10), count: typeSize.isAccessibilitySize ? 2 : 3) }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 12) {
                    CurrencyArtwork(currency: .diamonds, size: 38)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Diamonds").font(.caption).foregroundStyle(TetoStyle.muted)
                        Text(wallet.snapshot.diamonds, format: .number).font(TetoTypography.subsection).monospacedDigit()
                    }
                    Spacer()
                    Button { showingWallet = true } label: {
                        Label("Recharge", systemImage: "plus").font(.subheadline.weight(.semibold))
                            .padding(.horizontal, 14).frame(minHeight: 44).background(TetoStyle.lime, in: Capsule())
                    }.buttonStyle(.plain)
                }
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(DanceGift.catalog) { gift in
                        Button { selectedID = gift.id; error = nil } label: {
                            VStack(spacing: 10) {
                                GiftArtwork(gift: gift)
                                Text(gift.name).font(.subheadline.weight(.semibold)).multilineTextAlignment(.center)
                                Label(gift.diamonds.formatted(), systemImage: "diamond.fill")
                                    .font(.caption.weight(.medium)).foregroundStyle(TetoStyle.emerald)
                            }.frame(maxWidth: .infinity).padding(.vertical, 16).padding(.horizontal, 4)
                                .background(selectedID == gift.id ? TetoStyle.lime.opacity(0.4) : TetoStyle.card, in: RoundedRectangle(cornerRadius: 16))
                                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(selectedID == gift.id ? TetoStyle.emerald : TetoStyle.line, lineWidth: selectedID == gift.id ? 2 : 1))
                                .overlay(alignment: .topTrailing) {
                                    if selectedID == gift.id { Image(systemName: "checkmark.circle.fill").foregroundStyle(TetoStyle.emerald).padding(6).accessibilityHidden(true) }
                                }
                        }.buttonStyle(.plain)
                            .accessibilityLabel("\(gift.name), \(gift.diamonds) diamonds")
                            .accessibilityAddTraits(selectedID == gift.id ? .isSelected : [])
                    }
                }
                Text("Gifting is unavailable.").font(.footnote).foregroundStyle(TetoStyle.muted)
            }.padding(20)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            VStack(alignment: .leading, spacing: 12) {
                Stepper("Quantity: \(quantity)", value: $quantity, in: 1...99).font(.subheadline)
                HStack(alignment: .firstTextBaseline) {
                    Text("Total").foregroundStyle(TetoStyle.muted)
                    Spacer()
                    Label(total.formatted(), systemImage: "diamond.fill").font(.headline)
                }
                if total > wallet.snapshot.diamonds {
                    Button("Get more diamonds") { showingWallet = true }
                        .font(.subheadline.weight(.medium)).frame(minHeight: 44)
                }
                FormError(message: error)
                Button(wallet.isBusy ? "Please wait…" : "Send \(selected.name)") { confirming = true }
                    .buttonStyle(PrimaryButtonStyle()).disabled(wallet.isBusy)
            }.padding(20).background(TetoStyle.card)
        }
        .background { FreshStudioPageBackground() }.foregroundStyle(TetoStyle.ink)
        .tint(TetoStyle.emerald).preferredColorScheme(.light)
        .disabled(wallet.isBusy)
        .onChange(of: quantity) { _, _ in error = nil }
        .confirmationDialog("Send \(quantity) × \(selected.name)?", isPresented: $confirming, titleVisibility: .visible) {
            Button("Send · \(total.formatted()) diamonds") {
                let gift = selected
                let count = quantity
                Task { error = await wallet.send(gift, quantity: count, roomID: roomID) }
            }
            Button("Cancel", role: .cancel) {}
        } message: { Text("Gifting is unavailable. No diamonds will be spent.") }
        .sheet(isPresented: $showingWallet) {
            NavigationStack {
                WalletView(wallet: wallet)
                    .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { showingWallet = false } } }
            }.preferredColorScheme(.light).presentationDetents([.large])
        }
    }
}
