import SwiftUI

struct CurrencyArtwork: View {
    let currency: WalletCurrency
    var size: CGFloat = 40
    var body: some View {
        Canvas { context, dimensions in
            let w = dimensions.width
            let h = dimensions.height
            let topLeft = CGPoint(x: w * 0.22, y: h * 0.18)
            let topRight = CGPoint(x: w * 0.78, y: h * 0.18)
            let left = CGPoint(x: w * 0.04, y: h * 0.40)
            let right = CGPoint(x: w * 0.96, y: h * 0.40)
            let innerLeft = CGPoint(x: w * 0.34, y: h * 0.40)
            let innerRight = CGPoint(x: w * 0.66, y: h * 0.40)
            let top = CGPoint(x: w * 0.5, y: h * 0.18)
            let bottom = CGPoint(x: w * 0.5, y: h * 0.92)
            let facets: [([CGPoint], Color)] = [
                ([topLeft, top, innerLeft, left], Color(red: 0.20, green: 0.9, blue: 0.66)),
                ([top, topRight, innerRight, innerLeft], Color(red: 0.65, green: 1, blue: 0.81)),
                ([topRight, right, innerRight], TetoStyle.emerald),
                ([left, innerLeft, bottom], Color(red: 0.03, green: 0.59, blue: 0.42)),
                ([innerLeft, innerRight, bottom], Color(red: 0.14, green: 0.87, blue: 0.62)),
                ([innerRight, right, bottom], Color(red: 0.02, green: 0.40, blue: 0.30))
            ]
            for (points, color) in facets {
                var path = Path()
                path.addLines(points)
                path.closeSubpath()
                context.fill(path, with: .color(color))
                context.stroke(path, with: .color(.white.opacity(0.45)), lineWidth: 0.5)
            }
        }.frame(width: size, height: size).accessibilityHidden(true)
    }
}

struct GiftArtwork: View {
    let gift: DanceGift
    var body: some View {
        ZStack {
            if gift.id == "rose" {
                ZStack {
                    Capsule().fill(Color.green).frame(width: 3, height: 28).offset(y: 15)
                    Ellipse().fill(Color.green).frame(width: 18, height: 9).rotationEffect(.degrees(-30)).offset(x: 8, y: 15)
                    Image(systemName: "camera.macro").font(.system(size: 40, weight: .bold))
                        .foregroundStyle(LinearGradient(colors: [.pink, .red], startPoint: .topLeading, endPoint: .bottomTrailing)).offset(y: -8)
                }
            } else if gift.id == "bouquet" {
                HStack(spacing: -13) {
                    flower.rotationEffect(.degrees(-20)).offset(y: 6)
                    flower.offset(y: -5)
                    flower.rotationEffect(.degrees(20)).offset(y: 6)
                }.padding(12)
            } else {
                Image(systemName: gift.symbol).font(.system(size: 35, weight: .medium))
                    .foregroundStyle(LinearGradient(colors: [Color(hue: gift.hue, saturation: 0.3, brightness: 1), Color(hue: gift.hue, saturation: 0.85, brightness: 0.9)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .shadow(color: Color(hue: gift.hue, saturation: 0.8, brightness: 1).opacity(0.3), radius: 8, y: 4)
            }
        }.frame(width: 64, height: 64).accessibilityHidden(true)
    }
    private var flower: some View {
        Image(systemName: "camera.macro").font(.system(size: 25)).foregroundStyle(.pink.gradient)
    }
}

struct WalletHistoryView: View {
    @ObservedObject var wallet: WalletStore
    var body: some View {
        List(wallet.snapshot.activity) { entry in
            HStack(spacing: 12) {
                CurrencyArtwork(currency: entry.currency)
                VStack(alignment: .leading, spacing: 6) {
                    Text(entry.title).font(TetoTypography.headline)
                    Text(entry.date, format: .dateTime.month().day().hour().minute()).font(.caption).foregroundStyle(TetoStyle.muted)
                }
                Spacer()
                Text(entry.amount, format: .number).monospacedDigit()
            }
        }
        .overlay {
            if wallet.snapshot.activity.isEmpty {
                ContentUnavailableView("No transactions yet", systemImage: "clock.arrow.circlepath", description: Text("Completed wallet activity will appear here."))
            }
        }
        .freshStudioPage()
            .tetoNavigationTitle("Transactions").navigationBarTitleDisplayMode(.inline)
            .toolbar(.hidden, for: .tabBar)
    }
}
