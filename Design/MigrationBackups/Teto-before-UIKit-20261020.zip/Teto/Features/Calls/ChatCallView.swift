import AVFoundation
import SwiftUI

/// These controls do not initiate calls or request microphone access.
enum ChatCallKind: String, Identifiable {
    case voice, video
    var id: String { rawValue }
    var title: String { self == .voice ? "Voice call" : "Video call" }
}

struct ChatCallButtons: View {
    let open: (ChatCallKind) -> Void
    var body: some View {
        HStack(spacing: 4) {
            Button { open(.voice) } label: { Image(systemName: "phone").frame(width: 44, height: 44) }
                .accessibilityLabel("Voice call")
            Button { open(.video) } label: { Image(systemName: "video").frame(width: 44, height: 44) }
                .accessibilityLabel("Video call")
        }
    }
}

@MainActor
struct ChatCallView: View {
    let kind: ChatCallKind
    let conversation: DanceConversation
    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.openURL) private var openURL
    @StateObject private var camera = CallCameraController()
    @State private var visible = false
    @State private var microphoneEnabled = true
    @State private var speakerEnabled = false
    @Environment(\.verticalSizeClass) private var verticalSizeClass
    init(kind: ChatCallKind, conversation: DanceConversation) {
        self.kind = kind
        self.conversation = conversation
        _speakerEnabled = State(initialValue: kind == .video)
    }

    private var cameraActive: Bool { visible && kind == .video && scenePhase == .active }

    var body: some View {
        ZStack {
            background.ignoresSafeArea()
            if kind == .video {
                CallCameraView(session: camera.session, frontFacing: camera.frontFacing)
                    .ignoresSafeArea().opacity(camera.state == .ready && cameraActive ? 1 : 0)
                    .accessibilityHidden(true)
                LinearGradient(colors: [.black.opacity(0.42), .clear, .black.opacity(0.36)], startPoint: .top, endPoint: .bottom)
                    .ignoresSafeArea().allowsHitTesting(false)
            }
            VStack(spacing: 0) {
                header
                ScrollView {
                    VStack(spacing: 24) {
                        if kind == .voice {
                            ChatAvatar(conversation: conversation, size: verticalSizeClass == .compact ? 96 : 144)
                                .overlay(Circle().strokeBorder(.white.opacity(0.25), lineWidth: 1))
                            Text(conversation.name).font(TetoTypography.title)
                                .multilineTextAlignment(.center)
                        } else if camera.state != .ready {
                            cameraStatus
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.horizontal, 24)
                    .padding(.top, verticalSizeClass == .compact ? 16 : 64)
                    .padding(.bottom, 24)
                }
                Spacer(minLength: 8)
                controls
            }
        }
        .foregroundStyle(.white).preferredColorScheme(.dark)
        .interactiveDismissDisabled()
        .onAppear { visible = true }
        .onChange(of: cameraActive) { _, active in
            if active { camera.start() } else { camera.stop() }
        }
        .onDisappear { visible = false; camera.stop() }
        .onReceive(NotificationCenter.default.publisher(for: AVCaptureSession.wasInterruptedNotification, object: camera.session).receive(on: DispatchQueue.main)) { _ in
            camera.interrupted()
        }
        .onReceive(NotificationCenter.default.publisher(for: AVCaptureSession.interruptionEndedNotification, object: camera.session).receive(on: DispatchQueue.main)) { _ in
            if cameraActive { camera.interruptionEnded() }
        }
        .onReceive(NotificationCenter.default.publisher(for: AVCaptureSession.runtimeErrorNotification, object: camera.session).receive(on: DispatchQueue.main)) { _ in
            camera.failed()
        }
    }

    private var background: some View { FreshStudioImmersiveBackdrop() }

    private var header: some View {
        HStack(alignment: .top, spacing: 12) {
            Button(action: endCall) {
                Image(systemName: "chevron.down").font(.title3.weight(.semibold))
                    .frame(width: 44, height: 44).background(.white.opacity(0.14), in: Circle())
            }.accessibilityLabel("Back to chat")
            VStack(alignment: .leading, spacing: 4) {
                Text(kind.title).font(TetoTypography.headline)
                if kind == .video {
                    Text(conversation.name).font(.subheadline).lineLimit(2)
                }
            }.frame(maxWidth: .infinity, alignment: .leading)
            if kind == .video {
                Button { camera.flip() } label: {
                    Image(systemName: "arrow.triangle.2.circlepath.camera").font(.title2)
                        .frame(width: 44, height: 44).background(.white.opacity(0.14), in: Circle())
                }
                .disabled(camera.state != .ready)
                .opacity(camera.state == .ready ? 1 : 0.5)
                .accessibilityLabel("Flip camera")
                .accessibilityValue(camera.frontFacing ? "Front camera" : "Back camera")
            }
        }.buttonStyle(.plain).padding(.horizontal, 16).padding(.top, 8)
    }

    private var controls: some View {
        HStack(alignment: .top, spacing: 16) {
            callButton(title: microphoneEnabled ? "Microphone" : "Muted", symbol: microphoneEnabled ? "mic" : "mic.slash", selected: microphoneEnabled) {
                microphoneEnabled.toggle()
            }.accessibilityValue(microphoneEnabled ? "On" : "Off")
            callButton(title: "End", symbol: "phone.down.fill", destructive: true, action: endCall)
                .accessibilityLabel("End call and return to chat")
            callButton(title: "Speaker", symbol: speakerEnabled ? "speaker.wave.2" : "speaker.slash", selected: speakerEnabled) {
                speakerEnabled.toggle()
            }.accessibilityValue(speakerEnabled ? "On" : "Off")
        }.frame(maxWidth: 440).padding(.horizontal, 24).padding(.top, 16).padding(.bottom, 12)
    }

    private func callButton(title: String, symbol: String, selected: Bool = false, destructive: Bool = false,
                            action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: symbol).font(.system(size: 28, weight: .medium))
                    .frame(width: 64, height: 64)
                    .foregroundStyle(selected ? TetoStyle.ink : .white)
                    .background(destructive ? Color(red: 1, green: 0.16, blue: 0.32) : (selected ? .white : .white.opacity(0.16)),
                                in: Circle())
                Text(title).font(.caption).multilineTextAlignment(.center)
            }.frame(maxWidth: .infinity).contentShape(Rectangle())
        }.buttonStyle(.plain)
    }

    @ViewBuilder private var cameraStatus: some View {
        if camera.state == .loading || camera.state == .idle {
            ProgressView("Opening camera…").tint(.white)
        } else {
            Image(systemName: "video.slash").font(.largeTitle)
            Text(cameraMessage).font(TetoTypography.headline).multilineTextAlignment(.center)
            if camera.state == .denied {
                Button("Open Settings") {
                    if let url = URL(string: UIApplication.openSettingsURLString) { openURL(url) }
                }.buttonStyle(.bordered).tint(.white).frame(minHeight: 44)
            } else if camera.state == .failed || camera.state == .interrupted {
                Button("Try again") { if cameraActive { camera.start() } }
                    .buttonStyle(.bordered).tint(.white).frame(minHeight: 44)
            }
        }
    }

    private var cameraMessage: String {
        switch camera.state {
        case .denied: return "Allow camera access in Settings to see your camera here."
        case .restricted: return "Camera access is restricted on this device."
        case .unavailable: return "This camera is not available on this device."
        case .interrupted: return "Camera paused. It may be in use by another app."
        default: return "The camera could not start. Please try again."
        }
    }

    private func endCall() { visible = false; camera.stop(); dismiss() }
}
