import AVFoundation
import SwiftUI
import UIKit

struct CallCameraView: UIViewRepresentable {
    let session: AVCaptureSession
    let frontFacing: Bool

    func makeUIView(context: Context) -> CallCameraSurface {
        let view = CallCameraSurface()
        view.cameraLayer.videoGravity = .resizeAspectFill
        view.cameraLayer.session = session
        view.frontFacing = frontFacing
        return view
    }

    func updateUIView(_ view: CallCameraSurface, context: Context) {
        view.frontFacing = frontFacing
        view.setNeedsLayout()
    }

    static func dismantleUIView(_ view: CallCameraSurface, coordinator: ()) {
        view.cameraLayer.session = nil
    }
}

final class CallCameraSurface: UIView {
    override class var layerClass: AnyClass { AVCaptureVideoPreviewLayer.self }
    var cameraLayer: AVCaptureVideoPreviewLayer { layer as! AVCaptureVideoPreviewLayer }
    var frontFacing = true

    override func layoutSubviews() {
        super.layoutSubviews()
        guard let connection = cameraLayer.connection else { return }
        let angle: CGFloat
        switch window?.windowScene?.interfaceOrientation {
        case .landscapeLeft: angle = 0
        case .landscapeRight: angle = 180
        case .portraitUpsideDown: angle = 270
        default: angle = 90
        }
        if connection.isVideoRotationAngleSupported(angle) { connection.videoRotationAngle = angle }
        if connection.isVideoMirroringSupported {
            connection.automaticallyAdjustsVideoMirroring = false
            connection.isVideoMirrored = frontFacing
        }
    }
}
