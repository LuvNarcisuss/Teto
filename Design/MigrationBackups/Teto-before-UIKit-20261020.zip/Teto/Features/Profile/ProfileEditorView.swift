import SwiftUI

struct ProfileEditorView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var profile: LocalProfile
    @State private var failure: String?
    @State private var confirmingDiscard = false
    @FocusState private var focused: Bool
    private let original: LocalProfile
    private let symbols = ["person.fill", "leaf.fill", "sun.max.fill", "moon.stars.fill", "camera.fill", "music.note"]

    init(profile: LocalProfile) {
        original = profile
        _profile = State(initialValue: profile)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Your avatar") {
                    HStack { Spacer(); ProfileAvatar(symbol: profile.avatarSymbol); Spacer() }
                        .listRowBackground(Color.clear)
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 48))], spacing: 12) {
                        ForEach(symbols, id: \.self) { symbol in
                            Button { profile.avatarSymbol = symbol } label: {
                                Image(systemName: symbol).font(.title3).frame(width: 48, height: 48)
                                    .foregroundStyle(TetoStyle.emerald)
                                    .background(profile.avatarSymbol == symbol ? TetoStyle.lime : Color.clear, in: Circle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(avatarLabel(symbol))
                            .accessibilityAddTraits(profile.avatarSymbol == symbol ? .isSelected : [])
                        }
                    }
                }
                Section("Profile") {
                    TextField("Name", text: $profile.displayName).focused($focused)
                    Text("\(profile.displayName.count)/30 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                    TextField("A little about you", text: $profile.biography, axis: .vertical)
                        .lineLimit(3...6).focused($focused)
                    Text("\(profile.biography.count)/160 characters").font(.caption).foregroundStyle(TetoStyle.muted)
                    FormError(message: failure)
                }
            }
            .disabled(store.isBusy)
            .scrollContentBackground(.hidden)
            .freshStudioPage()
            .tetoNavigationTitle("Edit profile").navigationBarTitleDisplayMode(.inline)
            .scrollDismissesKeyboard(.interactively)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { if profile != original { confirmingDiscard = true } else { dismiss() } }.disabled(store.isBusy)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(store.isBusy ? "Saving…" : "Save") {
                        focused = false
                        Task {
                            if await store.saveProfile(profile) { dismiss() }
                            else { failure = store.lastSaveError ?? "Check your name and biography." }
                        }
                    }.disabled(store.isBusy || profile.displayName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || profile.displayName.count > 30 || profile.biography.count > 160)
                }
                ToolbarItemGroup(placement: .keyboard) { Spacer(); Button("Done") { focused = false } }
            }
            .interactiveDismissDisabled(store.isBusy || profile != original)
            .confirmationDialog("Discard unsaved changes?", isPresented: $confirmingDiscard, titleVisibility: .visible) {
                Button("Discard changes", role: .destructive) { dismiss() }
            }
        }
    }

    private func avatarLabel(_ symbol: String) -> String {
        switch symbol {
        case "leaf.fill": return "Leaf avatar"
        case "sun.max.fill": return "Sun avatar"
        case "moon.stars.fill": return "Moon avatar"
        case "camera.fill": return "Camera avatar"
        case "music.note": return "Music avatar"
        default: return "Person avatar"
        }
    }
}
