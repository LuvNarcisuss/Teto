import SwiftUI

struct ProfileSettingsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var agreementDocument: AgreementDocument?
    @State private var showingBlockedCreators = false
    @State private var showingAbout = false
    @State private var confirmingLogout = false
    @State private var confirmingDeletion = false
    @State private var actionError: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Privacy and community") {
                    Button { showingBlockedCreators = true } label: {
                        settingsRow("Blocked creators", symbol: "person.crop.circle.badge.xmark")
                    }
                }
                Section("Legal and information") {
                    Button { agreementDocument = .terms } label: {
                        settingsRow("Terms of Service", symbol: "doc.text")
                    }
                    Button { agreementDocument = .privacy } label: {
                        settingsRow("Privacy Policy", symbol: "hand.raised")
                    }
                    Button { showingAbout = true } label: {
                        settingsRow("About Teto", symbol: "info.circle")
                    }
                }
                if let acceptance = store.library.agreementAcceptance {
                    Section("Agreement acceptance") {
                        LabeledContent("Version", value: acceptance.version)
                        LabeledContent("Accepted") {
                            Text(acceptance.acceptedAt, format: .dateTime.month(.abbreviated).day().year().hour().minute())
                                .multilineTextAlignment(.trailing)
                        }
                    }
                }
                Section {
                    Button { confirmingLogout = true } label: {
                        settingsRow("Log out", symbol: "rectangle.portrait.and.arrow.right")
                    }.disabled(!store.canEndSession)
                    Button(role: .destructive) { confirmingDeletion = true } label: {
                        Label("Delete account", systemImage: "person.crop.circle.badge.minus")
                            .frame(minHeight: 44)
                    }.disabled(!store.canEndSession)
                    if let actionError { FormError(message: actionError) }
                } header: {
                    Text("Account")
                } footer: {
                    Text("Logging out keeps your data on this device. Deleting your account removes your Teto data from this device.")
                }
            }
            .freshStudioPage()
            .tetoNavigationTitle("Settings").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
            .alert("Log out of Teto?", isPresented: $confirmingLogout) {
                Button("Cancel", role: .cancel) {}
                Button("Log out", role: .destructive) {
                    Task { @MainActor in
                        actionError = nil
                        if await store.logOut() { dismiss() }
                        else { actionError = "Please wait for your changes to finish saving, then try again." }
                    }
                }
            } message: {
                Text("You will return to sign in. Your profile, chats and saved videos will stay on this device.")
            }
            .alert("Delete your account?", isPresented: $confirmingDeletion) {
                Button("Cancel", role: .cancel) {}
                Button("Delete account", role: .destructive) {
                    Task { @MainActor in
                        actionError = nil
                        if await store.deleteLocalAccount() { dismiss() }
                        else if store.isLoaded { actionError = "Please wait for your changes to finish saving, then try again." }
                    }
                }
            } message: {
                Text("This permanently deletes your profile, imported video copies, chats, drafts, follows, likes, saved videos, comments and viewing history from this device. Photos originals stay unchanged. Teto has no online account service, so no server account will be deleted. This cannot be undone.")
            }
            .sheet(item: $agreementDocument) { UserAgreementView(document: $0) }
            .sheet(isPresented: $showingBlockedCreators) { BlockedCreatorsView() }
            .sheet(isPresented: $showingAbout) { LocalModeInfoView() }
        }
    }

    private func settingsRow(_ title: String, symbol: String) -> some View {
        HStack {
            Label(title, systemImage: symbol)
            Spacer(minLength: 8)
            Image(systemName: "chevron.right").font(.caption).foregroundStyle(TetoStyle.muted).accessibilityHidden(true)
        }
        .foregroundStyle(TetoStyle.ink).frame(minHeight: 44).contentShape(Rectangle())
    }
}
