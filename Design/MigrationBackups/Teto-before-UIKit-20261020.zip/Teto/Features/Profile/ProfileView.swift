import SwiftUI

struct ProfileView: View {
    @EnvironmentObject private var store: AppStore
    @State private var editingProfile = false
    @State private var showingSettings = false
    @State private var showingAbout = false
    @State private var showingBlockedCreators = false
    @State private var section = "Works"
    @State private var playingVideo: LocalVideo?
    @Environment(\.dynamicTypeSize) private var typeSize
    private var works: [LocalVideo] { store.personalWorks.filter { !$0.isBundled } }
    private var visibleVideos: [LocalVideo] {
        switch section {
        case "Liked": return store.likedVideos
        case "Saved": return store.savedVideos
        default: return works
        }
    }
    private var columns: [GridItem] {
        Array(repeating: GridItem(.flexible(), spacing: 6), count: typeSize.isAccessibilitySize ? 2 : 3)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 0) {
                identity
                VStack(spacing: 14) {
                    Button("Edit profile") { editingProfile = true }
                        .font(.subheadline.weight(.semibold))
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .background(Color.white.opacity(0.5), in: Capsule())
                        .overlay(Capsule().strokeBorder(TetoStyle.line, lineWidth: 0.8))
                    NavigationLink { WalletView(wallet: store.wallet) } label: {
                        HStack(spacing: 12) {
                            CurrencyArtwork(currency: .diamonds, size: 28)
                            Text("Wallet").font(.subheadline.weight(.semibold))
                            Spacer()
                            Image(systemName: "chevron.right").font(.caption)
                        }.padding(.horizontal, 16).frame(minHeight: 52)
                            .background(TetoStyle.lime, in: RoundedRectangle(cornerRadius: 16))
                    }.buttonStyle(.plain)
                    NavigationLink {
                        PendingCreationsView().toolbar(.hidden, for: .tabBar)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "clock.badge.checkmark").foregroundStyle(TetoStyle.emerald)
                            Text("Pending review (\(store.pendingSubmissions.count))").font(.subheadline.weight(.semibold))
                            Spacer(minLength: 4)
                            Image(systemName: "chevron.right").font(.caption)
                        }.padding(16).frame(minHeight: 52)
                            .background(Color.white.opacity(0.65), in: RoundedRectangle(cornerRadius: 16))
                    }.buttonStyle(.plain)
                    collectionTabs
                    collection
                }.padding(.horizontal, 16)
            }.padding(.bottom, 20)
        }
        .foregroundStyle(TetoStyle.ink)
        .safeAreaInset(edge: .top, spacing: 0) { header }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        // One canvas includes the header and extends behind the system status bar.
        .background { FreshStudioPageBackground().ignoresSafeArea() }
        .toolbar(.hidden, for: .navigationBar)
        .toolbarBackground(.automatic, for: .tabBar)
        .toolbarColorScheme(.light, for: .tabBar)
        .sheet(isPresented: $editingProfile) { ProfileEditorView(profile: store.library.profile) }
        .sheet(isPresented: $showingSettings) { ProfileSettingsView() }
        .sheet(isPresented: $showingBlockedCreators) { BlockedCreatorsView() }
        .sheet(isPresented: $showingAbout) { LocalModeInfoView() }
        .fullScreenCover(item: $playingVideo) { video in
            ShortsFeedView(isTabActive: true, isSearching: .constant(false),
                           collectionVideoIDs: [video.id], onClose: { playingVideo = nil }, closeLabel: "Back to profile")
        }
    }

    private var header: some View {
        HStack {
            Text("Me").font(TetoTypography.largeTitle).tracking(-1)
            Spacer()
            Button { showingSettings = true } label: {
                Image(systemName: "gearshape").font(.system(size: 22)).frame(width: 44, height: 44)
            }.accessibilityLabel("Settings")
        }.padding(.horizontal, 16).padding(.vertical, 6)
            .foregroundStyle(TetoStyle.ink)
    }

    private var identity: some View {
        VStack(spacing: 8) {
            ProfileAvatar(symbol: store.library.profile.avatarSymbol, size: 104)
                .overlay(Circle().strokeBorder(Color.white, lineWidth: 3))
            Text(store.library.profile.displayName).font(TetoTypography.subsection)
                .multilineTextAlignment(.center)
            Text("Dance. People. Together.").font(.caption).foregroundStyle(TetoStyle.muted)
            Text(store.library.profile.biography).font(.subheadline)
                .multilineTextAlignment(.center).foregroundStyle(TetoStyle.muted)
                .fixedSize(horizontal: false, vertical: true).padding(.top, 4)
        }.padding(.horizontal, 24).padding(.top, 2).padding(.bottom, 18)
            .frame(maxWidth: .infinity)
    }

    private func collectionTitle(_ item: String) -> String {
        switch item {
        case "Works": return "Works(\(works.count))"
        case "Liked": return "Liked(\(store.likedVideos.count))"
        case "Saved": return "Saved(\(store.savedVideos.count))"
        default: return item
        }
    }

    private var collectionTabs: some View {
        HStack(spacing: 0) {
            ForEach(["Works", "Liked", "Saved", "About"], id: \.self) { item in
                Button { section = item } label: {
                    Text(collectionTitle(item)).font(.subheadline.weight(section == item ? .semibold : .regular))
                        .monospacedDigit().lineLimit(1).minimumScaleFactor(0.75)
                        .frame(maxWidth: .infinity, minHeight: 44)
                        .foregroundStyle(section == item ? TetoStyle.ink : TetoStyle.muted)
                        .overlay(alignment: .bottom) {
                            if section == item { Capsule().fill(TetoStyle.emerald).frame(height: 2).padding(.horizontal, 20) }
                        }
                }.buttonStyle(.plain).accessibilityAddTraits(section == item ? .isSelected : [])
            }
        }.padding(.top, 2)
    }

    @ViewBuilder private var collection: some View {
        if section == "About" {
            VStack(spacing: 0) {
                NavigationLink { VoiceRoomsView(draftsOnly: true).toolbar(.hidden, for: .tabBar) } label: {
                    menuRow("Drafts(\(store.library.roomDrafts.count))", "doc.text")
                }
                Button { showingBlockedCreators = true } label: { menuRow("Blocked creators", "person.crop.circle.badge.xmark") }
                Button { showingAbout = true } label: { menuRow("About Teto", "info.circle") }
            }.buttonStyle(.plain)
        } else if visibleVideos.isEmpty {
            VStack(spacing: 12) {
                Image("DanceSneakers").resizable().scaledToFit().frame(width: 100, height: 100).accessibilityHidden(true)
                Text(section == "Liked" ? "Your favorite moves start here" : (section == "Saved" ? "Save your favorite moves" : "Share your first dance")).font(TetoTypography.headline)
                if section == "Liked" {
                    Text("Tap the heart on a video to find it here.")
                        .font(.subheadline).multilineTextAlignment(.center)
                } else {
                    NavigationLink("Open video library") {
                        VideoLibraryView(savedOnly: section == "Saved").toolbar(.hidden, for: .tabBar)
                    }
                        .font(.subheadline).frame(minHeight: 44)
                }
            }.foregroundStyle(TetoStyle.muted).frame(maxWidth: .infinity).padding(.vertical, 30)
        } else {
            LazyVGrid(columns: columns, spacing: 6) {
                ForEach(visibleVideos) { video in
                    Button { playingVideo = video } label: {
                        Color.clear.aspectRatio(0.75, contentMode: .fit)
                            .overlay { LocalVideoCover(url: store.coverURL(video)) }
                            .overlay(alignment: .bottomLeading) {
                                Label(video.durationLabel, systemImage: "play.fill")
                                    .font(.caption2.weight(.semibold)).foregroundStyle(.white)
                                    .padding(6).background(Color.black.opacity(0.35), in: Capsule()).padding(6)
                            }.clipShape(RoundedRectangle(cornerRadius: 10))
                    }.buttonStyle(.plain).accessibilityLabel("Play \(video.title)")
                }
            }
        }
    }

    private func menuRow(_ title: String, _ symbol: String) -> some View {
        HStack { Label(title, systemImage: symbol); Spacer(); Image(systemName: "chevron.right").font(.caption) }
            .font(.subheadline).frame(minHeight: 52)
    }
}

struct LocalModeInfoView: View {
    @Environment(\.dismiss) private var dismiss
    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack(spacing: 14) {
                        Image("TetoMark").resizable().scaledToFit().frame(width: 56, height: 56)
                            .clipShape(RoundedRectangle(cornerRadius: 14)).accessibilityHidden(true)
                        TetoWordmark(compact: true).foregroundStyle(TetoStyle.emerald)
                    }.padding(.vertical, 8)
                    Text("Find your rhythm. Connect through dance.")
                        .font(TetoTypography.subsection)
                    Text("A place for choreography, freestyle and the people who love to move.")
                }
                Section("Your data") {
                    Text("Your profile and activity are stored on this device. Cloud backup is unavailable.")
                    Text("Keep original copies of your videos. Removing Teto also removes its saved data.")
                    Text("Manage your data in Settings > Account.")
                }
                Section("Permissions") {
                    Text("Camera access is requested when needed. Camera footage is not recorded or sent.")
                    Text("Only the videos you choose are imported from Photos. Your originals stay unchanged.")
                }
                Section("Media credits") {
                    Text("Video and photo credits are available with the content.")
                }
            }
            .freshStudioPage()
            .tetoNavigationTitle("About Teto").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }
    }
}
