import SwiftUI

/// Shared actions embedded in both Live and Shorts option lists.
struct ContentSafetyActions: View {
    let target: ContentSafetyTarget
    let onBlocked: () -> Void
    @EnvironmentObject private var store: AppStore
    @State private var confirmingBlock = false
    @State private var error: String?

    var body: some View {
        Section("Safety") {
            NavigationLink {
                ContentReportView(target: target)
            } label: { Label("Report video", systemImage: "flag") }
            Button(role: .destructive) { confirmingBlock = true } label: {
                Label("Block creator", systemImage: "person.crop.circle.badge.xmark")
            }.disabled(store.isBusy || target.creator.isLocalOwner)
            if target.creator.isLocalOwner {
                Text("You cannot block your own profile.").font(.footnote).foregroundStyle(TetoStyle.muted)
            }
            if let error { Text(error).font(.footnote).foregroundStyle(.red) }
        }
        .confirmationDialog("Block \(target.creator.name)?", isPresented: $confirmingBlock, titleVisibility: .visible) {
            Button("Block creator", role: .destructive) {
                Task {
                    if await store.blockCreator(target.creator) { onBlocked() }
                    else { error = store.lastSaveError ?? "The creator could not be blocked. Try again." }
                }
            }
        } message: {
            Text("Hide this creator's videos and chats. Unblock them anytime in Settings.")
        }
    }
}

struct ContentReportView: View {
    let target: ContentSafetyTarget
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var reason: ContentReportReason?
    @State private var details = ""
    @State private var saved = false
    @State private var error: String?
    @FocusState private var editing: Bool
    private var valid: Bool {
        reason != nil && details.count <= 500
        && !details.unicodeScalars.contains { $0.properties.isAlphabetic && !$0.isASCII }
    }
    var body: some View {
        Form {
            if saved {
                Section {
                    Label("Saved", systemImage: "internaldrive")
                    Text("Not submitted. Reporting is unavailable.")
                    Button("Done") { dismiss() }
                }
            } else {
                Section(target.kind.rawValue) {
                    Text(target.title).font(TetoTypography.headline)
                    Text(target.creator.name).foregroundStyle(TetoStyle.muted)
                }
                Section("Reason") {
                    ForEach(ContentReportReason.allCases) { value in
                        Button { reason = value } label: {
                            HStack {
                                Text(value.rawValue).foregroundStyle(.primary)
                                Spacer()
                                if reason == value { Image(systemName: "checkmark") }
                            }.frame(minHeight: 44)
                        }.accessibilityAddTraits(reason == value ? .isSelected : [])
                    }
                }
                Section("Additional details") {
                    TextField("Tell us more (optional)", text: $details, axis: .vertical)
                        .lineLimit(3...6).focused($editing)
                    Text("\(details.count)/500 · English only").font(.caption).foregroundStyle(TetoStyle.muted)
                }
                Section {
                    Text("Reporting is unavailable. You can save a draft.").font(.footnote)
                    if let error { Text(error).foregroundStyle(.red) }
                    Button("Save report") {
                        guard let reason else { return }
                        editing = false
                        Task {
                            if await store.saveContentReport(target, reason: reason, details: details) { saved = true }
                            else { error = store.lastSaveError ?? "The report could not be saved. Try again." }
                        }
                    }.disabled(!valid)
                }
            }
        }
        .disabled(store.isBusy).scrollDismissesKeyboard(.interactively)
        .freshStudioPage()
            .tetoNavigationTitle(target.kind == .comment ? "Report comment" : "Report video").navigationBarTitleDisplayMode(.inline)
    }
}

struct BlockedCreatorsView: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss
    @State private var error: String?
    private var creators: [CreatorProfile] {
        Array((store.library.contentSafety?.blockedCreators ?? [:]).values).sorted { $0.name < $1.name }
    }
    var body: some View {
        NavigationStack {
            List {
                if creators.isEmpty {
                    ContentUnavailableView("No blocked creators", systemImage: "person.crop.circle.badge.checkmark",
                                           description: Text("Creators you block will appear here."))
                }
                ForEach(creators) { creator in
                    HStack {
                        Text(creator.name)
                        Spacer(minLength: 12)
                        Button("Unblock") {
                            Task {
                                if !(await store.unblockCreator(creator.id)) {
                                    error = store.lastSaveError ?? "The creator could not be unblocked. Try again."
                                }
                            }
                        }.frame(minHeight: 44).disabled(store.isBusy)
                    }
                }
                Section {
                    Text("Unblocking restores videos and chats without following the creator.")
                        .font(.footnote).foregroundStyle(TetoStyle.muted)
                    if let error { Text(error).foregroundStyle(.red) }
                }
                if let reports = store.library.contentSafety?.reports, !reports.isEmpty {
                    Section("Report drafts") {
                        Text("Not submitted").font(.footnote).foregroundStyle(TetoStyle.muted)
                        ForEach(reports.reversed()) { report in
                            VStack(alignment: .leading, spacing: 5) {
                                Text(report.title).font(TetoTypography.headline)
                                Text(report.reason.rawValue).font(.subheadline)
                                Text(report.creatorName).font(.caption).foregroundStyle(TetoStyle.muted)
                            }
                        }
                    }
                }
            }
            .freshStudioPage()
            .tetoNavigationTitle("Blocked creators").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .confirmationAction) { Button("Done") { dismiss() } } }
        }.preferredColorScheme(.light).tint(TetoStyle.emerald)
    }
}
