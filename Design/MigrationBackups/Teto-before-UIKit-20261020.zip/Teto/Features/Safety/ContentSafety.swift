import Foundation

struct ContentSafetyTarget: Identifiable {
    enum Kind: String, Codable { case live = "Live video", shortVideo = "Short video", comment = "Comment" }
    let id: String
    let title: String
    let kind: Kind
    let creator: CreatorProfile

    static func comment(id: String, name: String, text: String) -> Self {
        Self(id: id, title: text, kind: .comment,
             creator: CreatorProfile(id: "comment-author:" + name, name: name, biography: ""))
    }
}

enum ContentReportReason: String, Codable, CaseIterable, Identifiable {
    case spam = "Spam or misleading content"
    case harassment = "Harassment or bullying"
    case hate = "Hate or discrimination"
    case sexual = "Sexual content"
    case violence = "Violence"
    case dangerous = "Dangerous activity"
    case other = "Other"
    var id: String { rawValue }
}

struct LocalContentReport: Codable, Identifiable {
    let id: UUID
    let contentID: String
    let title: String
    let kind: ContentSafetyTarget.Kind
    let creatorID: String
    let creatorName: String
    let reason: ContentReportReason
    let details: String
    let savedAt: Date
}

struct ContentSafetyState: Codable {
    var blockedCreators: [String: CreatorProfile] = [:]
    var reports: [LocalContentReport] = []
}
