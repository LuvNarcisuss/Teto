import Foundation

struct ShortsInteractionSnapshot: Codable {
    var schemaVersion = 1
    var liked: Set<UUID> = []
    var comments: [UUID: [ShortComment]] = [:]
    var completedShares: [UUID: Int] = [:]
}

/// Separate from library saves so profile/favorite updates cannot overwrite discussions.
actor ShortsInteractionRepository {
    private let url: URL
    init(root: URL) { url = root.appendingPathComponent("shorts-interactions-v1.json") }

    func load() throws -> ShortsInteractionSnapshot {
        let data: Data
        do { data = try Data(contentsOf: url) }
        catch let error as NSError where error.domain == NSCocoaErrorDomain && error.code == NSFileReadNoSuchFileError {
            return ShortsInteractionSnapshot()
        }
        let snapshot = try JSONDecoder().decode(ShortsInteractionSnapshot.self, from: data)
        guard snapshot.schemaVersion == 1 else { throw LocalLibraryError.unsupportedVersion }
        guard snapshot.completedShares.values.allSatisfy({ $0 >= 0 }) else { throw LocalLibraryError.unreadableLibrary }
        for entries in snapshot.comments.values {
            let identifiers = Set(entries.map(\.id))
            let roots = Set(entries.filter { $0.parentID == nil }.map(\.id))
            guard identifiers.count == entries.count,
                  entries.allSatisfy({ entry in
                      guard let parent = entry.parentID else { return true }
                      return parent != entry.id && roots.contains(parent)
                  }) else { throw LocalLibraryError.unreadableLibrary }
        }
        return snapshot
    }

    func save(_ snapshot: ShortsInteractionSnapshot) throws {
        try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
        try JSONEncoder().encode(snapshot).write(to: url,
            options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}
