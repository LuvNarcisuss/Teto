import CoreTransferable
import Foundation
import UniformTypeIdentifiers

/// PhotosPicker grants access to the selected item only. No broad library permission.
struct ImportedVideo: Transferable {
    let temporaryURL: URL

    static var transferRepresentation: some TransferRepresentation {
        FileRepresentation(importedContentType: .movie) { received in
            let size = try received.file.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard size > 0 else { throw LocalLibraryError.invalidVideo }
            guard size <= 250 * 1_024 * 1_024 else { throw LocalLibraryError.videoTooLarge }
            let suppliedExtension = received.file.pathExtension.lowercased()
            let ext = ["mp4", "mov", "m4v"].contains(suppliedExtension) ? suppliedExtension : "mov"
            let destination = FileManager.default.temporaryDirectory
                .appendingPathComponent("teto-import-\(UUID().uuidString).\(ext)")
            do {
                try Task.checkCancellation()
                try FileManager.default.copyItem(at: received.file, to: destination)
                try Task.checkCancellation()
                return ImportedVideo(temporaryURL: destination)
            } catch {
                try? FileManager.default.removeItem(at: destination)
                throw error
            }
        }
    }
}
